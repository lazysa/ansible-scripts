ALTER TABLE `audience`.`insight_info`
ADD COLUMN `update_period` TINYINT(4) NOT NULL DEFAULT 5 AFTER `error_code`,
ADD COLUMN `expires` DATETIME NOT NULL DEFAULT '2199-01-01 00:00:00' AFTER `update_period`;

ALTER TABLE `audience`.`insight_info`
ADD COLUMN `start_task` TINYINT(4) NOT NULL DEFAULT 0 AFTER `expires`;


CREATE TABLE `id_merge_report` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `segment_id` varchar(255) NOT NULL COMMENT '人群id',
  `status` tinyint(4) NOT NULL DEFAULT '1' COMMENT '0 删除\n1 正常',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `refresh_time` datetime DEFAULT NULL,
  `data_status` tinyint(4) NOT NULL DEFAULT '1',
  `error_code` varchar(255) DEFAULT NULL,
  `update_period` tinyint(4) NOT NULL DEFAULT '5',
  `expires` datetime NOT NULL DEFAULT '2199-01-01 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=351 DEFAULT CHARSET=utf8 COMMENT='id_merge_report';

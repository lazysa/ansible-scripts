'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.analysisDownload = exports.campaignSegmentReportTime = exports.campaignSegmentReportPages = exports.campaignSegmentReport = exports.analysis = undefined;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import {Enums} from '../../config/consts';


let analysis = exports.analysis = _joi2.default.object().keys({
    category: _joi2.default.number().integer().required(),
    dataSourceId: _joi2.default.number().integer(),
    // tagGroupId:Joi.number().integer(),
    secTagId: _joi2.default.string(),
    sort: _joi2.default.string(),
    isTopTen: _joi2.default.number().integer()
});

let campaignSegmentReport = exports.campaignSegmentReport = _joi2.default.object().keys({
    segment: _joi2.default.array().required(),
    metric: _joi2.default.array()
});
let campaignSegmentReportPages = exports.campaignSegmentReportPages = _joi2.default.object().keys({
    segment: _joi2.default.array().required(),
    metric: _joi2.default.array(),
    pageIndex: _joi2.default.number().integer(),
    pageSize: _joi2.default.number().integer(),
    keyword: _joi2.default.string().allow('', null).max(100),
    sort: _joi2.default.string().allow('', null).max(100)
});
let campaignSegmentReportTime = exports.campaignSegmentReportTime = _joi2.default.object().keys({
    segment: _joi2.default.array().required()
});

let analysisDownload = exports.analysisDownload = _joi2.default.object().keys({
    category: _joi2.default.number().integer().required(),
    dataSourceId: _joi2.default.number().integer(),
    sort: _joi2.default.string(),
    secTagId: _joi2.default.string()
});
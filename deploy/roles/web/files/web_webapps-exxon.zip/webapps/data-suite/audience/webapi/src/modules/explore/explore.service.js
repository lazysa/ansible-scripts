'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getBehaviourTypeList = exports.getBasic = exports.getDetails = exports.getExploreList = exports.dealWithTagList = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _lodash = require('lodash');

var _tag = require('../tag/tag.service');

var _tagValue = require('../tagValue/tagValue.service');

var _api = require('../common/api');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/**
 * 添加taglist的tagName,tagValueName
 * @param tagList
 * @param tagArrList
 * @param tagValueArrList
 * @returns {*}
 */
let dealWithTagList = exports.dealWithTagList = (tagList, tagArrList, tagValueArrList) => {
    let arr = Array.prototype.concat.call([], tagArrList, tagValueArrList);
    let obj = {};
    arr.forEach(item => {
        obj[item.id] = item.name;
    });
    tagList.forEach(item => {
        if (item.tagId && obj[item.tagId]) {
            item.tagName = obj[item.tagId];
        }
        if (item.tagValueId && item.tagValueId.length > 0) {
            item.tagValueName = item.tagValueId.map(z => obj[z]);
        }
    });
    return tagList;
};

let getExploreList = exports.getExploreList = body => {
    return _api.ReportApi.getExploreList(body);
};

let getDetails = exports.getDetails = body => {
    return _api.ReportApi.getDetails(body);
};

let getBasic = exports.getBasic = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (body) {
        let data = yield _api.ReportApi.getBasic(body);

        if (data.basicInfo && data.basicInfo.tagList && data.basicInfo.tagList.length > 0) {
            let tagList = data.basicInfo.tagList;
            let tagArrList = yield (0, _tag.getFirstTaglistByIds)(tagList.map(function (item) {
                return item.tagId;
            }));
            let tagValueArrList = yield (0, _tagValue.getFirstTagValuelistByIds)((0, _lodash.union)(...tagList.map(function (item) {
                return item.tagValueId;
            })));
            tagList = dealWithTagList(tagList, tagArrList, tagValueArrList);
            data.basicInfo.tagList = tagList;
        }
        return data;
    });

    return function getBasic(_x) {
        return _ref.apply(this, arguments);
    };
})();

let getBehaviourTypeList = exports.getBehaviourTypeList = body => {
    return _api.ReportApi.getBehaviourTypeList(body);
};
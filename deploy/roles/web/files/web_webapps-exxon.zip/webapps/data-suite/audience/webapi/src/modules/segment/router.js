'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _segmentController = require('./segment.controller.js');

var ctrl = _interopRequireWildcard(_segmentController);

var _segmentFilter = require('./segment.filter.js');

var filter = _interopRequireWildcard(_segmentFilter);

var _permission = require('../common/util/permission.util');

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
  prefix: '/segment'
});
/**
 * @apiVersion 1.0.0
 * @api {GET} /segment/first/all/list 获取第一方所有人群列表
 * @apiName getALlList
 * @apiGroup segment
 * @apiSuccess {String}    id      人群id
 * @apiSuccess {String}   name  人群名
 */
router.get('/first/all/list', ctrl.firstAllList);
/**
 * @apiVersion 1.0.0pu't
 * @api {GET} /segment/upload/list 获取上传人群列表
 * @apiName getUploadList
 * @apiGroup segment
 * @apiSuccess {String}    id      人群id
 * @apiSuccess {String}   name  人群名
 */
router.get('/upload/list', (0, _permission.checkPermission)('audience.segment.access'), (0, _permission.constructorResource)('segment'), ctrl.segmentUploadList);
/**
 * @apiVersion 1.0.0
 * @api {GET} /segment/upload/field/list 人群上传的映射字段list
 * @apiName getUploadFieldList
 * @apiGroup segment
 */
router.get('/upload/field/list', ctrl.uploadFieldList);
router.post('/upload', ctrl.upload);
/**
 * @apiVersion 1.0.0
 * @api {GET} /segment/:segmentGroupId/normalList 获取正常状态的人群list
 * @apiName getNormalList
 * @apiGroup segment
 * @apiParam  {String} segmentGroupId 人群组id
 * @apiSuccess {String}    id      人群id
 * @apiSuccess {String}   name  人群名
 */
router.get('/:segmentGroupId/normalList', (0, _permission.checkPermission)('audience.segment.access'), (0, _permission.constructorResource)('segment'), ctrl.normalList);
/**
 * @apiVersion 1.0.0
 * @api {GET} /segment/:segmentGroupId/allList 获取所有状态的人群list
 * @apiName getAllList
 * @apiGroup segment
 * @apiParam  {String} segmentGroupId 人群组id
 * @apiSuccess {String}    id      人群id
 * @apiSuccess {String}   name  人群名
 */
router.get('/:segmentGroupId/allList', (0, _permission.checkPermission)('audience.segment.access'), (0, _permission.constructorResource)('segment'), ctrl.allList);

/**
 * @apiVersion 1.0.0
 * @api {GET} /segment/:segmentGroupId/pages 获取第一方所有人群分页
 * @apiName getALlPages
 * @apiGroup segment
 * @apiParam  {String} segmentGroupId 人群组id
 * @apiParam  {Number} pageIndex 分页索引
 * @apiParam  {Number} pageSize 分页大小
 * @apiParam  {String} keywords 搜索字段
 * @apiParam  {String} sort 排序字段s
 * @apiSuccess {String}    id      人群id
 * @apiSuccess {String}   name  人群名
 */
router.get('/:segmentGroupId/pages', (0, _permission.checkPermission)('audience.segment.page'), (0, _permission.constructorResource)('segment'), filter.pages, ctrl.pages);

/**
 * @apiVersion 1.0.0
 * @api {POST} /segment 新建第一方人群
 * @apiName segmentCreate
 * @apiGroup segment
 * @apiContentType application/json
 * @apiParam  {String} name 人群名
 * @apiParam  {Number} segmentGroupId 人群分组id
 * @apiParam  {Number} type 人群类型
 * @apiParam  {Object} segmentRules 人群规则
 * @apiParam  {Object}  insight 洞察设置

 * @apiParam  {String} remark 备注
 * @apiParam  {Number} updatePeriod 人群更新周期
 * @apiParam  {Number} isForever 人群是否是不过期
 * @apiParam  {String} expires 人群有效期
 * @apiParam  {Number} isOpenIdMerge 是否开启id merge
 * @apiParam  {Number} reportUpdatePeriod 报告更新周期
 * @apiParam  {Number} reportIsForever 报告人群是否是不过期
 * @apiParam  {String} reportExpires 报告有效期
 */
router.post('/', (0, _permission.checkPermission)('audience.segment.create'), filter.create, ctrl.create);

// router.post('/campaign',ctrl.createCampaign);
// router.post('/site',ctrl.createSite);
router.put('/campaign', ctrl.updateCampaignAndSite);
router.put('/site', ctrl.updateCampaignAndSite);

/**
 * @apiVersion 1.0.0
 * @api {GET} /segment/:id 根据人群id获取单一人群信息
 * @apiName query
 * @apiGroup segment
 * @apiParam  {String} id 人群id
 * @apiSuccess {String}    id      人群id
 * @apiSuccess {String}   name  人群名
 */
router.get('/:id', ctrl.query);

/**
 * @apiVersion 1.0.0
 * @api {GET} /insight/:id 根据人群id获取洞察概览
 * @apiName queryInsight
 * @apiGroup segment
 * @apiParam  {String} id 人群id
 */
router.get('/insight/:id', ctrl.queryInsight);

/**
 * @apiVersion 1.0.0
 * @api {DELETE} /segment/:id 删除人群
 * @apiName remove
 * @apiGroup segment
 * @apiParam  {String} id 人群id
 */
router.delete('/:id', ctrl.removeSegmentBaseAuth, ctrl.removeSegmentAuth, (0, _permission.checkPermission)('audience.segment.delete'), ctrl.remove);

/**
 * @apiVersion 1.0.0
 * @api {DELETE} /segment/validate/:id 删除人群验证
 * @apiName removeValidate
 * @apiGroup segment
 * @apiParam  {String} id 人群id
 */
router.delete('/validate/:id', ctrl.removeSegmentBaseAuth, ctrl.removeValidate);

/**
 * @apiVersion 1.0.0
 * @api {PUT} /segment/:id 人群更新 参数同新建
 * @apiName update
 * @apiGroup segment
 * @apiParam  {String} id 人群id
 */
router.put('/:id', filter.create, ctrl.update);

/**
 * @apiVersion 1.0.0
 * @api {PUT} /segment/:id 手动更新洞察报告
 * @apiName update
 * @apiGroup segment
 * @apiParam  {String} segmentId 人群id
 * @apiParam  {Number} category 洞察类别
 * @apiParam  {Number} dataSourceId 第三方数据源id(第一方报告不传此参数)
 */
router.put('/:segmentId/insight', filter.updateInsight, ctrl.updateInsight);

/**
 * @apiVersion 1.0.0
 * @api {GET} /segment/download/:segmentId 人群文件下载
 * @apiName download
 * @apiGroup segment
 * @apiParam  {String} segmentId 人群id
 */
router.get('/download/:segmentId', ctrl.download);
router.get('/download/validate/:segmentId', ctrl.downloadValidate);

router.post('/crossover/summary', ctrl.crossoverSummary);

exports.default = router;
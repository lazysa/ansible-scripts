'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _tagValueController = require('./tagValue.controller.js');

var ctrl = _interopRequireWildcard(_tagValueController);

var _tagValueFilter = require('./tagValue.filter.js');

var filter = _interopRequireWildcard(_tagValueFilter);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
    prefix: '/tagValue'
});

//根据组id获取标签list
router.get('/first/:tagId/list', ctrl.firstPartyList);
router.get('/first/:tagId/namelist', ctrl.firstPartyNameList);
router.get('/third/:tagId/list', ctrl.thirdPartyList);

//根据组id获取标签pages
router.get('/first/:tagId/pages', filter.pages, ctrl.firstPartyPages);
router.get('/third/:tagId/pages', filter.pages, ctrl.thirdPartyPages);

router.post('/first', filter.create, ctrl.create);
router.post('/upload', ctrl.upload);
router.get('/first/:id', ctrl.query);

router.delete('/first/validate/:id', ctrl.removeTagValueBaseAuth, ctrl.removeValidate);
router.delete('/first/:id', ctrl.removeTagValueBaseAuth, ctrl.removeTagValueAuth, ctrl.remove);

router.put('/first/:id', filter.create, ctrl.update);
router.put('/first/display/sequence', filter.displaySequenceUpdate, ctrl.firstDisplaySequenceUpdate);
router.put('/third/display/sequence', filter.displaySequenceUpdate, ctrl.thirdDisplaySequenceUpdate);

router.post('/validate', filter.validateRules, ctrl.validateRules);
router.post('/bulkCreate', filter.bulkCreate, ctrl.bulkCreate);

exports.default = router;
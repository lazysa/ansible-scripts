'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.generateIdReportXlsx = exports.generateXLSX = exports.generateXLSXReportFile = exports.generateReportZip = exports.generateReportZipOrTar = exports.generateReportFile = exports.getFieldList = exports.getAllInsightListBySegmentId = exports.getRefreshTime = exports.getCoverage = exports.create = exports.filterAnalysis = exports.getTagValueByTagValueModelThroughTagIds = exports.getTagValueByTagValueModel = exports.getTagListByTagModel = exports.sortServerAnalysis = exports.isNullReport = exports.getInsightTagIds = exports.Insight = undefined;

var _is = require('babel-runtime/core-js/object/is');

var _is2 = _interopRequireDefault(_is);

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _keys = require('babel-runtime/core-js/object/keys');

var _keys2 = _interopRequireDefault(_keys);

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

/**
 * 获取覆盖人数
 * @param segmentIds
 * @returns {model}
 */
let getCoverage = exports.getCoverage = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (segmentIds) {
        let list = yield _models.Segment.findAll({
            where: {
                id: { $in: segmentIds }
            },
            raw: true
        });
        return convertArrayToMapObject(list, 'id', 'coverage');
    });

    return function getCoverage(_x9) {
        return _ref3.apply(this, arguments);
    };
})();

/**
 * 获取人群报告的更新时间
 * @param segmentIds
 * @param category
 * @param dataSourceId
 * @return {*|Query}
 */


let getRefreshTime = exports.getRefreshTime = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (segmentIds, category, dataSourceId) {
        let where = {
            segmentId: { $in: segmentIds },
            category
        };
        if (dataSourceId) {
            (0, _assign2.default)(where, {
                dataSourceId
            });
        }
        let list = yield _models.InsightInfo.findAll({
            where,
            raw: true
        });
        return convertArrayToMapObject(list, 'segmentId', 'refreshTime');
    });

    return function getRefreshTime(_x10, _x11, _x12) {
        return _ref4.apply(this, arguments);
    };
})();

/**
 *
 * @param segmentId
 * @returns {*}
 */


exports.getListByModelName = getListByModelName;
exports.getOrderSort = getOrderSort;
exports.getDisplayByMetrics = getDisplayByMetrics;

var _lodash = require('lodash');

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _exceljs = require('exceljs');

var _exceljs2 = _interopRequireDefault(_exceljs);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _jszip = require('jszip');

var _jszip2 = _interopRequireDefault(_jszip);

var _archiver = require('archiver');

var _archiver2 = _interopRequireDefault(_archiver);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _consts = require('../../config/consts');

var _api = require('../common/api');

var _helper = require('../common/util/helper');

var _models = require('../common/models');

var _tagGroup = require('../tagGroup/tagGroup.service');

var _fileToken = require('../fileToken/fileToken.service');

var _dataSource = require('../dataSource/dataSource.service');

var _through = require('../../config/idReport/through.metric');

var _through2 = _interopRequireDefault(_through);

var _insightDownload = require('../../config/insightDownload/insight.download.type');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const { Status, TagStatus, ColType, DataSourceCategory, IsUsedForInsight } = _consts.Enums;


/**
 * 洞察类
 */
class Insight {
    constructor({ segmentId, category, dataSourceId, sort, tagId, secTagId, downloadMode }) {
        this.downloadMode = downloadMode;
        this.segmentId = segmentId;
        this.segmentIdList = segmentId.split(',');
        this.multipleMode = this.segmentIdList.length > 1;
        this.category = category;
        this.dataSourceId = dataSourceId;
        this.tagId = tagId;
        this.secTagId = secTagId;
        this.sort = sort;
        this.model = Number(category) === DataSourceCategory.FirstParty ? 'first' : 'third';
        this.insightData = null;
        this.srcData = null;
        this.segmentObj = null;
        this.coverage = null;
        this.refreshTime = null;
        this.fileName = null;
    }

    getInsightFormServer() {
        var _this = this;

        return (0, _asyncToGenerator3.default)(function* () {
            let srcData = {};
            let multipleMode = _this.multipleMode;
            if (!_this.tagId && !_this.secTagId) {
                //全部标签
                srcData = _this.downloadMode ? yield _api.ReportApi.downloadInsightFormServer(_this.segmentId, _this.category, _this.dataSourceId) : multipleMode ? yield _api.ReportApi.getInsightFormServerMulti(_this.segmentIdList, _this.category, _this.dataSourceId) : yield _api.ReportApi.getInsightFormServer(_this.segmentId, _this.category, _this.dataSourceId);
            } else if (_this.secTagId) {
                //二维
                srcData = _this.downloadMode ? yield _api.ReportApi.downloadInsight2dFormServer(_this.segmentId, _this.tagId, _this.secTagId) : multipleMode ? yield _api.ReportApi.getInsight2dFormServerMulti(_this.segmentIdList, _this.tagId, _this.secTagId) : yield _api.ReportApi.getInsight2dFormServer(_this.segmentId, _this.tagId, _this.secTagId);
            } else if (_this.tagId) {
                //单维
                srcData = _this.downloadMode ? yield _api.ReportApi.downloadInsightFormServer(_this.segmentId, _this.category, _this.dataSourceId, _this.tagId) : multipleMode ? yield _api.ReportApi.getInsightFormServerMulti(_this.segmentIdList, _this.category, _this.dataSourceId, _this.tagId) : yield _api.ReportApi.getInsightFormServer(_this.segmentId, _this.category, _this.dataSourceId, _this.tagId);
            }
            _this.insightData = srcData && srcData.insight;
            _this.srcData = srcData;
            return _this;
        })();
    }

    getInsightTagIds() {
        return getInsightTagIds(this.model, this.category, this.dataSourceId);
    }

    filterAnalysis() {
        var _this2 = this;

        return (0, _asyncToGenerator3.default)(function* () {
            if (_this2.tagId) {
                _this2.insightData = yield filterAnalysis(_this2.insightData, _this2.model, null, _this2.tagId, _this2.secTagId);
                return _this2;
            }
            _this2.insightData = yield filterAnalysis(_this2.insightData, _this2.model, (yield _this2.getInsightTagIds()));
            return _this2;
        })();
    }

    getCoverage() {
        var _this3 = this;

        return (0, _asyncToGenerator3.default)(function* () {
            _this3.coverage = yield getCoverage(_this3.segmentIdList);
            let totalCoverage = _this3.srcData && _this3.srcData.coverage;
            if (!_this3.multipleMode && totalCoverage) _this3.coverage = totalCoverage;
            return _this3;
        })();
    }

    getRefreshTime() {
        var _this4 = this;

        return (0, _asyncToGenerator3.default)(function* () {
            _this4.refreshTime = yield getRefreshTime(_this4.segmentIdList, _this4.category, _this4.dataSourceId);
            let refreshTime = _this4.srcData && _this4.srcData.refreshTime;
            if (!_this4.multipleMode && refreshTime) _this4.refreshTime = refreshTime;
            return _this4;
        })();
    }

    returnFileToken() {
        var _this5 = this;

        return (0, _asyncToGenerator3.default)(function* () {
            let fileName;
            if (_this5.tagId) {
                fileName = yield generateXLSXReportFile(_this5.insightData, _this5.segmentObj, _this5.coverage, _this5.dataSourceId, _this5.secTagId);
            } else {
                fileName = yield generateReportFile(_this5.insightData, _this5.segmentObj, _this5.coverage, _this5.dataSourceId);
            }
            if (!_fs2.default.existsSync(fileName)) {
                throw new _errors2.default.ReportNotExistFile();
            }
            return (0, _fileToken.getToken)(fileName);
        })();
    }

    sortServerAnalysis() {
        this.insightData = sortServerAnalysis(this.insightData, this.sort);
        return this;
    }

    returnAllDimensionAnalysis() {
        return {
            refreshTime: this.refreshTime,
            coverage: this.coverage,
            analysis: this.insightData
        };
    }

    returnSingleDimensionAnalysis() {
        return this.insightData && this.insightData[0] || {};
    }
}

exports.Insight = Insight; /**
                            * 获取一维前500的洞察结果
                            * @param segmentId
                            * @param category
                            * @param dataSourceId
                            * @param tagId
                            * @returns {*}
                            */
// export let getInsightFormServer = (segmentId,category,dataSourceId,tagId) => {
//     let url = `${baseUrl}/query/insight`;
//     return getReportApi(url,{
//         tagId: tagId || '',
//         segmentId: segmentId === 'TOTAL' ? '' : segmentId,
//         sourceId: Number(category) === DataSourceCategory.FirstParty ? 0 : Number(dataSourceId)
//     });
// };
/**
 * 获取所有的洞察结果，生成xlsx
 * @param segmentId
 * @param category
 * @param dataSourceId
 * @param tagId
 * @returns {*}
 */
// export let downloadInsightFormServer = (segmentId,category,dataSourceId,tagId) => {
//     let url = `${baseUrl}/download/insight`;
//     return getReportApi(url,{
//         tagId: tagId || '',
//         segmentId: segmentId === 'TOTAL' ? '' : segmentId,
//         sourceId: Number(category) === DataSourceCategory.FirstParty ? 0 : Number(dataSourceId)
//     });
// };
/**
 * 获取第一方样本库二维分析结果
 * @param segmentId
 * @param tagId
 * @param secTagId
 * @returns {*}
 */
// export let getInsight2dFormServer = (segmentId,tagId,secTagId) => {
//     let url = `${baseUrl}/query/insight2d`;
//     return getReportApi(url,{
//         tagId,
//         secTagId,
//         segmentId: segmentId === 'TOTAL' ? '' : segmentId
//     });
// };

/**
 * 获取第一方样本库二维分析结果下载
 * @param segmentId
 * @param tagId
 * @param secTagId
 * @returns {*}
 */
// export let downloadInsight2dFormServer = (segmentId,tagId,secTagId) => {
//     let url = `${baseUrl}/download/insight2d`;
//     return getReportApi(url,{
//         tagId,
//         secTagId,
//         segmentId: segmentId === 'TOTAL' ? '' : segmentId
//     });
// };

// /**
//  * 活动效果分析图表
//  * @param body
//  * @return {*}
//  */
// export function getCampaignSegmentReport(body) {
//     let url = `${analyticsApiPathUrl}/campaign/report/audience/segment`;
//     return getData(url,body);
// }
//
// /**
//  * 活动效果分析分页
//  * @param body
//  * @return {*}
//  */
// export function getCampaignSegmentReportPages(body) {
//     let url = `${analyticsApiPathUrl}/campaign/report/audience/segment/pages`;
//     return getData(url,body);
// }
//
// /**
//  * 活动效果分析时间
//  * @param body
//  * @return {*}
//  */
// export function getCampaignSegmentReportTime(body) {
//     let url = `${analyticsApiPathUrl}/campaign/report/audience/segment/time`;
//     return getData(url,body);
// }
//
// /**
//  * 活动效果下载
//  * @param body
//  * @return {*}
//  */
// export async function getCampaignSegmentReportDownload(body) {
//     let url = `${analyticsApiPathUrl}/campaign/report/audience/segment/download`;
//     let token = await getData(url,body);
//     let downloadUrl = `${analyticsApiPathUrl}/fileToken/${token}/downloadFile`;
//     let filePath = path.join(config.fileDir,'./segmentCampaignReport.xlsx');
//     await downloadFormServer(downloadUrl,{},{method: 'get'},{filePath});
//     return filePath;
// }

/**
 * 包装根据modelName取对应第一方或者第三方的taglist
 * @param modelName
 * @param confitions
 * @return {*}
 */

function getListByModelName(modelName, confitions) {
    switch (modelName) {
        case 'FirstPartyTag':
            return _models.FirstPartyTag.findAll(confitions);
        case 'ThirdPartyTag':
            return _models.ThirdPartyTag.findAll(confitions);
        case 'FirstPartyTagValue':
            return _models.FirstPartyTagValue.findAll(confitions);
        case 'ThirdPartyTagValue':
            return _models.ThirdPartyTagValue.findAll(confitions);
    }
}

/**
 * 根据dataSourceId 和categroy取得对应得tagID list
 * @param modelName
 * @param category
 * @param dataSourceId
 * @returns {*}
 */
let getInsightTagIds = exports.getInsightTagIds = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (modelName, category, dataSourceId) {
        let tagGroupList,
            tagGroupIds,
            tagGroupMap = {};
        if (!tagGroupIds) {
            //没传组标签分组ids(数组)的情况
            tagGroupList = yield (0, _tagGroup.getTagGroupByCategory)(category, dataSourceId);
            tagGroupIds = tagGroupList.map(function (item) {
                return item.id;
            });
            tagGroupList.forEach(function (x) {
                tagGroupMap[x.id] = x.name;
            });
        }
        let tagList = yield getListByModelName(`${(0, _lodash.capitalize)(modelName)}PartyTag`, {
            attributes: {
                exclude: ['tagType', 'mergeRule', 'createdAt', 'updatedAt', 'status']
            },
            where: {
                tagGroupId: {
                    $in: tagGroupIds
                },
                status: TagStatus.Open,
                isUsedForInsight: IsUsedForInsight.able
            },
            raw: true
        });

        tagList.forEach(function (z) {
            z.tagGroupName = tagGroupMap[z.tagGroupId];
        });
        return tagList;
    });

    return function getInsightTagIds(_x, _x2, _x3) {
        return _ref.apply(this, arguments);
    };
})();
/**
 * 判断是否是空的报告
 * @param srcData
 * @return {boolean}
 */
let isNullReport = exports.isNullReport = srcData => {
    let isNull = true;
    if (!srcData || !srcData.insight) return isNull;
    let data = srcData.insight;
    for (let dataItem of data) {
        if (dataItem.result && dataItem.result.length > 0) {
            isNull = false;
        }
    }
    return isNull;
};

/**
 * 洞察指标排序
 * @param array
 * @param firstSort
 * @return {Array}
 */
function getOrderSort(array, firstSort) {
    const defaultSort = [['displaySequence', 'asc'], ['uv', 'desc'], ['featurePercentage', 'desc'], ['percentage', 'desc'], ['tagValueName', 'asc'], ['tagValueId', 'asc']];
    let firstSortKeyName = firstSort && firstSort.replace(/^-/, '');
    let firstSortMethod = firstSort && /^-/.test(firstSort) ? 'desc' : 'asc';
    let keyNameArray = firstSort ? [firstSortKeyName] : [],
        sortMethodArray = firstSort ? [firstSortMethod] : [];

    for (let [keyName, sortMethod] of defaultSort) {
        if (keyName === firstSortKeyName) continue;
        keyNameArray = [...keyNameArray, keyName];
        sortMethodArray = [...sortMethodArray, sortMethod];
    }
    return (0, _lodash.orderBy)(array, keyNameArray, sortMethodArray);
}

/**
 * 排序
 * @param data
 * @param sort
 * @returns {*}
 */
let sortServerAnalysis = exports.sortServerAnalysis = (data, sort) => {
    console.time('sortResult');
    if (!data) return data;
    for (let dataItem of data) {
        dataItem.result = getOrderSort(dataItem.result, sort);
    }
    console.timeEnd('sortResult');
    return data;
};
/**
 * 根据标签id去查询标签的俩表
 * @param tagModelName
 * @param tagIds
 * @return {*}
 */
let getTagListByTagModel = exports.getTagListByTagModel = (tagModelName, tagIds) => {
    return getListByModelName(tagModelName, {
        attributes: {
            exclude: ['tagType', 'mergeRule', 'createdAt', 'updatedAt', 'status']
        },
        where: {
            id: {
                $in: tagIds
            }
        },
        raw: true
    });
};

let getTagValueByTagValueModel = exports.getTagValueByTagValueModel = (tagValueModelName, tagValueIds) => {
    return getListByModelName(tagValueModelName, {
        where: {
            id: {
                $in: tagValueIds
            }
        },
        raw: true
    });
};
/**
 * 根据标签id去查询标签值的列表
 * @param tagValueModelName
 * @param tagIds
 * @return {*}
 */
let getTagValueByTagValueModelThroughTagIds = exports.getTagValueByTagValueModelThroughTagIds = (tagValueModelName, tagIds) => {
    return getListByModelName(tagValueModelName, {
        attributes: ['id', 'name', 'remark', 'displaySequence'],
        where: {
            tagId: {
                $in: tagIds
            }
        },
        raw: true
    });
};
/**
 * 根据标签组id过滤出对应得标签分析结果
 * 同时add tagName tagValueName
 *
 * @param srcData
 * @param modelName
 * @param srcTagList
 * @param tagId
 * @param secTagId
 * @returns {*}
 */
let filterAnalysis = exports.filterAnalysis = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (srcData, modelName, srcTagList, tagId, secTagId) {

        let data = srcData;
        if (!data || data.length === 0) return [];
        let tagModelName = `${(0, _lodash.capitalize)(modelName)}PartyTag`;
        let tagValueModelName = `${(0, _lodash.capitalize)(modelName)}PartyTagValue`;
        let tagList = [];
        if (srcTagList && srcTagList.length > 0 && !tagId) {
            tagList = srcTagList;
        } else {
            tagList = yield getTagListByTagModel(tagModelName, [tagId, secTagId].filter(function (c) {
                return c;
            }));
        }

        data = data.filter(function (nD) {
            return (0, _lodash.find)(tagList, function (tD) {
                return tD.id === nD.tagId;
            });
        });

        let tagValueListNameMap = {},
            tagValueListRemarkMap = {},
            tagValueListDisplaySequenceMap = {};
        let tagValueList = yield getTagValueByTagValueModelThroughTagIds(tagValueModelName, [...data.map(function (d) {
            return d.tagId;
        }), secTagId].filter(function (c) {
            return c;
        }));
        /**
         * 添加标签值的map关系 不宜使用find
         */
        if (tagValueList) {
            tagValueList.forEach(function (item) {
                tagValueListNameMap[item.id] = item.name;
                tagValueListRemarkMap[item.id] = item.remark;
                tagValueListDisplaySequenceMap[item.id] = item.displaySequence;
            });
        }
        console.time('convertName');
        for (let dataItem of data) {
            let tagIdNameConcat = (0, _lodash.find)(tagList, function (tagItem) {
                return tagItem.id === dataItem.tagId;
            });
            /**
             * 添加tagName
             */
            if (!tagIdNameConcat) continue;
            dataItem['tagName'] = tagIdNameConcat['name'];
            dataItem['tagGroupId'] = tagIdNameConcat['tagGroupId'];
            dataItem['tagGroupName'] = tagIdNameConcat['tagGroupName'];
            dataItem['chartType'] = tagIdNameConcat['chartType'];
            dataItem['tagRemark'] = tagIdNameConcat['remark'];

            /**
             * 添加secTagName
             */
            if (secTagId) {
                let secTagIdFind = (0, _lodash.find)(tagList, function (tagItem) {
                    return tagItem.id === dataItem.secTagId;
                });
                if (secTagIdFind) dataItem['secTagName'] = secTagIdFind['name'];
            }

            if (!dataItem.result || dataItem.result.length === 0) continue;

            dataItem.result.forEach(function (resItem) {
                resItem['tagValueName'] = tagValueListNameMap[resItem.tagValueId];
                resItem['tagValueRemark'] = tagValueListRemarkMap[resItem.tagValueId];
                resItem['displaySequence'] = tagValueListDisplaySequenceMap[resItem.tagValueId];
                if (resItem.secTagValueId) {
                    resItem['secTagValueName'] = tagValueListNameMap[resItem.secTagValueId];
                    resItem['secTagValueRemark'] = tagValueListRemarkMap[resItem.secTagValueId];
                }
            });
        }
        console.timeEnd('convertName');
        return data;
    });

    return function filterAnalysis(_x4, _x5, _x6, _x7, _x8) {
        return _ref2.apply(this, arguments);
    };
})();

function convertArrayToMapObject(array, key, value) {
    let map = {};
    array.forEach(item => {
        if (item[key]) {
            map[item[key]] = item[value];
        }
    });
    return map;
}

/**
 * 新建
 * @param model
 * @returns {model}
 */
let create = exports.create = model => {
    return _models.InsightInfo.create(model);
};let getAllInsightListBySegmentId = exports.getAllInsightListBySegmentId = segmentId => {
    return _models.InsightInfo.findAll({
        attributes: ['id', 'category', 'dataSourceId', 'status', 'errorCode'],
        where: {
            segmentId
            // status: InsightStatus.Normal
        },
        raw: true
    });
};

/**
 * 获取上传人群的字段映射列表
 * @param dataSourceId
 * @return {*}
 */
let getFieldList = exports.getFieldList = dataSourceId => {
    let where = {
        status: Status.Normal,
        category: dataSourceId ? DataSourceCategory.ThirdParty : DataSourceCategory.FirstParty
    };
    if (dataSourceId) {
        (0, _assign2.default)(where, { dataSourceId });
    }

    return _models.InsightField.findAll({
        where,
        order: [['colNum', 'ASC']],
        raw: true
    });
};
/**
 * 生成所有标签的zip
 * @param data
 * @param segmentInfo
 * @param coverage
 * @param dataSourceId
 * @returns {Promise}
 */
let generateReportFile = exports.generateReportFile = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (data, segmentInfo, coverage, dataSourceId) {

        let srcExcelData = (0, _lodash.groupBy)(data, 'tagGroupName');
        let tagGroupNameList = (0, _keys2.default)(srcExcelData);

        let insightField = yield getFieldList(dataSourceId);

        let insightFieldMap = {};
        insightField.forEach(function (item) {
            insightFieldMap[item.id] = item.name;
        });

        for (let tagGroupName of tagGroupNameList) {
            let tagGroupData = srcExcelData[tagGroupName];
            let workbook = new _exceljs2.default.Workbook();
            let filename = _config2.default.fileDir + `/${tagGroupName}.xlsx`;
            for (let tagData of tagGroupData) {
                let tagXlsx = [[_insightDownload.DIMENSION_CHINESE].concat(insightField.map(function (i) {
                    return i.name;
                }))];
                if (tagData.result && tagData.result.length > 0) {
                    tagData.result.forEach(function (res) {
                        let tempRow = [res.tagValueName];
                        insightField.forEach(function (insightFieldItem) {
                            let tMetric = insightFieldMap[insightFieldItem.id];
                            if (tMetric) {
                                let tempVal = getDisplayByMetrics(res[insightFieldItem.id], insightFieldItem.colType);
                                tempRow.push(tempVal);
                            }
                        });
                        tagXlsx.push(tempRow);
                    });
                }
                let tagSheet = workbook.addWorksheet(tagData.tagName && tagData.tagName.replace(/[\/\\\:\?\*\[\]\']/g, ''));
                tagSheet.addRows(tagXlsx);
            }
            let st = _fs2.default.createWriteStream(filename);
            yield workbook.xlsx.write(st);
        }
        return generateReportZipOrTar(tagGroupNameList.map(function (name) {
            return `${name}.xlsx`;
        }));
    });

    return function generateReportFile(_x13, _x14, _x15, _x16) {
        return _ref5.apply(this, arguments);
    };
})();

/**
 * 生成zip
 * @param nameList
 * @param zipName
 * @returns {Promise}
 */
let generateReportZipOrTar = exports.generateReportZipOrTar = (nameList, zipName) => {
    return new _promise2.default(resolve => {
        let archive = (0, _archiver2.default)('zip', {});
        zipName = zipName || _path2.default.join(_config2.default.fileDir, 'report.zip');
        let output = _fs2.default.createWriteStream(zipName);
        output.on('close', function () {
            console.log(archive.pointer() + ' total bytes');
            console.log('archiver has been finalized and the output file descriptor has closed.');
            resolve(zipName);
        });
        output.on('err', function (err) {
            console.log(err);
            console.log('archiver has been finalized and the output file descriptor has closed.');
            resolve();
        });
        archive.pipe(output);
        for (let name of nameList) {
            console.log(_path2.default.join(_config2.default.fileDir, name));
            archive.append(_fs2.default.createReadStream(_path2.default.join(_config2.default.fileDir, name)), { name: name });
        }
        archive.finalize();
    });
};

/**
 * 生成zip
 * @param nameList
 * @param zipName
 * @returns {Promise}
 */
let generateReportZip = exports.generateReportZip = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (nameList, zipName) {
        let zip = new _jszip2.default();
        zipName = zipName || _config2.default.fileDir + '/report.zip';
        for (let name of nameList) {
            let filename = _config2.default.fileDir + `/${name}`;
            yield zip.file(name, _fs2.default.readFileSync(filename));
        }
        return new _promise2.default(function (resolve) {
            try {
                zip.generateNodeStream({
                    streamFiles: true
                }).pipe(_fs2.default.createWriteStream(zipName)).on('finish', function () {
                    resolve(zipName);
                });
            } catch (err) {
                console.log(err);
            }
        });
    });

    return function generateReportZip(_x17, _x18) {
        return _ref6.apply(this, arguments);
    };
})();

function getDisplayByMetrics(metrics, type) {
    if (type === ColType.percent) {
        let val = (Number(metrics || 0) * 100).toFixed(2);
        return (0, _is2.default)(val, NaN) ? '0' : val + '%';
    } else {
        return (0, _is2.default)(metrics, undefined) ? _insightDownload.NULL_CHINESE : Number.prototype.toFixed.call(metrics);
    }
}

/**
 * 生成XLSX报告文件
 * @param data
 * @param segmentInfo
 * @param coverage
 * @param dataSourceId
 * @param secTagId
 * @returns {*}
 */
let generateXLSXReportFile = exports.generateXLSXReportFile = (() => {
    var _ref7 = (0, _asyncToGenerator3.default)(function* (data, segmentInfo, coverage, dataSourceId, secTagId) {
        let filename = _path2.default.join(_config2.default.fileDir, `./report.xlsx`);

        let csvArray = [];

        let insightField = yield getFieldList(dataSourceId);

        let insightFieldMap = {};
        insightField.forEach(function (item) {
            insightFieldMap[item.id] = item.name;
        });

        data.forEach(function (item) {

            let tagArray = [secTagId ? [_insightDownload.MAIN_DIMENSION_CHINESE, _insightDownload.SEC_DIMENSION_CHINESE].concat(insightField.map(function (i) {
                return i.name;
            })) : [_insightDownload.DIMENSION_CHINESE].concat(insightField.map(function (i) {
                return i.name;
            }))].concat(item.result ? item.result.map(function (res) {

                let tempRow = secTagId ? [res.tagValueName, res.secTagValueName] : [res.tagValueName];

                insightField.forEach(function (insightFieldItem) {
                    if (insightFieldMap[insightFieldItem.id]) {
                        let tempVal = getDisplayByMetrics(res[insightFieldItem.id], insightFieldItem.colType);
                        tempRow.push(tempVal);
                    }
                });

                return tempRow;
            }) : ['']);

            csvArray = csvArray.concat(tagArray);
        });

        yield generateXLSX(csvArray, filename, data[0] ? data[0].tagName : 'sheet');

        return filename;
    });

    return function generateXLSXReportFile(_x19, _x20, _x21, _x22, _x23) {
        return _ref7.apply(this, arguments);
    };
})();

/**
 * 生成XLSX
 * @param array
 * @param filename
 * @param sheetName
 */
let generateXLSX = exports.generateXLSX = (() => {
    var _ref8 = (0, _asyncToGenerator3.default)(function* (array, filename, sheetName) {
        let workbook = new _exceljs2.default.Workbook();
        let worksheet = workbook.addWorksheet(sheetName && sheetName.replace(/[\/\\\:\?\*\[\]\']/g, ''), {
            pageSetup: {
                fitToPage: true,
                fitToHeight: 5,
                fitToWidth: 7
            }
        });
        worksheet.addRows(array);
        let st = _fs2.default.createWriteStream(filename);
        yield workbook.xlsx.write(st);
    });

    return function generateXLSX(_x24, _x25, _x26) {
        return _ref8.apply(this, arguments);
    };
})();

/**
 * 生成ID merge报告Excel文件
 * 包含单用户ID分析 和 重合分析
 * @param distributionData
 * @param allThroughData
 */
let generateIdReportXlsx = exports.generateIdReportXlsx = (() => {
    var _ref9 = (0, _asyncToGenerator3.default)(function* (distributionData, allThroughData) {
        let workbook = new _exceljs2.default.Workbook();
        let fileName = _path2.default.join(_config2.default.fileDir, './idReport.xlsx');
        let idMetricList = yield (0, _dataSource.IdMetricList)();

        let singleIdSheetData = [[_insightDownload.ID_TYPE_CHINESE].concat(idMetricList.map(function (item) {
            return item.name;
        }))];
        let singleIdSheet = workbook.addWorksheet(_insightDownload.SINGLE_ID_ANALYSIS_SHEET_NAME);
        distributionData.forEach(function (item) {
            let itemData = [];
            itemData.push(item.id);
            idMetricList.forEach(function (metric) {
                let metricData = (0, _helper.formatData)(item[metric.id], metric.vtype);
                itemData.push(metricData);
            });
            singleIdSheetData.push(itemData);
        });
        singleIdSheet.addRows(singleIdSheetData);

        let throughSheetData = [_through2.default.map(function (item) {
            return item.name;
        })];
        let throughSheet = workbook.addWorksheet(_insightDownload.THROUGH_ANALYSIS_SHEET_NAME);
        allThroughData.forEach(function (item) {
            let itemData = [];
            _through2.default.forEach(function (metric) {
                let metricData = (0, _helper.formatData)(item[metric.id], metric.vtype);
                if (metric.id == 'idPercentage') {
                    if (metricData == 0) {
                        metricData = '--';
                    } else {
                        metricData = `1:${metricData}`;
                    }
                }
                itemData.push(metricData);
            });
            throughSheetData.push(itemData);
        });
        throughSheet.addRows(throughSheetData);

        let stream = _fs2.default.createWriteStream(fileName);
        yield workbook.xlsx.write(stream);

        return fileName;
    });

    return function generateIdReportXlsx(_x27, _x28) {
        return _ref9.apply(this, arguments);
    };
})();
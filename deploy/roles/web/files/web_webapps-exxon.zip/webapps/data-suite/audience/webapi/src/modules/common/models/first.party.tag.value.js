'use strict';

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

var _sequelize = require('sequelize');

var _sequelize2 = _interopRequireDefault(_sequelize);

var _consts = require('../../../config/consts');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('First_party_tag_value', {
        id: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: true,
            defaultValue: null
        },
        valueOriginalId: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'value_original_id'
        },
        name: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null
        },
        tagId: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'tag_id'
        },
        valueRules: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'value_rules'
        },
        parseRules: {
            type: DataTypes.JSON,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'parse_rules',
            set: function (val) {
                try {
                    this.setDataValue('parseRules', JSON.parse((0, _stringify2.default)(val)));
                } catch (err) {
                    return null;
                }
            },
            get: function (val) {
                try {
                    return this.getDataValue(val);
                } catch (err) {
                    return null;
                }
            }
        },
        tagValueRules: {
            type: DataTypes.JSON,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'tag_value_rules',
            set: function (val) {
                try {
                    this.setDataValue('tagValueRules', JSON.parse((0, _stringify2.default)(val)));
                } catch (err) {
                    return null;
                }
            },
            get: function (val) {
                try {
                    return this.getDataValue(val);
                } catch (err) {
                    return null;
                }
            }
        },
        remark: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null
        },
        coverage: {
            type: DataTypes.INTEGER(10),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null
        },
        status: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        },
        type: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        },
        dataStatus: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _consts.Enums.TagValueStatus.Generating,
            field: 'data_status'
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'created_at'
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'updated_at'
        },
        priority: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        },
        displaySequence: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 0,
            field: 'display_sequence'
        },
        refreshTime: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            field: 'refresh_time'
        }
    }, {
        tableName: 'first_party_tag_value'
    });
};
-- 更新周期
INSERT INTO `audience`.`update_period` (`id`, `name`, `data_source_id`, `status`) VALUES ('4', '不更新', '1', '1');
INSERT INTO `audience`.`update_period` (`id`, `name`, `data_source_id`, `status`) VALUES ('3', '一月一次', '1', '1');
INSERT INTO `audience`.`update_period` (`id`, `name`, `data_source_id`, `status`) VALUES ('2', '一周一次', '1', '1');
INSERT INTO `audience`.`update_period` (`id`, `name`, `data_source_id`, `status`) VALUES ('1', '一天一次', '1', '1');
INSERT INTO `audience`.`update_period` (`id`, `name`, `data_source_id`, `status`) VALUES ('5', '自动更新', '1', '1');

-- 初始化标签组
INSERT INTO `audience`.`tag_group` (`id`, `name`, `category`,`status`) VALUES ('TTG0','其它', '1', '1') 
    ON DUPLICATE KEY UPDATE name='其它',category='1',status='1';



-- 初始化sequence
INSERT INTO `seq` VALUES ('segmentId', 1000);
INSERT INTO `seq` VALUES ('tagId', 500);
INSERT INTO `seq` VALUES ('tagGroupId', 50000);
INSERT INTO `seq` VALUES ('tagValueId', 10000);
INSERT INTO `seq` VALUES ('thirdTag', 1000);
INSERT INTO `seq` VALUES ('thirdTagValue', 50000);


-- 初始化insight_field
INSERT INTO `insight_field` (`id`, `name`, `category`, `data_source_id`, `col_num`, `col_type`, `is_default`, `record_viewable`, `status`)
VALUES
	('uv', '识别人数', 1, NULL, 1, 'number', 0, 1, 1),
	('percentage', '人群占比', 1, NULL, 2, 'percent', 0, 1, 1),
	('featurePercentage', '人群特征占比', 1, NULL, 3, 'percent', 1, 1, 1),
	('featurePercentage', '人群特征占比', 2, 1, 4, 'percent', 1, 1, 1),
	('tgi', 'TGI', 1, 1, 5, 'number', 0, 0, 1);

-- 初始化insight_info
INSERT INTO `audience`.`insight_info` (`segment_id`, `status`, `category`, `data_status`) VALUES ('TOTAL', '1', '1', '1');
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.updateSequence = exports.removeSegmentToOther = exports.isHaveChildren = exports.isDefaultGroup = exports.remove = exports.update = exports.create = exports.getSegmentCountByGroupList = exports.list = exports.constructorData = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _consts = require('../../config/consts');

var _models = require('../common/models');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let Status = _consts.Enums.Status;
let OtherStatus = _consts.Enums.OtherStatus;
let constructorData = exports.constructorData = (res, parentIdGroup) => {
    for (let item of res) {
        if (item.id && parentIdGroup[item.id]) {
            item.children = constructorData(parentIdGroup[item.id], parentIdGroup);
        }
    }
    return res;
};

let list = exports.list = where => {
    return _models.SegmentGroup.findAll({
        attributes: ['id', 'name', 'parentId', 'sequence'],
        where: {
            status: Status.Normal
        },
        order: [['sequence', 'ASC']],

        raw: true
    });
};

/**
 * 获取人群分组下的count
 * @returns {*}
 */
let getSegmentCountByGroupList = exports.getSegmentCountByGroupList = (where = {}) => {
    return _models.Segment.findAll({
        attributes: [[_models.sequelize.fn('count', '*'), 'segmentCount'], 'segmentGroupId'],
        where: (0, _assign2.default)(where, {
            status: Status.Normal
        }),
        group: ['segmentGroupId'],
        raw: true
    });
};

let create = exports.create = model => {
    return _models.SegmentGroup.create(model);
};

let update = exports.update = (id, model) => {
    return _models.SegmentGroup.update(model, {
        where: { id }
    });
};

let remove = exports.remove = id => {
    return _models.SegmentGroup.update({
        status: Status.Deleted
    }, {
        where: { id }
    });
};

/**
 * 是否是默认分组
 * @param id
 * @returns {Query|*}
 */
let isDefaultGroup = exports.isDefaultGroup = id => {
    return _models.SegmentGroup.findOne({
        where: {
            id,
            isDefault: Status.Normal
        },
        raw: true
    });
};
/**
 * 是否有子组
 * @param parentId
 * @returns {Query|*}
 */
let isHaveChildren = exports.isHaveChildren = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (parentId) {
        return _models.SegmentGroup.findOne({
            where: {
                parentId,
                status: Status.Normal
            },
            raw: true
        });
    });

    return function isHaveChildren(_x) {
        return _ref.apply(this, arguments);
    };
})();

let removeSegmentToOther = exports.removeSegmentToOther = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (segmentGroupId) {
        let otherGroup = yield _models.SegmentGroup.findOne({
            attributes: ['id'],
            where: {
                id: OtherStatus.segment
            },
            raw: true
        });
        if (otherGroup && otherGroup.id == segmentGroupId) {
            throw new _errors2.default.SegmentGroupCannotDelete();
        }
        if (otherGroup) {
            yield _models.Segment.update({
                segmentGroupId: otherGroup.id
            }, {
                where: {
                    segmentGroupId
                }
            });
            return true;
        }
        return false;
    });

    return function removeSegmentToOther(_x2) {
        return _ref2.apply(this, arguments);
    };
})();

let updateSequence = exports.updateSequence = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (id, parentId, afterId) {
        let needUpdateSequence;
        if (afterId) {
            let afterRecord = yield _models.SegmentGroup.findOne({
                where: { id: afterId },
                raw: true
            });
            needUpdateSequence = afterRecord.sequence;
        } else {

            let where = {};
            if (parentId) {
                where = {
                    parentId
                };
            } else {
                where = {
                    parentId: {
                        $eq: null
                    }
                };
            }
            let maxSequenceRecord = yield _models.SegmentGroup.findOne({
                where,
                order: [['sequence', 'DESC']],
                raw: true
            });
            console.log(maxSequenceRecord);
            if (!maxSequenceRecord) {
                let parentIdRecord = yield _models.SegmentGroup.findOne({
                    where: {
                        id: parentId
                    },
                    raw: true
                });
                needUpdateSequence = parentIdRecord.sequence + 1;
            } else {
                needUpdateSequence = maxSequenceRecord.sequence + 1;
            }
        }

        let instance = yield _models.SegmentGroup.findAll({
            where: {
                sequence: { $gte: needUpdateSequence }
            }
        });

        if (instance && instance.length > 0) {
            for (let instanceItem of instance) {
                yield instanceItem.increment('sequence');
            }
        }
        return needUpdateSequence;
    });

    return function updateSequence(_x3, _x4, _x5) {
        return _ref3.apply(this, arguments);
    };
})();
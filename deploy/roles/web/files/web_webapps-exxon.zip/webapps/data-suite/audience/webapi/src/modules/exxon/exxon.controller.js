'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.tagBuyerCounts = exports.channelBuyerCount = exports.buyerCountRecord = exports.loyalCategoryDataList = exports.categoryDataList = exports.productList = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _lodash = require('lodash');

var _helper = require('./../common/util/helper');

var _exxon = require('./exxon.service');

var exxonService = _interopRequireWildcard(_exxon);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let productList = exports.productList = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = yield exxonService.productList();

            // data = await exxonService.categoryData("美孚超级");
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function productList(_x) {
        return _ref.apply(this, arguments);
    };
})();

let categoryDataList = exports.categoryDataList = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null,
            categoriesDic = {},
            productsCount = null;
        let error = null;

        try {
            data = yield exxonService.categorieDatas();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function categoryDataList(_x2) {
        return _ref2.apply(this, arguments);
    };
})();

let loyalCategoryDataList = exports.loyalCategoryDataList = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null,
            categoriesDic = {},
            productsCount = null;
        let error = null;

        try {
            data = yield exxonService.loyalCategorieDatas();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function loyalCategoryDataList(_x3) {
        return _ref3.apply(this, arguments);
    };
})();

let buyerCountRecord = exports.buyerCountRecord = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;

        let { startDate, endDate, category, product, step } = ctx.request.query;

        try {
            data = yield exxonService.buyerCountRecord(startDate, endDate, category, product, step);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function buyerCountRecord(_x4) {
        return _ref4.apply(this, arguments);
    };
})();

let channelBuyerCount = exports.channelBuyerCount = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;

        let { startDate, endDate, category, product } = ctx.request.query;

        try {
            data = yield exxonService.channelBuyerCount(startDate, endDate, category, product);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function channelBuyerCount(_x5) {
        return _ref5.apply(this, arguments);
    };
})();

let tagBuyerCounts = exports.tagBuyerCounts = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;

        try {
            data = yield exxonService.tagBuyerCounts();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function tagBuyerCounts(_x6) {
        return _ref6.apply(this, arguments);
    };
})();
CREATE TABLE `audience`.`report_task` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `key_id` VARCHAR(255) NULL,
  `key_type` TINYINT(4) NOT NULL DEFAULT 1,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  `task_id` VARCHAR(255) NULL,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`));

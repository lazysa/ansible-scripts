/*
Navicat MySQL Data Transfer

Source Server         : dev
Source Server Version : 50711
Source Host           : cc-mysql-test.c5s7vgxpiybm.rds.cn-north-1.amazonaws.com.cn:3306
Source Database       : audience

Target Server Type    : MYSQL
Target Server Version : 50711
File Encoding         : 65001

Date: 2017-09-15 15:45:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for operator
-- ----------------------------
DROP TABLE IF EXISTS `operator`;
CREATE TABLE `operator` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `operator_id` varchar(64) DEFAULT NULL COMMENT '操作符id',
  `name` varchar(128) DEFAULT NULL COMMENT '名称',
  `status` tinyint(4) DEFAULT '1' COMMENT '状态 1:正常 0：删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of operator
-- ----------------------------
INSERT INTO `operator` VALUES ('1', '$include', '包含', '1');
INSERT INTO `operator` VALUES ('2', '$exclude', '不包含', '1');
INSERT INTO `operator` VALUES ('3', '$ne', '不等于', '1');
INSERT INTO `operator` VALUES ('4', '$skip', '不限', '1');
INSERT INTO `operator` VALUES ('5', '$gt', '大于', '1');
INSERT INTO `operator` VALUES ('6', '$gte', '大于等于', '1');
INSERT INTO `operator` VALUES ('7', '$optionHasSkip', '单选(包含不限)', '1');
INSERT INTO `operator` VALUES ('8', '$optionNoSkip', '单选(不含不限)', '1');
INSERT INTO `operator` VALUES ('9', '$eq', '等于', '1');
INSERT INTO `operator` VALUES ('10', '$offset', '动态范围', '1');
INSERT INTO `operator` VALUES ('11', '$in', '多选', '1');
INSERT INTO `operator` VALUES ('12', '$range', '范围', '1');
INSERT INTO `operator` VALUES ('13', '$range', '固定范围', '1');
INSERT INTO `operator` VALUES ('14', '$lte', '结束于', '1');
INSERT INTO `operator` VALUES ('15', '$endWith', '结尾为', '1');
INSERT INTO `operator` VALUES ('16', '$range', '介于', '1');
INSERT INTO `operator` VALUES ('17', '$startWith', '开头为', '1');
INSERT INTO `operator` VALUES ('18', '$gte', '起始于', '1');
INSERT INTO `operator` VALUES ('19', '$all', '完全匹配', '1');
INSERT INTO `operator` VALUES ('20', '$lt', '小于', '1');
INSERT INTO `operator` VALUES ('21', '$lte', '小于等于', '1');
INSERT INTO `operator` VALUES ('22', '$topDomain', '一级域名为', '1');
INSERT INTO `operator` VALUES ('23', '$domain', '域名为', '1');
INSERT INTO `operator` VALUES ('24', '$regexp', '正则表达式', '1');
SET FOREIGN_KEY_CHECKS=1;

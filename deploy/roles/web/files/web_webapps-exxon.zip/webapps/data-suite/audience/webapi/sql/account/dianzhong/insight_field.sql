/*
Navicat MySQL Data Transfer

Source Server         : 192.168.10.40_3306
Source Server Version : 50711
Source Host           : 192.168.10.40:3306
Source Database       : audience

Target Server Type    : MYSQL
Target Server Version : 50711
File Encoding         : 65001

Date: 2017-04-20 15:12:26
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for insight_field
-- ----------------------------
DROP TABLE IF EXISTS `insight_field`;
CREATE TABLE `insight_field` (
  `id` varchar(255) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `category` int(10) NOT NULL,
  `data_source_id` int(10) DEFAULT NULL,
  `col_num` int(10) NOT NULL,
  `col_type` varchar(255) NOT NULL DEFAULT 'number',
  `is_default` int(10) NOT NULL DEFAULT '0',
  `record_viewable` tinyint(4) NOT NULL DEFAULT '1',
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`col_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of insight_field
-- ----------------------------
INSERT INTO `insight_field` VALUES ('uv', '识别人数', '1', null, '1', 'number', '0', '1', '1');
INSERT INTO `insight_field` VALUES ('percentage', '人群占比', '1', null, '2', 'percent', '1', '1', '1');
INSERT INTO `insight_field` VALUES ('featurePercentage', '人群特征占比', '1', null, '3', 'percent', '0', '1', '1');
INSERT INTO `insight_field` VALUES ('featurePercentage', '人群特征占比', '2', '1', '4', 'percent', '1', '1', '1');
INSERT INTO `insight_field` VALUES ('tgi', 'TGI', '1', '1', '5', 'number', '0', '0', '1');
SET FOREIGN_KEY_CHECKS=1;

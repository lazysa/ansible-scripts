'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.downloadValidate = exports.download = exports.crossoverSummary = exports.removeValidate = exports.remove = exports.removeSegmentBaseAuth = exports.removeSegmentAuth = exports.updateInsight = exports.update = exports.queryInsight = exports.query = exports.upload = exports.create = exports.updateCampaignAndSite = exports.createCampaign = exports.createSite = exports.pages = exports.firstList = exports.firstAndUploadList = exports.normalList = exports.allList = exports.uploadFieldList = exports.segmentUploadList = exports.firstAllList = undefined;

var _is = require('babel-runtime/core-js/object/is');

var _is2 = _interopRequireDefault(_is);

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _extends2 = require('babel-runtime/helpers/extends');

var _extends3 = _interopRequireDefault(_extends2);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

/**
 * 人群删除验证中间件
 * @param ctx
 * @param next
 * @return {Promise.<void>}
 */
let removeSegmentAuth = exports.removeSegmentAuth = (() => {
    var _ref20 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        try {
            let id = ctx.params.id;
            let usedSegmentList = yield segmentService.isUploadSegmentUsedBySegment(id, 'segmentId');
            if (usedSegmentList && usedSegmentList.length > 0) {
                throw new _errors2.default.SegmentUsed();
            }
            let analyticsUsed = yield _api.AnalyticsWebApi.isSegmentUsedByAnalytics(id);
            if (analyticsUsed && (analyticsUsed.campaign && analyticsUsed.campaign.length > 0 || analyticsUsed.site && analyticsUsed.site.length > 0)) {
                throw new _errors2.default.SegmentCampaignOrSiteUsed();
            }
            yield next();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function removeSegmentAuth(_x19, _x20) {
        return _ref20.apply(this, arguments);
    };
})();

/**
 * 人群删除验证中间件
 * @param ctx
 * @param next
 * @return {Promise.<void>}
 */


let removeSegmentBaseAuth = exports.removeSegmentBaseAuth = (() => {
    var _ref21 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        try {
            let id = ctx.params.id;
            let exportObj = yield segmentService.shouldRemoveSegment(id);
            if (exportObj) {
                throw new _errors2.default.SegmentExportExist();
            }
            yield next();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function removeSegmentBaseAuth(_x21, _x22) {
        return _ref21.apply(this, arguments);
    };
})();

var _consts = require('../../config/consts');

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _uuid = require('uuid');

var _uuid2 = _interopRequireDefault(_uuid);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _stream = require('stream');

var _lodash = require('lodash');

var _helper = require('../common/util/helper');

var _permission = require('../common/util/permission.util');

var _segmentService = require('./segment.service.js');

var segmentService = _interopRequireWildcard(_segmentService);

var _fileToken = require('../fileToken/fileToken.service');

var _segmentGroup = require('../segmentGroup/segmentGroup.service');

var _api = require('../common/api');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _index = require('../common/models/index');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
    Status, ReportUpdatePeriod, SegmentUpdatePeriod, TagUpdatePeriod, SegmentType, DefaultSiteSegmentType, DataSourceCategory, IdMergeStatus, SegmentStatus
} = _consts.Enums;

let firstAllList = exports.firstAllList = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = yield segmentService.firstAllList();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function firstAllList(_x) {
        return _ref.apply(this, arguments);
    };
})();

let segmentUploadList = exports.segmentUploadList = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {

            let { where } = ctx.state;
            data = yield segmentService.getRulesOfUploadSegment(where);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function segmentUploadList(_x2) {
        return _ref2.apply(this, arguments);
    };
})();
/**
 * 人群上传自字段
 * @param ctx
 * @returns {{status}|{data, status}|*}
 */
let uploadFieldList = exports.uploadFieldList = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = [];
        let error = null;
        try {
            let mappingUserIdList = yield segmentService.getMappingUserIdList();
            let firstPartyUserIdType = yield _api.DataAssetsWebApi.getFirstPartyUserIdType();
            data = firstPartyUserIdType.map(function ({ userIdTypeName, userIdTypeDesc, encryptType }) {
                return {
                    userIdTypeName,
                    userIdTypeDesc,
                    encryptType,
                    dataSourceList: function () {
                        let arr = [{
                            category: DataSourceCategory.FirstParty
                        }];
                        mappingUserIdList.forEach(function ({ firstUserIdTypeName, thirdUserIdTypeName, dataSourceId }) {
                            if (firstUserIdTypeName === userIdTypeName) arr.push({
                                category: DataSourceCategory.ThirdParty,
                                dataSourceId,
                                thirdUserIdTypeName
                            });
                        });
                        return arr;
                    }()
                };
            });
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function uploadFieldList(_x3) {
        return _ref3.apply(this, arguments);
    };
})();

let allList = exports.allList = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let { where } = ctx.state;
            let segmentGroupId = ctx.params.segmentGroupId;
            data = yield segmentService.allList(segmentGroupId, where);
            let insightList = yield segmentService.queryInsight(data.map(function (z) {
                return z.id;
            }));
            let insightGroup = (0, _lodash.groupBy)(insightList, 'segmentId');
            data.forEach(function (item) {
                item.insight = insightGroup[item.id];
            });
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function allList(_x4) {
        return _ref4.apply(this, arguments);
    };
})();

let normalList = exports.normalList = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let { where } = ctx.state;
            let segmentGroupId = ctx.params.segmentGroupId;
            data = yield segmentService.normalList(segmentGroupId, where);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function normalList(_x5) {
        return _ref5.apply(this, arguments);
    };
})();

let firstAndUploadList = exports.firstAndUploadList = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let { where } = ctx.state;
            let { keywords } = ctx.request.query;
            let segmentGroupId = ctx.params.segmentGroupId;
            let srcSegmentListData = yield segmentService.firstAndUploadList(segmentGroupId, where, keywords);
            let defaultList = yield segmentService.getAnalyticsReportDefaultSegmentList();
            data = srcSegmentListData.map(function (item) {
                return (0, _extends3.default)({}, item, {
                    isCampaignDefault: defaultList.find(function (z) {
                        return z.segmentId === item.id && z.isCampaignDefault === Status.Normal;
                    }) ? Status.Normal : Status.Deleted,
                    isSiteDefault: defaultList.find(function (z) {
                        return z.segmentId === item.id && z.isSiteDefault === Status.Normal;
                    }) ? Status.Normal : Status.Deleted
                });
            });
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function firstAndUploadList(_x6) {
        return _ref6.apply(this, arguments);
    };
})();

let firstList = exports.firstList = (() => {
    var _ref7 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let { where } = ctx.state;
            let { keywords } = ctx.request.query;
            let segmentGroupId = ctx.params.segmentGroupId;
            data = yield segmentService.firstList(segmentGroupId, where, keywords);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function firstList(_x7) {
        return _ref7.apply(this, arguments);
    };
})();

let pages = exports.pages = (() => {
    var _ref8 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let segmentGroupId = ctx.params.segmentGroupId;
            let query = ctx.request.query;
            let offset = query.pageSize * (query.pageIndex - 1);
            let limit = +query.pageSize;
            let { keywords, sort } = query;
            let { where } = ctx.state;
            if (segmentGroupId !== 'all') {
                (0, _assign2.default)(where, {
                    segmentGroupId
                });
            } else {
                let allSegmentGroupList = yield (0, _segmentGroup.list)();
                (0, _assign2.default)(where, {
                    segmentGroupId: {
                        $in: allSegmentGroupList.map(function (z) {
                            return z.id;
                        })
                    }
                });
            }
            where = segmentService.getWhere(where, keywords, sort);

            let conditions = {
                attributes: {
                    exclude: ['updatedAt', 'created_at', 'updated_at']
                },
                offset,
                limit,
                where,
                order: sort ? [[sort.replace(/^-/, ''), /^-/.test(sort) ? 'DESC' : 'ASC'], ['createdAt', 'DESC']] : [['createdAt', 'DESC']],
                raw: true
            };
            let { rows: list, count: total } = yield segmentService.pages(conditions);
            /**
             * 添加附加的信息
             */
            if (list && list.length > 0) {
                let segmentInsightList = yield segmentService.queryInsight(list.map(function (item) {
                    return item.id;
                }));
                segmentInsightList = (0, _lodash.groupBy)(segmentInsightList, 'segmentId');

                for (let item of list) {
                    try {
                        item['segmentRules'] = JSON.parse(item['segmentRules']);
                        item['insight'] = segmentInsightList[item.id] || [];
                    } catch (err) {
                        console.log(item.id);
                        console.log(err);
                    }
                }
            }
            let map = yield segmentService.appendSegmentRulesMap();
            data = {
                total: total,
                list: list,
                map: map,
                pageSize: query.pageSize,
                pageIndex: query.pageIndex
            };
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function pages(_x8) {
        return _ref8.apply(this, arguments);
    };
})();

/**
 * 创建默认站点人群
 * @param ctx
 * @returns {{status}|{data, status}|*}
 */
let createSite = exports.createSite = (() => {
    var _ref9 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {

            let { teamIds, privateTeamId } = ctx.state.actionInfo;
            let body = ctx.request.body;
            data = yield segmentService.createDefaultSegmentByDimension(body, 'Site');
            yield (0, _permission.createTeamResourceId)('segment', privateTeamId, data.map(function (item) {
                return item.id;
            }));
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function createSite(_x9) {
        return _ref9.apply(this, arguments);
    };
})();

/**
 * 新建analytics 的活动人群
 * @param ctx
 * @returns {{status}|{data, status}|*}
 */
let createCampaign = exports.createCampaign = (() => {
    var _ref10 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = [];
        let error = null;
        try {
            let { teamIds, privateTeamId } = ctx.state.actionInfo;
            let body = ctx.request.body;
            data = yield segmentService.createDefaultSegmentByDimension(body, 'Campaign');
            yield (0, _permission.createTeamResourceId)('segment', privateTeamId, data.map(function (item) {
                return item.id;
            }));
        } catch (ex) {
            console.log(ex);
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function createCampaign(_x10) {
        return _ref10.apply(this, arguments);
    };
})();

/**
 * 更新活动
 * @param ctx
 * @returns {{status}|{data, status}|*}
 */
let updateCampaignAndSite = exports.updateCampaignAndSite = (() => {
    var _ref11 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = [];
        let error = null;
        try {
            let body = ctx.request.body;
            let { segment, name, expires, status, insight } = body;
            if (!segment || segment.length <= 0) {
                throw new _errors2.default.SegmentIdNotExist();
            }
            let model = {
                expires,
                updatePeriod: status ? SegmentUpdatePeriod.day : SegmentUpdatePeriod.motionless
            };
            let updateSegmentType = ctx.path.match(/\/([^\/]+)$/);
            console.log(updateSegmentType);

            let DefaultSegmentType = updateSegmentType ? _consts.Enums[`Default${(0, _lodash.capitalize)(updateSegmentType[1])}SegmentType`] : {};
            console.log(`Default${(0, _lodash.capitalize)(updateSegmentType[1])}SegmentType`);

            for (let _ref12 of segment) {
                let { id, type } = _ref12;

                let tempSegmentModel = (0, _assign2.default)({
                    name: `${name}_${DefaultSegmentType[type]}`
                }, model);
                yield segmentService.update(id, tempSegmentModel);
                yield segmentService.updateTagUpdatePeriodBySegmentId(id, (0, _assign2.default)({ name }, model));
                if (id && insight && Array.isArray(insight)) {
                    yield segmentService.updateInsightList(id, insight, false, model.updatePeriod, model.expires);
                }
            }
            data = segment;
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function updateCampaignAndSite(_x11) {
        return _ref11.apply(this, arguments);
    };
})();

function getAfterThreeDay() {
    return (0, _moment2.default)(_moment2.default.utc().add(2, 'day').format('YYYY-MM-DD')).toDate();
}

function getAfterDay() {
    return (0, _moment2.default)(_moment2.default.utc().add(1, 'day').format('YYYY-MM-DD')).toDate();
}

/**
 * 新建人群
 * @param ctx
 * @returns {{status}|{data, status}|*}
 */
let create = exports.create = (() => {
    var _ref13 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let { name } = body;
            let { privateTeamId } = ctx.state.actionInfo;
            if (body.isForever) {
                body.expires = _helper.FOREVER_TIME;
            }
            if (body && body.type === SegmentType.Lookalike) {
                body.updatePeriod = SegmentUpdatePeriod.motionless;
                body.expires = getAfterDay();
                console.log(body.expires);
            }
            /**
             * TODO segmentRules的includes参数限制
             * @type {body}
             */

            if (body && body.segmentRules && body.segmentRules.fileRules && body.type === SegmentType.Upload) {
                /**
                 * 上传s3文件
                 */
                body.segmentRules.fileRules = yield segmentService.uploadSegment(body.segmentRules.fileRules);

                /**
                 * 新建上传人群的对应的内置标签 标签值
                 * 入库 更细周期为一天一次 过期时间三天后
                 * 不入库 更新周期是不更新
                 *
                 */
                let inStorage = body.segmentRules.fileRules.inStorage;
                body = (0, _assign2.default)(body, uploadSegmentGetReportExpires(inStorage));

                body.segmentRules.firstPartyRules = yield segmentService.createUploadSegmentTagAndTagValue(name, body.segmentRules.fileRules.flag, inStorage, body.updatePeriod, body.expires);
            }

            data = yield segmentService.create(body);
            //新建人群任务
            yield segmentService.addReportSegmentTask(data.id);
            if (data.id && body.insight && Array.isArray(body.insight) && body.insight.length > 0) {
                body.insight.forEach((() => {
                    var _ref14 = (0, _asyncToGenerator3.default)(function* (item) {
                        let insightRecord = yield segmentService.createInsightModel({
                            segmentId: data.id,
                            category: item.category,
                            dataSourceId: item.dataSourceId,
                            updatePeriod: body.insightUpdatePeriod,
                            expires: body.insightIsForever ? _helper.FOREVER_TIME : body.insightExpires
                        });
                        let insightInstance = yield insightRecord.reload();
                        //新建洞察任务
                        yield segmentService.addReportInsightTask(insightInstance.dataValues.id);
                    });

                    return function (_x13) {
                        return _ref14.apply(this, arguments);
                    };
                })());
            }

            if (body.isOpenIdMerge) {
                let idMergeModel = {
                    segmentId: data.id,
                    updatePeriod: body.idMergeUpdatePeriod,
                    expires: body.idMergeIsForever ? _helper.FOREVER_TIME : body.idMergeExpires
                };
                yield segmentService.createIdMergeReport(idMergeModel);
            }

            if (body.isOpenCampaignReport) {
                let campaignReportModel = {
                    segmentId: data.id
                };
                yield segmentService.createCampaignReport(campaignReportModel);
            }
            yield (0, _permission.createTeamResourceId)('segment', privateTeamId, data.id);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function create(_x12) {
        return _ref13.apply(this, arguments);
    };
})();

/**
 *
 * @param ctx
 * @returns {{status}|{data, status}|*}
 */
let upload = exports.upload = (() => {
    var _ref15 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let file = body.files.file;
            let filePath = 'segment-' + _uuid2.default.v1() + _path2.default.extname(file.name);
            _fs2.default.renameSync(file.path, _path2.default.join(_config2.default.fileDir, `/${filePath}`));
            data = {
                filePath: filePath
            };
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function upload(_x14) {
        return _ref15.apply(this, arguments);
    };
})();

/**
 * 构造前端报告的返回格式
 * @param insight
 * @param idMergeReport
 * @return {*}
 */
function getReportExpiresInfo(insight, idMergeReport) {
    let obj = {};
    if (idMergeReport) {
        (0, _assign2.default)(obj, {
            idMergeUpdatePeriod: idMergeReport.updatePeriod,
            idMergeExpires: idMergeReport.expires,
            idMergeIsForever: (0, _helper.dateIsForever)(idMergeReport.expires),
            isOpenIdMerge: IdMergeStatus.Normal
        });
    }
    if (insight && Array.isArray(insight) && insight.length > 0) {
        (0, _assign2.default)(obj, {
            insightUpdatePeriod: insight[0].updatePeriod,
            insightExpires: insight[0].expires,
            insightIsForever: (0, _helper.dateIsForever)(insight[0].expires)
        });
    }
    return obj;
}

/**
 * 上传人群自动构造报告的周期和有效期
 * @param inStorage
 */
function uploadSegmentGetReportExpires(inStorage) {
    return {
        updatePeriod: inStorage ? TagUpdatePeriod.day : TagUpdatePeriod.motionless,
        expires: inStorage ? getAfterThreeDay() : _helper.FOREVER_TIME,
        insightUpdatePeriod: inStorage ? ReportUpdatePeriod.day : ReportUpdatePeriod.motionless,
        insightExpires: inStorage ? getAfterThreeDay() : _helper.FOREVER_TIME,
        idMergeUpdatePeriod: inStorage ? ReportUpdatePeriod.day : ReportUpdatePeriod.motionless,
        idMergeExpires: inStorage ? getAfterThreeDay() : _helper.FOREVER_TIME
    };
}

let query = exports.query = (() => {
    var _ref16 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = {};
        let error = null;
        try {
            let id = ctx.params.id;
            data = yield segmentService.query(id);
            if (data) {
                let insight = yield segmentService.queryInsight([id]);
                insight = yield segmentService.getDataSourceDetails(insight);
                let idMergeReportRecord = yield segmentService.queryIdMergeReport([id]);
                let CampaignReportRecord = yield segmentService.queryCampaignReport([id]);
                data['insight'] = insight;
                data['isOpenCampaignReport'] = CampaignReportRecord ? CampaignReportRecord.status : Status.Deleted;
                data['isOpenIdMerge'] = idMergeReportRecord ? idMergeReportRecord.status : IdMergeStatus.Deleted;
                let segmentRules = JSON.parse(data['segmentRules']);
                data['segmentRules'] = yield segmentService.convertIdToName(segmentRules);
                data['isForever'] = (0, _helper.dateIsForever)(data.expires);

                data = (0, _assign2.default)({}, data, getReportExpiresInfo(insight, idMergeReportRecord));
            }
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function query(_x15) {
        return _ref16.apply(this, arguments);
    };
})();

let queryInsight = exports.queryInsight = (() => {
    var _ref17 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = {};
        let error = null;
        try {
            let id = ctx.params.id;
            data = yield segmentService.queryInsight([id]);
            data = yield segmentService.getDataSourceDetails(data);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function queryInsight(_x16) {
        return _ref17.apply(this, arguments);
    };
})();

/**
 * 更新人群
 * @param ctx
 * @return {Promise.<{status}|{data, status}|*>}
 */
let update = exports.update = (() => {
    var _ref18 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let id = ctx.params.id;
            if (body.isForever) {
                body.expires = _helper.FOREVER_TIME;
            }
            /**
             * 放大人群
             */
            if (body && body.type === SegmentType.Lookalike) {
                body.updatePeriod = SegmentUpdatePeriod.motionless;
                body.expires = getAfterDay();
            }
            /**
             * 判断人群规则变更，改变人群状态为生成中
             * 判断人群规则和周期是否变更，添加到report任务中
             */
            let { shouldUpdateToGenerating, shouldAddReportTask } = yield segmentService.shouldUpdateDateStatus(id, body);

            data = yield segmentService.update(id, shouldUpdateToGenerating ? (0, _extends3.default)({}, body, {
                dataStatus: SegmentStatus.Generating
            }) : body);
            //判断是否添加人群任务
            if (shouldAddReportTask) yield segmentService.addReportSegmentTask(id);

            if (id && body.insight && Array.isArray(body.insight)) {
                /**
                 * 改变洞察报告
                 */
                yield segmentService.updateInsightList(id, body.insight, shouldUpdateToGenerating, body.insightUpdatePeriod, body.insightIsForever ? _helper.FOREVER_TIME : body.insightExpires);
            }
            if (id && body.hasOwnProperty('isOpenIdMerge')) {
                /**
                 * 改变idMerge报告
                 */
                yield segmentService.updateIdMergeReport(id, body.isOpenIdMerge, shouldUpdateToGenerating, body.idMergeUpdatePeriod, body.idMergeIsForever ? _helper.FOREVER_TIME : body.idMergeExpires);
            }

            if (id && body.hasOwnProperty('isOpenCampaignReport')) {
                /**
                 * 改变活动报告
                 */
                yield segmentService.updateCampaignReport(id, body.isOpenCampaignReport);
            }
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function update(_x17) {
        return _ref18.apply(this, arguments);
    };
})();

/**
 * 手动更新按钮
 * @param ctx
 * @return {{status}|{data, status}|*}
 */
let updateInsight = exports.updateInsight = (() => {
    var _ref19 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let segmentId = ctx.params.segmentId;
            let { category, dataSourceId } = body;
            for (let item of segmentId.split(',')) {
                data = yield segmentService.updateInsight(item, category, dataSourceId);
            }
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function updateInsight(_x18) {
        return _ref19.apply(this, arguments);
    };
})();let remove = exports.remove = (() => {
    var _ref22 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let id = ctx.params.id;
            let { privateTeamId } = ctx.state.actionInfo;
            data = yield segmentService.remove(id);
            data = yield segmentService.removeInsightBySegmentId(id);
            data = yield segmentService.removeIdMergeBySegmentId(id);
            data = yield segmentService.removeCampaignReportBySegmentId(id);
            yield segmentService.addReportSegmentTask(id);
            yield (0, _permission.removeTeamResourceId)('segment', privateTeamId, id);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function remove(_x23) {
        return _ref22.apply(this, arguments);
    };
})();

let removeValidate = exports.removeValidate = (() => {
    var _ref23 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let id = ctx.params.id;
            let analyticsUsed = yield _api.AnalyticsWebApi.isSegmentUsedByAnalytics(id);
            let segmentUsedList = yield segmentService.isUploadSegmentUsedBySegment(id, 'segmentId');
            data = (0, _assign2.default)({ segment: segmentUsedList }, analyticsUsed);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function removeValidate(_x24) {
        return _ref23.apply(this, arguments);
    };
})();

/**
 * 人群交叉
 * @param ctx
 * @return {Promise.<{status}|{data, status}|*>}
 */
let crossoverSummary = exports.crossoverSummary = (() => {
    var _ref24 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let segmentIds = ctx.request.body;
            data = yield _api.ReportApi.getCrossoverSummary(segmentIds);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function crossoverSummary(_x25) {
        return _ref24.apply(this, arguments);
    };
})();

let download = exports.download = (() => {
    var _ref25 = (0, _asyncToGenerator3.default)(function* (ctx) {

        try {
            let segmentId = ctx.params.segmentId;
            let { token } = ctx.request.query;
            let segmentInfo = yield segmentService.query(segmentId);
            ctx.res.connection.setTimeout(0);
            if (!segmentInfo) {
                throw new _errors2.default.ReportNotExistFile();
            }

            let segmentRules = JSON.parse(segmentInfo.segmentRules);

            if (segmentRules && segmentRules.fileRules && segmentRules.fileRules.filePath && (0, _is2.default)(segmentRules.fileRules.inStorage, 0)) {
                /**
                 * 自己上传的人群文件
                 * @type {*|string}
                 */
                ctx.attachment(`${segmentId}.csv`);
                return ctx.body = _fs2.default.createReadStream(_path2.default.join(_config2.default.fileDir, `/${segmentRules.fileRules.filePath}`));
            } else {
                /**
                 * 调用接口下载任务文件
                 */
                ctx.attachment(`${segmentId}.zip`);
                // let token = await segmentService.download({segmentId});
                // return ctx.body = ctx.res.pipe(segmentService.download({segmentId}));
                if (!token) throw new _errors2.default.ReportNotExistFile();
                return ctx.redirect(`${_config2.default.reportDownloadApiPath}/${token}`);
            }

            // if (!fs.existsSync(fileName)) {
            //     throw new errors.ReportNotExistFile();
            // }
            // data = await getToken(fileName);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        // ctx.body = wrap(null,data);
    });

    return function download(_x26) {
        return _ref25.apply(this, arguments);
    };
})();

let downloadValidate = exports.downloadValidate = (() => {
    var _ref26 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = true;
        try {
            let segmentId = ctx.params.segmentId;
            let segmentInfo = yield segmentService.query(segmentId);
            // ctx.res.connection.setTimeout(0);
            if (!segmentInfo) {
                throw new _errors2.default.ReportNotExistFile();
            }

            let segmentRules = JSON.parse(segmentInfo.segmentRules);

            if (segmentRules && segmentRules.fileRules && segmentRules.fileRules.filePath && (0, _is2.default)(segmentRules.fileRules.inStorage, 0)) {
                /**
                 * 自己上传的人群文件
                 * @type {*|string}
                 */
                if (!_fs2.default.existsSync(_path2.default.join(_config2.default.fileDir, `/${segmentRules.fileRules.filePath}`))) {
                    throw new _errors2.default.ReportNotExistFile();
                }
            } else {
                data = yield segmentService.download({ segmentId });
                if (!data) {
                    throw new _errors2.default.ReportNotExistFile();
                }
            }
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(null, data);
    });

    return function downloadValidate(_x27) {
        return _ref26.apply(this, arguments);
    };
})();
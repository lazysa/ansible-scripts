'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _insightController = require('./insight.controller.js');

var ctrl = _interopRequireWildcard(_insightController);

var _insightFilter = require('./insight.filter.js');

var filter = _interopRequireWildcard(_insightFilter);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({});

//人群列表
router.get('/insight/:segmentId', filter.analysis, ctrl.analysis);
router.get('/insight/:segmentId/:tagId', filter.analysis, ctrl.analysisByTagId);

router.get('/report/download/:segmentId', filter.download, ctrl.download);
router.get('/report/download/:segmentId/:tagId', filter.download, ctrl.downloadByTagId);

//人群活动效果报告
router.post('/campaign/segment/report', filter.campaignSegmentReport, ctrl.campaignSegmentReport);
router.post('/campaign/segment/report/time', filter.campaignSegmentReportTime, ctrl.campaignSegmentReportTime);
router.post('/campaign/segment/report/pages', filter.campaignSegmentReportPages, ctrl.campaignSegmentReportPages);
router.post('/campaign/segment/report/download', filter.campaignSegmentReport, ctrl.campaignSegmentReportDownload);

//id报告
router.get('/idmerge/distribution/:segmentId', ctrl.distribution);
router.post('/idmerge/association', ctrl.association);
router.get('/idReport/download/:segmentId', ctrl.downloadIdReport);

exports.default = router;
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.campaignMetrics = undefined;

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _api = require('../common/api');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let campaignMetrics = exports.campaignMetrics = () => {
    return _api.AnalyticsWebApi.campaignMetrics();
};
/*
Navicat MySQL Data Transfer

Source Server         : dev
Source Server Version : 50711
Source Host           : cc-mysql-test.c5s7vgxpiybm.rds.cn-north-1.amazonaws.com.cn:3306
Source Database       : audience

Target Server Type    : MYSQL
Target Server Version : 50711
File Encoding         : 65001

Date: 2017-09-15 15:43:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tag_value_upload_log
-- ----------------------------
DROP TABLE IF EXISTS `tag_value_upload_log`;
CREATE TABLE `tag_value_upload_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_path` varchar(255) NOT NULL,
  `tag_id` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `rules` json NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;
SET FOREIGN_KEY_CHECKS=1;

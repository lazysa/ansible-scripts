'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.tagBuyerCounts = exports.channelBuyerCount = exports.loyalBuyerCountRecord = exports.buyerCountRecord = exports.productList = exports.categoryBuyerCount = exports.categorySegmentsIds = exports.loyalProductsBuyerCount = exports.loyalCategorieBuyerCount = exports.productsBuyerCount = exports.categoriesBuyerCount = exports.categoryList = exports.loyalCategorieDatas = exports.categorieDatas = undefined;

var _sequelize = require('sequelize');

var _sequelize2 = _interopRequireDefault(_sequelize);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _models = require('../common/models');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let categorieDatas = exports.categorieDatas = (startDate, endDate) => {
    let allPromises = [],
        categoriesCount = null,
        productsCount = null,
        segments = null;
    allPromises.push(categoriesBuyerCount(startDate, endDate).then(rsp => categoriesCount = rsp));
    allPromises.push(productsBuyerCount(startDate, endDate).then(rsp => productsCount = rsp));
    allPromises.push(categorySegmentsIds('buy').then(rsp => segments = rsp));

    return _bluebird2.default.all(allPromises).then(() => {
        return combineCategoryProduct(categoriesCount, productsCount, segments);
    });
};

let loyalCategorieDatas = exports.loyalCategorieDatas = () => {
    let allPromises = [],
        categoriesCount = null,
        productsCount = null,
        segments = null;
    allPromises.push(loyalCategorieBuyerCount().then(rsp => categoriesCount = rsp));
    allPromises.push(loyalProductsBuyerCount().then(rsp => productsCount = rsp));
    allPromises.push(categorySegmentsIds('loyal').then(rsp => segments = rsp));

    return _bluebird2.default.all(allPromises).then(() => {
        return combineCategoryProduct(categoriesCount, productsCount, segments);
    });
};

let categoryList = exports.categoryList = () => {
    return _models.Exxon.findAll({
        attributes: [[_sequelize2.default.literal('DISTINCT `category`'), 'category']],
        raw: true
    });
};

let categoriesBuyerCount = exports.categoriesBuyerCount = (startDate, endDate) => {
    let sql = 'SELECT category, count(DISTINCT(buyer_mobile)) as `buyerCount` FROM ods_sells_transaction';

    let dateRange = dateRangeSqlCondition(startDate, endDate);
    // let dateRange = dateRangeSqlCondition('2016-01-01', '2016-06-01');
    dateRange && (sql += ' WHERE ' + dateRange);

    sql += ' GROUP BY category';

    return _models.sequelize.query(sql, { type: _models.sequelize.QueryTypes.SELECT });
};

let productsBuyerCount = exports.productsBuyerCount = (startDate, endDate) => {
    // let productSql = `SELECT viscosity, count(DISTINCT(buyer_mobile)) as buyerCount FROM ods_sells_transaction`;
    // let dateRange = dateRangeSqlCondition(startDate, endDate);
    // // let dateRange = dateRangeSqlCondition('2016-01-01', '2016-06-01');
    // dateRange && (productSql += ' WHERE ' + dateRange);
    // productSql += ' GROUP BY viscosity';

    // let categorySql = `SELECT DISTINCT(category), viscosity FROM ods_sells_transaction`;
    //
    // let sql = `SELECT L.viscosity AS name, L.buyerCount, R.category FROM (${productSql}) L INNER JOIN (${categorySql}) R ON L.viscosity=R.viscosity`;

    let sql = `SELECT viscosity as name, category, count(DISTINCT(buyer_mobile)) as buyerCount FROM ods_sells_transaction group by viscosity, category`;
    let dateRange = dateRangeSqlCondition(startDate, endDate);
    // let dateRange = dateRangeSqlCondition('2016-01-01', '2016-06-01');
    dateRange && (sql += ' WHERE ' + dateRange);

    return _models.sequelize.query(sql, { type: _models.sequelize.QueryTypes.SELECT });
};

let loyalCategorieBuyerCount = exports.loyalCategorieBuyerCount = () => {
    let lastYearThisDay = (0, _moment2.default)().year((0, _moment2.default)().year() - 1).format("YYYYMMDD");
    let rangeCondition = dateRangeSqlCondition(lastYearThisDay);
    let sql = `SELECT T.category, count(1) as buyerCount from (SELECT category, buyer_mobile FROM ods_sells_transaction WHERE ${rangeCondition} GROUP BY category, buyer_mobile HAVING(count(buyer_mobile)>1)) T GROUP BY T.category;`;

    return _models.sequelize.query(sql, { type: _models.sequelize.QueryTypes.SELECT });
};

let loyalProductsBuyerCount = exports.loyalProductsBuyerCount = () => {
    let lastYearThisDay = (0, _moment2.default)().year((0, _moment2.default)().year() - 1).format("YYYYMMDD");
    let rangeCondition = dateRangeSqlCondition(lastYearThisDay);
    // let sql = `SELECT L.product_name AS name, L.buyerCount, R.category FROM
    //           (
    //               SELECT T.product_name, count(1) as buyerCount from
    //               (
    //                   SELECT product_name, buyer_mobile, count(buyer_mobile) as buyerCount FROM ods_sells_transaction WHERE ${rangeCondition} GROUP BY product_name,buyer_mobile HAVING(count(buyer_mobile)>1)
    //               ) T GROUP BY T.product_name
    //           ) L INNER JOIN
    //           (SELECT DISTINCT(category), product_name FROM ods_sells_transaction) R ON L.product_name=R.product_name`;

    let sql = `SELECT T.viscosity as name, T.category, count(1) as buyerCount from (SELECT viscosity, category, buyer_mobile, count(buyer_mobile) as buyerCount FROM ods_sells_transaction WHERE ${rangeCondition} GROUP BY viscosity, category, buyer_mobile HAVING(count(buyer_mobile)>1)) T GROUP BY T.viscosity`;

    return _models.sequelize.query(sql, { type: _models.sequelize.QueryTypes.SELECT });
};

let categorySegmentsIds = exports.categorySegmentsIds = life_cycle => {
    let sql = `SELECT segment_id, category, viscosity FROM ods_sells_segments WHERE life_cycle='${life_cycle}'`;

    return _models.sequelize.query(sql, { type: _models.sequelize.QueryTypes.SELECT });
};

let categoryBuyerCount = exports.categoryBuyerCount = category => {
    return _models.sequelize.query('SELECT count(DISTINCT(buyer_mobile)) as `count` FROM ods_sells_transaction WHERE category=\'' + category + '\'', { type: _models.sequelize.QueryTypes.SELECT }).then(response => response[0] ? response[0].count : 0);
};

let productList = exports.productList = category => {
    let params = {
        attributes: [[_sequelize2.default.literal('DISTINCT `product_name`'), 'productName']],
        raw: true
    };
    category && (params.where = { category });
    return _models.Exxon.findAll(params);
};

let buyerCountRecord = exports.buyerCountRecord = (startDate, endDate, category, product, step) => {
    // var sql = `SELECT date, count(DISTINCT(buyer_mobile)) as buyerCount FROM ods_sells_transaction`;
    // // var condition = '';
    // // category && (condition += `category='${category}'`);
    // // product && (condition += (condition ? ` AND `:``) + `product_name='${product}'`);
    // // condition && (sql += ` WHERE ${condition}`);
    // let condition = specialCondition(category, product);
    // let dateRange = dateRangeSqlCondition(startDate, endDate);
    // if(dateRange) {
    //     sql += (condition ? `` : ` WHERE `) + dateRange;
    // }
    let dateRange = dateRangeSqlCondition(startDate, endDate);
    let sCondition = specialCondition(category, product);
    let conditions = [],
        condSql = '';
    dateRange && conditions.push(dateRange);
    sCondition && conditions.push(sCondition);
    conditions.length > 0 && (condSql = conditions.join(' AND '));
    condSql && (condSql = ' WHERE ' + condSql + ' ');

    // let sql = `SELECT date, count(DISTINCT(buyer_mobile)) as buyerCount FROM ods_sells_transaction ${condSql} GROUP BY date`;
    let sql = null;
    if (!step || step == 'd') {
        sql = `
        SELECT L.date as date, L.buyerCount AS allCount, R.buyerCount AS loyalCount
            FROM
            (SELECT date, count(DISTINCT(buyer_mobile)) as buyerCount FROM ods_sells_transaction ${condSql} GROUP BY date) L
            LEFT JOIN
            (SELECT T.date, count(1) as buyerCount
              FROM
                (SELECT date, buyer_mobile, count(buyer_mobile) from ods_sells_transaction ${condSql} GROUP BY date, buyer_mobile HAVING(count(buyer_mobile)>1)) T
              GROUP BY T.date) R
            ON L.date=R.date
        `;
    } else if (step == 'w') {
        sql = `
        SELECT L.date as date, L.buyerCount AS allCount, R.buyerCount AS loyalCount, L.date_start as date_start, L.date_end as date_end
            FROM
            (SELECT DATE_FORMAT(date,'%x %v') as date, MAX(DISTINCT(date)) as date_end, MIN(DISTINCT(date)) as date_start, count(DISTINCT(buyer_mobile)) as buyerCount FROM ods_sells_transaction ${condSql} GROUP BY DATE_FORMAT(date,'%x %v')) L
            LEFT JOIN
            (SELECT T.date, count(1) as buyerCount
              FROM
                (SELECT DATE_FORMAT(date,'%x %v') as date, buyer_mobile, count(buyer_mobile) from ods_sells_transaction ${condSql} GROUP BY DATE_FORMAT(date,'%x %v'), buyer_mobile HAVING(count(buyer_mobile)>1)) T
              GROUP BY T.date) R
            ON L.date=R.date;
        `;
    } else if (step == 'm') {
        sql = `
        SELECT L.date as date, L.buyerCount AS allCount, R.buyerCount AS loyalCount
            FROM
            (SELECT LEFT(date, 6) as date, count(DISTINCT(buyer_mobile)) as buyerCount FROM ods_sells_transaction ${condSql} GROUP BY LEFT(date, 6)) L
            LEFT JOIN
            (SELECT T.date, count(1) as buyerCount
              FROM
                (SELECT LEFT(date, 6) as date, buyer_mobile, count(buyer_mobile) from ods_sells_transaction ${condSql} GROUP BY LEFT(date, 6), buyer_mobile HAVING(count(buyer_mobile)>1)) T
              GROUP BY T.date) R
            ON L.date=R.date
        `;
    }

    return _models.sequelize.query(sql, { type: _models.sequelize.QueryTypes.SELECT });
};

let loyalBuyerCountRecord = exports.loyalBuyerCountRecord = (startDate, endDate, category, product) => {
    let dateRange = dateRangeSqlCondition(startDate, endDate);
    let sCondition = specialCondition(category, product);
    let conditions = [],
        condSql = '';
    dateRange && conditions.push(dateRange);
    sCondition && conditions.push(sCondition);
    conditions.length > 0 && (condSql = conditions.join(' AND '));
    condSql && (condSql = ' WHERE ' + condSql + ' ');

    var sql = `SELECT T.date, count(1) as buyerCount FROM
        (SELECT date, buyer_mobile, count(buyer_mobile) from ods_sells_transaction ${condSql} GROUP BY date, buyer_mobile HAVING(count(buyer_mobile)>1)) T GROUP BY T.date`;
};

let channelBuyerCount = exports.channelBuyerCount = (startDate, endDate, category, product) => {
    // let condSql = combineConditions(startDate, endDate, category, product);
    //
    // let sql = `SELECT channel, count(DISTINCT(buyer_mobile)) as 'buyerCount' FROM ods_sells_transaction ${condSql} GROUP BY channel`;

    let sCondition = specialCondition(category, product);
    // sCondition && (sCondition = "WHERE " + sCondition);
    let c1 = sCondition ? " WHERE " + sCondition : "";
    let c2 = sCondition ? " AND " + sCondition : "";

    let lastYearThisDay = (0, _moment2.default)().year((0, _moment2.default)().year() - 1).format("YYYYMMDD");
    let rangeCondition = dateRangeSqlCondition(lastYearThisDay);

    let sql = `
    SELECT L.channel as channel, L.count as allCount, R.count as loyalCount FROM (SELECT channel, COUNT(DISTINCT(buyer_mobile)) as count FROM ods_sells_transaction ${c1} GROUP BY channel) L LEFT JOIN
    (SELECT T.channel, count(1) as count FROM (SELECT buyer_mobile, count(buyer_mobile), channel from ods_sells_transaction WHERE ${rangeCondition} ${c2} GROUP BY channel, buyer_mobile HAVING(count(buyer_mobile)>1)) T GROUP BY T.channel) R ON L.channel = R.channel;
    `;

    return _models.sequelize.query(sql, { type: _models.sequelize.QueryTypes.SELECT });
};

let tagBuyerCounts = exports.tagBuyerCounts = () => {
    let buyerCounts = {};
    let tagSegmentIdsGetter = _models.sequelize.query(`SELECT segment_id, life_cycle FROM ods_sells_segments WHERE category = ''`, { type: _models.sequelize.QueryTypes.SELECT });

    let allPromises = [allBuyerCount().then(count => buyerCounts.all = count), loyalBuyerCount().then(count => buyerCounts.loyal = count), tagSegmentIdsGetter.then(rsp => {
        let allSegment = rsp && rsp.filter && rsp.filter(item => item.life_cycle == 'buy');
        let loyalSegment = rsp && rsp.filter && rsp.filter(item => item.life_cycle == 'loyal');
        allSegment && allSegment[0] && (buyerCounts.allId = allSegment[0].segment_id);
        loyalSegment && loyalSegment[0] && (buyerCounts.loyalId = loyalSegment[0].segment_id);
    })];
    return _bluebird2.default.all(allPromises).then(() => buyerCounts);
};

let allBuyerCount = () => {
    return _models.sequelize.query(`SELECT count(DISTINCT(buyer_mobile)) as count FROM ods_sells_transaction`, { type: _models.sequelize.QueryTypes.SELECT }).then(response => response[0] ? response[0].count : 0);
};

let loyalBuyerCount = () => {
    let lastYearThisDay = (0, _moment2.default)().year((0, _moment2.default)().year() - 1).format("YYYYMMDD");
    let rangeCondition = dateRangeSqlCondition(lastYearThisDay);

    let sql = `SELECT count(R.buyer_mobile) as count FROM (SELECT buyer_mobile FROM ods_sells_transaction WHERE ${rangeCondition} GROUP BY buyer_mobile having(count(buyer_mobile)>1)) R`;

    return _models.sequelize.query(sql, { type: _models.sequelize.QueryTypes.SELECT }).then(response => response[0] ? response[0].count : 0);
};

let dateRangeSqlCondition = (start, end) => {
    let sMoment = start ? (0, _moment2.default)(start) : (0, _moment2.default)('1999-01-01'),
        eMoment = end ? (0, _moment2.default)(end) : (0, _moment2.default)();
    let sYear = sMoment.year(),
        sMonth = sMoment.month() + 1,
        sDay = sMoment.date(),
        sDate = sMoment.format('YYYYMMDD');
    let eYear = eMoment.year(),
        eMonth = eMoment.month() + 1,
        eDay = eMoment.date(),
        eDate = eMoment.format('YYYYMMDD');

    let sSql = `date>=${sDate}`,
        eSql = `date<=${eDate}`;

    // let sSql = `RIGHT(pay_date, 4)>=${sYear} AND RIGHT(LEFT(pay_date, 5), 2)>=${sMonth} AND LEFT(pay_date, 2)>=${sDay}`;
    // let eSql = `RIGHT(pay_date, 4)<=${eYear} AND RIGHT(LEFT(pay_date, 5), 2)<=${eMonth} AND LEFT(pay_date, 2)<=${eDay}`;
    //
    if (start && end) return `${sSql} AND ${eSql}`;
    if (start) return `${sSql}`;
    if (end) return `${eSql}`;
    return null;

    // let yearSql = `RIGHT(pay_date, 4)>=${sYear} AND RIGHT(pay_date, 4)<=${eYear}`;
    // let monthSql = `RIGHT(LEFT(pay_date, 5), 2)>=${sMonth} AND RIGHT(LEFT(pay_date, 5), 2)<=${eMonth}`;
    // let daySql = `LEFT(pay_date, 2)>=${sDay} AND LEFT(pay_date, 2)<=${eDay}`;
    //
    // return `${yearSql} AND ${monthSql} AND ${daySql}`;
};

let specialCondition = (category, product) => {
    var condition = '';
    category && (condition += `category='${category}'`);
    product && (condition += (condition ? ` AND ` : ``) + `viscosity='${product}'`);

    return condition;
};

let combineConditions = (startDate, endDate, category, product) => {
    let dateRange = dateRangeSqlCondition(startDate, endDate);
    let sCondition = specialCondition(category, product);
    let conditions = [],
        condSql = '';
    dateRange && conditions.push(dateRange);
    sCondition && conditions.push(sCondition);
    conditions.length > 0 && (condSql = conditions.join(' AND '));
    condSql && (condSql = ' WHERE ' + condSql + ' ');

    return condSql;
};

let combineCategoryProduct = (categoriesCount, productsCount, segments) => {
    if (!productsCount) return categoriesCount;

    let data = [],
        categoriesDic = {};
    for (let item of categoriesCount) {
        let segment = segments.filter(s => !s.viscosity && s.category == item.category)[0];
        categoriesDic[item.category] = { name: item.category, buyerCount: item.buyerCount, segmentId: segment && segment.segment_id };
    }
    for (let pItem of productsCount) {
        if (categoriesDic[pItem.category]) {
            categoriesDic[pItem.category].products = categoriesDic[pItem.category].products || [];

            let segment = segments.filter(s => s.viscosity == pItem.name && s.category == pItem.category)[0];
            pItem.segmentId = segment && segment.segment_id;
            categoriesDic[pItem.category].products.push(pItem);
        }
    }
    for (let cItemKey in categoriesDic) {
        data.push(categoriesDic[cItemKey]);
    }

    return data;
};
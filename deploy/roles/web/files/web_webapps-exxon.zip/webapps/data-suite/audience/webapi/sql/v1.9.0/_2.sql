CREATE TABLE `audience`.`analytics_report_default_segment` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `segment_id` VARCHAR(255) NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  `is_campaign_default` TINYINT(4) NOT NULL DEFAULT 1,
  `is_site_default` TINYINT(4) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`));

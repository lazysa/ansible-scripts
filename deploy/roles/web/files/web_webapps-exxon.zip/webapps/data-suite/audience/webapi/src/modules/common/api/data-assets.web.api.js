'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _helper = require('../util/helper');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class DataAssetsWebApi {
    constructor() {
        this.baseUrl = _config2.default.dataAssetsApiPath;
    }

    getFirstPartyUserIdType() {
        let url = `${this.baseUrl}/v1/business/userIdType`;
        return (0, _helper.getDataAssetsApi)(url, {}, { method: 'get' });
    }

    getSysUserIdColumnsListByTableName(tableName) {
        let url = `${this.baseUrl}/v1/business/sysUserIdColumns/${tableName}`;
        return (0, _helper.getDataAssetsApi)(url, {}, { method: 'get' });
    }
    sysUserIdColumns(body) {
        let url = `${this.baseUrl}/v1/business/sysUserIdColumns/create`;
        return (0, _helper.getDataAssetsApi)(url, body, { method: 'post' });
    }
}

exports.default = new DataAssetsWebApi();
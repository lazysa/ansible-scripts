'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.details = exports.pages = undefined;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import {Enums} from '../../config/consts';


let pages = exports.pages = _joi2.default.object().keys({
    keywords: _joi2.default.string().allow('').min(0).max(300),
    pageIndex: _joi2.default.number().integer().min(1).required().default(1),
    pageSize: _joi2.default.number().integer().min(1).max(1000).required().default(10),
    sort: _joi2.default.string().allow('')
});

let details = exports.details = _joi2.default.object().keys({
    pageIndex: _joi2.default.number().integer().min(1).required().default(1),
    pageSize: _joi2.default.number().integer().min(1).max(1000).required().default(10),
    startDate: _joi2.default.string(),
    endDate: _joi2.default.string(),
    type: _joi2.default.string()
});
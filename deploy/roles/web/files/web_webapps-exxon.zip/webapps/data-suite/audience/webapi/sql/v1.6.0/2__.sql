update segment set expires= '2199-01-01 00:00:00' where expires is null;

update first_party_tag set expires= '2199-01-01 00:00:00' where expires is null;

ALTER TABLE `audience`.`first_party_tag`
CHANGE COLUMN `expires` `expires` DATETIME NOT NULL DEFAULT '2199-01-01 00:00:00' ;

ALTER TABLE `audience`.`segment`
CHANGE COLUMN `expires` `expires` DATETIME NOT NULL DEFAULT '2199-01-01 00:00:00' ;




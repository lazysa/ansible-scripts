'use strict';

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Tag_value_original', {
        tagValueId: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'tag_value_id'
        },
        originalId: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'original_id'
        },
        status: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: 'status'
        }
    }, {
        tableName: 'tag_value_original',
        timestamps: false
    });
};
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let Schema = _mongoose2.default.Schema;

let schema = new Schema({
	'id': String,
	'type': {
		'type': Number,
		'default': 1
	},
	'metaObjectId': String, //对象id
	'name': String,
	'remark': String, //说明
	'dataType': Number, //类型
	'isMultiValue': { //是否支持多值
		'type': Number,
		'default': 0
	},
	'isUnique': {
		'type': Number,
		'default': 0
	},
	'isUserId': { //是否是用户id
		'type': Number,
		'default': 0
	},
	'userIdType': [Number],
	'isUserField': { //是否是用户资料字段
		'type': Number,
		'default': 0
	},
	'isNameField': { //是name字段
		'type': Number,
		'default': 0
	},
	'relatedMetaObjectId': String, //关联的对象id
	'relatedMetaObjectFieldId': String, //关联的相应对象的相应字段
	'editable': { //是否可编辑
		'type': Number,
		'default': 1
	},
	'settleTime': {
		'type': Date,
		'default': Date.now
	},
	'lastChanged': {
		'type': Date,
		'default': Date.now
	},
	'status': {
		'type': Number,
		'default': 1
	}
});

schema.index({
	'id': 1
});

schema.index({
	"metaObjectId": 1
});

exports.default = _mongoose2.default.model('MetaObjectField', schema);
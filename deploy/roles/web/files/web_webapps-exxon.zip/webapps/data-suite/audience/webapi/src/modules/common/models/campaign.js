"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

/*
事务处理 http://www.uml.org.cn/sjjm/2014081111.asp
*/

var campaignSechma = new Schema({
	"id": String,
	"name": String, //名称
	"startTime": {
		"type": Date,
		default: null
	}, //开始时间
	"endTime": {
		"type": Date,
		default: null
	}, //结束时间
	"budget": Number, //预算
	"remark": {
		"type": String,
		"maxlength": 250
	}, //备注
	"defaultGoalId": {
		type: String,
		default: null
	}, //默认目标
	"siteIds": [String], //关联站点
	"source": Number, //来源 WEB LOG
	"settleTime": {
		"type": Date,
		"default": Date.now
	},
	"lastChanged": {
		"type": Date,
		"default": Date.now
	},
	"status": {
		"type": Number,
		"default": 1
	}
});

campaignSechma.index({
	"id": 1
});
campaignSechma.index({
	"name": 1
});

exports.default = mongoose.model("Campaign", campaignSechma);
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _consts = require('../../../config/consts');

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _helper = require('../util/helper');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const { DataSourceCategory } = _consts.Enums;


class ReportApi {
    constructor() {
        this.baseUrl = _config2.default.reportApiPath;
    }

    //下载人群文件
    downloadSegmentFile(body, filePath) {
        let url = `${this.baseUrl}/download/segment`;
        body.templateId = 'default';
        return (0, _helper.getReportApi)(url, body, {}, {
            filePath
        });
    }

    //查询洞察报告
    getCrossoverSummary(segmentIds = []) {
        let url = `${this.baseUrl}/segment/cross/summary`;
        return (0, _helper.getReportApi)(url, {
            segmentIds
        });
    }

    //查询洞察报告
    getInsightFormServer(segmentId, category, dataSourceId, tagId) {
        let url = `${this.baseUrl}/query/insight`;
        return (0, _helper.getReportApi)(url, {
            tagId: tagId || '',
            segmentId: segmentId === 'TOTAL' ? '' : segmentId,
            sourceId: Number(category) === DataSourceCategory.FirstParty ? 0 : Number(dataSourceId)
        });
    }

    //查询多人群洞察报告
    getInsightFormServerMulti(segmentIds, category, dataSourceId, tagId) {
        let url = `${this.baseUrl}/query/insightmulti`;
        return (0, _helper.getReportApi)(url, {
            tagId: tagId || '',
            segmentId: segmentIds,
            sourceId: Number(category) === DataSourceCategory.FirstParty ? 0 : Number(dataSourceId)
        });
    }

    //查询二维
    getInsight2dFormServer(segmentId, tagId, secTagId) {
        let url = `${this.baseUrl}/query/insight2d`;
        return (0, _helper.getReportApi)(url, {
            tagId,
            secTagId,
            segmentId: segmentId === 'TOTAL' ? '' : segmentId
        });
    }

    //查询二维 多人群
    getInsight2dFormServerMulti(segmentIds, tagId, secTagId) {
        let url = `${this.baseUrl}/query/insight2dmulti`;
        return (0, _helper.getReportApi)(url, {
            tagId,
            secTagId,
            segmentId: segmentIds
        });
    }

    //下载洞察报告
    downloadInsightFormServer(segmentId, category, dataSourceId, tagId) {
        let url = `${this.baseUrl}/download/insight`;
        return (0, _helper.getReportApi)(url, {
            tagId: tagId || '',
            segmentId: segmentId === 'TOTAL' ? '' : segmentId,
            sourceId: Number(category) === DataSourceCategory.FirstParty ? 0 : Number(dataSourceId)
        });
    }

    //下载二位交叉的结果
    downloadInsight2dFormServer(segmentId, tagId, secTagId) {
        let url = `${this.baseUrl}/download/insight2d`;
        return (0, _helper.getReportApi)(url, {
            tagId,
            secTagId,
            segmentId: segmentId === 'TOTAL' ? '' : segmentId
        });
    }

    //获取全景资料list
    getExploreList(body) {
        let url = `${this.baseUrl}/query/explore/list`;
        return (0, _helper.getReportApi)(url, body);
    }

    //获取全景资料详情
    getDetails(body) {
        let url = `${this.baseUrl}/query/explore/detail`;
        return (0, _helper.getReportApi)(url, body);
    }

    //获取行为类型list
    getBehaviourTypeList(body) {
        let url = `${this.baseUrl}/query/explore/event`;
        return (0, _helper.getReportApi)(url, body);
    }

    //获取基础信息
    getBasic(body) {
        let url = `${this.baseUrl}/query/explore/basic`;
        return (0, _helper.getReportApi)(url, body);
    }

    /**
     * 获取ID merge 分布报告
     * @param body
     */
    getDistribution(body) {
        let url = `${this.baseUrl}/mergeid/distributed`;
        return (0, _helper.getReportApi)(url, body);
    }

    /**
     * 获取ID merge 打通率报告
     * @param body
     */
    getAssociation(body) {
        let url = `${this.baseUrl}/mergeid/through`;
        return (0, _helper.getReportApi)(url, body);
    }

    /**
     * 获取ID merge 所有打通率报告
     * @param body
     */
    getAllThrough(body) {
        let url = `${this.baseUrl}/mergeid/throughall`;
        return (0, _helper.getReportApi)(url, body);
    }
}

exports.default = new ReportApi();
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.removeValidate = exports.remove = exports.removeTagBaseAuth = exports.removeTagAuth = exports.update = exports.query = exports.bulkCreate = exports.create = exports.thirdPartyAllPages = exports.thirdPartyPages = exports.thirdPartyAllList = exports.thirdPartyDepthList = exports.thirdPartyList = exports.firstPartyPages = exports.firstPartyDepthList = exports.firstPartyList = undefined;

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

/**
 * 删除标签前的验证
 * @param ctx
 * @param next
 * @return {Promise.<void>}
 */
let removeTagAuth = exports.removeTagAuth = (() => {
    var _ref13 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        try {
            let id = ctx.params.id;

            let usedSegmentList = yield (0, _segment.isUploadSegmentUsedBySegment)(id, 'tagId');
            if (usedSegmentList && usedSegmentList.length > 0) {
                throw new _errors2.default.TagSegmentUsed();
            }
            yield next();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function removeTagAuth(_x13, _x14) {
        return _ref13.apply(this, arguments);
    };
})();

let removeTagBaseAuth = exports.removeTagBaseAuth = (() => {
    var _ref14 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        try {
            let id = ctx.params.id;
            let tagValueGenerating = yield tagService.isTagValueGenerating(id);
            if (tagValueGenerating) {
                //标签生成中
                throw new _errors2.default.TagValueAtGenerating();
            }

            let analyticsValidateRes = yield _api.AnalyticsWebApi.isTagUsedByCampaignOrSite(id);
            if (analyticsValidateRes) {
                if (analyticsValidateRes['site']) throw new _errors2.default.TagSiteUsed();
                if (analyticsValidateRes['campaign']) throw new _errors2.default.TagCampaignUsed();
            }
            yield next();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function removeTagBaseAuth(_x15, _x16) {
        return _ref14.apply(this, arguments);
    };
})();

/**
 * 移除
 * @param ctx
 * @return {{status}|{data, status}|*}
 */


var _consts = require('../../config/consts');

var _helper = require('../common/util/helper');

var _tag = require('./tag.service');

var tagService = _interopRequireWildcard(_tag);

var _tagValue = require('../tagValue/tagValue.service');

var _segment = require('../segment/segment.service');

var _lodash = require('lodash');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _api = require('../common/api');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let { Status, DataSourceCategory, TagLevel } = _consts.Enums;

let firstPartyList = exports.firstPartyList = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let tagGroupId = ctx.params.tagGroupId;
            let { mergeRule, isUsedForInsight, isUsedForSegment } = ctx.request.query;
            data = yield tagService.firstPartyList(tagGroupId, mergeRule, isUsedForInsight, isUsedForSegment);
            data = yield tagService.appendTagGroupToTagList(data);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function firstPartyList(_x) {
        return _ref.apply(this, arguments);
    };
})();
let firstPartyDepthList = exports.firstPartyDepthList = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let tagGroupId = ctx.params.tagGroupId;
            let { mergeRule, isUsedForInsight } = ctx.request.query;

            let tagGroupArray = yield tagService.getDepthTagGroupId(tagGroupId, DataSourceCategory.FirstParty);

            data = yield tagService.firstPartyList(tagGroupArray, mergeRule, isUsedForInsight);
            data = yield tagService.appendTagGroupToTagList(data);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function firstPartyDepthList(_x2) {
        return _ref2.apply(this, arguments);
    };
})();

let firstPartyPages = exports.firstPartyPages = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let tagGroupId = ctx.params.tagGroupId;
            let query = ctx.request.query;
            let offset = query.pageSize * (query.pageIndex - 1);
            let limit = +query.pageSize;
            let { keywords, sort } = query;
            let where = {
                recordViewable: Status.Normal
            };
            if (tagGroupId !== 'all') {
                (0, _assign2.default)(where, {
                    tagGroupId: tagGroupId
                });
            }
            where = tagService.getWhere(where, keywords);

            let conditions = {
                attributes: ['id', 'name', 'status', 'createdAt', 'tagLevel', 'recordEditable', 'isUsedForInsight', 'coverage'],
                offset,
                limit,
                where,
                order: sort ? [[sort.replace(/^-/, ''), /^-/.test(sort) ? 'DESC' : 'ASC'], ['createdAt', 'DESC']] : [['createdAt', 'DESC']]
            };
            let { rows: list, count: total } = yield tagService.firstPartyPages(conditions);
            data = {
                total: total,
                list: list,
                pageSize: query.pageSize,
                pageIndex: query.pageIndex
            };
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function firstPartyPages(_x3) {
        return _ref3.apply(this, arguments);
    };
})();

let thirdPartyList = exports.thirdPartyList = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let tagGroupId = ctx.params.tagGroupId;
            let { isUsedForInsight, isUsedForSegment } = ctx.request.query;
            data = yield tagService.thirdPartyList(tagGroupId, isUsedForInsight, isUsedForSegment);
            data = yield tagService.appendTagGroupToTagList(data);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function thirdPartyList(_x4) {
        return _ref4.apply(this, arguments);
    };
})();

let thirdPartyDepthList = exports.thirdPartyDepthList = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let tagGroupId = ctx.params.tagGroupId;
            let { isUsedForInsight } = ctx.request.query;
            let tagGroupArray = yield tagService.getDepthTagGroupId(tagGroupId, DataSourceCategory.ThirdParty);

            data = yield tagService.thirdPartyList(tagGroupArray, isUsedForInsight);
            data = yield tagService.appendTagGroupToTagList(data);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function thirdPartyDepthList(_x5) {
        return _ref5.apply(this, arguments);
    };
})();

let thirdPartyAllList = exports.thirdPartyAllList = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let dataSourceId = ctx.params.dataSourceId;
            let { isUsedForInsight } = ctx.request.query;
            let ids = yield tagService.getTagGroupByDataSourceId(dataSourceId);
            if (ids) {
                data = yield tagService.thirdPartyAllList(ids.map(function (item) {
                    return item.id;
                }), isUsedForInsight);
                let tagMap = (0, _lodash.groupBy)(ids, 'id');
                data.forEach(function (item) {
                    if (tagMap[item.tagGroupId] && tagMap[item.tagGroupId][0] && tagMap[item.tagGroupId][0].name) {
                        item.tagGroupName = tagMap[item.tagGroupId][0].name;
                    }
                });
            }
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function thirdPartyAllList(_x6) {
        return _ref6.apply(this, arguments);
    };
})();

/**
 * 第三方根据id查询pages
 * @param ctx
 * @returns {{status}|{data, status}|*}
 */
let thirdPartyPages = exports.thirdPartyPages = (() => {
    var _ref7 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let tagGroupId = ctx.params.tagGroupId;
            let query = ctx.request.query;
            let offset = query.pageSize * (query.pageIndex - 1);
            let limit = +query.pageSize;
            let keywords = query.keywords;

            let where = {
                tagGroupId: tagGroupId
            };

            where = tagService.getWhere(where, keywords);

            let conditions = {
                attributes: ['id', 'name', 'status', 'refreshTime', 'isUsedForInsight'],
                offset,
                limit,
                where,
                order: [['createdAt', 'DESC']]
            };
            let { rows: list, count: total } = yield tagService.thirdPartyPages(conditions);
            data = {
                total: total,
                list: list,
                pageSize: query.pageSize,
                pageIndex: query.pageIndex
            };
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function thirdPartyPages(_x7) {
        return _ref7.apply(this, arguments);
    };
})();

/**
 * 第三方所有pages
 * @param ctx
 * @returns {{status}|{data, status}|*}
 */
let thirdPartyAllPages = exports.thirdPartyAllPages = (() => {
    var _ref8 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let dataSourceId = ctx.params.dataSourceId;
            let query = ctx.request.query;
            let offset = query.pageSize * (query.pageIndex - 1);
            let limit = +query.pageSize;
            let keywords = query.keywords;
            let where = {};
            let ids = yield tagService.getTagGroupByDataSourceId(dataSourceId);
            if (ids) {
                (0, _assign2.default)(where, {
                    tagGroupId: {
                        $in: ids.map(function (item) {
                            return item.id;
                        })
                    }
                });
            }
            where = tagService.getWhere(where, keywords);

            let conditions = {
                attributes: ['id', 'name', 'status', 'refreshTime', 'isUsedForInsight'],
                offset,
                limit,
                where,
                order: [['createdAt', 'DESC']]
            };
            let { rows: list, count: total } = yield tagService.thirdPartyPages(conditions);
            data = {
                total: total,
                list: list,
                pageSize: query.pageSize,
                pageIndex: query.pageIndex
            };
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function thirdPartyAllPages(_x8) {
        return _ref8.apply(this, arguments);
    };
})();

let create = exports.create = (() => {
    var _ref9 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            if (body.isForever) {
                body.expires = _helper.FOREVER_TIME;
            }
            data = yield tagService.create(body);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function create(_x9) {
        return _ref9.apply(this, arguments);
    };
})();

let bulkCreate = exports.bulkCreate = (() => {
    var _ref10 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let { metaObject, tag } = body;
            // await tagService.createSysUserIdColumns(field,metaObject);
            for (let item of tag) {
                if (item.isForever) {
                    item.expires = _helper.FOREVER_TIME;
                    item.tagLevel = TagLevel.batchDefault;
                }
                let tagRecord = yield tagService.create(item);
                yield (0, _tagValue.bulkCreateDefaultBatchTagValue)(item.tagValue, metaObject, item.metaObjectField, tagRecord && tagRecord.id);
            }
        } catch (ex) {
            console.log(ex);
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function bulkCreate(_x10) {
        return _ref10.apply(this, arguments);
    };
})();

let query = exports.query = (() => {
    var _ref11 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = {};
        let error = null;
        try {
            let id = ctx.params.id;
            data = yield tagService.query(id);
            data['priority'] = yield tagService.getTagValuePriority(id);
            data['isForever'] = Number((0, _helper.dateIsForever)(data.expires));
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function query(_x11) {
        return _ref11.apply(this, arguments);
    };
})();

let update = exports.update = (() => {
    var _ref12 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let id = ctx.params.id;
            if (body.isForever) {
                body.expires = _helper.FOREVER_TIME;
            }
            /*
             *更新标签值表的优先级列表
             */
            if (body.priority && body.priority.length > 0) {
                yield tagService.shouldPriorityUpdate(id, body.priority, body.tagType);
            }
            data = yield tagService.update(id, body);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function update(_x12) {
        return _ref12.apply(this, arguments);
    };
})();let remove = exports.remove = (() => {
    var _ref15 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let id = ctx.params.id;
            data = yield tagService.remove(id);
            data = yield tagService.removeTagValue(id);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function remove(_x17) {
        return _ref15.apply(this, arguments);
    };
})();
/**
 * 移除验证
 * @param ctx
 * @return {{status}|{data, status}|*}
 */
let removeValidate = exports.removeValidate = (() => {
    var _ref16 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let id = ctx.params.id;
            data = yield (0, _segment.isUploadSegmentUsedBySegment)(id, 'tagId');
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function removeValidate(_x18) {
        return _ref16.apply(this, arguments);
    };
})();

/*
 export let close = async(ctx) => {
 let data = null;
 let error = null;
 try {
 let id = ctx.params.id;
 let status = `${capitalize(ctx.params.status)}`;
 let modelName = `${capitalize(ctx.params.dimensions)}PartyTag`;
 data = await tagService.closeOrOpen(modelName,id,status);
 } catch (ex) {

 return ctx.body = wrap(ex);
 }
 ctx.body = wrap(error,data);
 };
 */
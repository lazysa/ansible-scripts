/*
Navicat MySQL Data Transfer

Source Server         : dev
Source Server Version : 50711
Source Host           : cc-mysql-test.c5s7vgxpiybm.rds.cn-north-1.amazonaws.com.cn:3306
Source Database       : audience

Target Server Type    : MYSQL
Target Server Version : 50711
File Encoding         : 65001

Date: 2017-09-15 15:44:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tag_rely_on
-- ----------------------------
DROP TABLE IF EXISTS `tag_rely_on`;
CREATE TABLE `tag_rely_on` (
  `tag_value_id` varchar(255) NOT NULL,
  `tag_id` varchar(255) NOT NULL,
  `rely_on_tag_id` varchar(255) NOT NULL,
  `rely_on_tag_value_id` json DEFAULT NULL,
  PRIMARY KEY (`tag_value_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
SET FOREIGN_KEY_CHECKS=1;

ALTER TABLE `audience`.`first_party_tag` 
ADD COLUMN `record_viewable` TINYINT(4) NOT NULL DEFAULT 1 AFTER `is_used_for_insight`,
ADD COLUMN `expires` DATETIME NULL AFTER `record_viewable`;

ALTER TABLE `audience`.`segment` 
ADD COLUMN `expires` DATETIME NULL AFTER `refresh_time`;

ALTER TABLE `audience`.`segment` 
ADD COLUMN `record_editable` TINYINT(4) NOT NULL DEFAULT 1 AFTER `expires`;


ALTER TABLE `audience`.`segment_group` 
ADD COLUMN `sequence` INT NULl AFTER id;

UPDATE  segment_group set `sequence` = `id`;



-- INSERT INTO `segment_upload_field` ( `name`, `field_id`, `encrypt_type`, `data_source_id`, `category`, `column_field_id`)
-- VALUES
-- 	( 'phone_SHA1', 'phone', 'SHA1', 1, 2, 'phone_key'),
-- 	( 'IMEI_SHA1', 'IMEI', 'SHA1', 1, 2, 'imei_key'),
-- 	( 'IDFA_SHA1', 'IDFA', 'SHA1', 1, 2, 'idfa_key');

--   INSERT INTO `segment_upload_field` (`name`, `field_id`, `encrypt_type`, `data_source_id`, `category`, `column_field_id`)
-- VALUES
-- 	( 'phone_MD5', 'phone', 'MD5', 0, 1, 'mobile_md5'),
--   	( 'IMEI_MD5', 'IMEI', 'MD5', 0, 1, 'imei_md5'),
--     	( 'phone', 'phone', NULL, 0, 1, 'mobile'),
--          	( 'IMEI', 'IMEI', NULL , 0, 1, 'imei')
--   ;

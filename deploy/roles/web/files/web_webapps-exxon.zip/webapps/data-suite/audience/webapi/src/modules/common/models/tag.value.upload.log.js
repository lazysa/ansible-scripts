'use strict';

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

var _sequelize = require('sequelize');

var _sequelize2 = _interopRequireDefault(_sequelize);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Tag_value_upload_log', {
        id: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            defaultValue: null
        },
        filePath: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'file_path'
        },
        tagId: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'tag_id'
        },
        status: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'created_at'
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'updated_at'
        },
        rules: {
            type: DataTypes.JSON,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            set: function (val) {
                try {
                    this.setDataValue('rules', JSON.parse((0, _stringify2.default)(val)));
                } catch (err) {
                    return null;
                }
            },
            get: function (val) {
                try {
                    return this.getDataValue(val);
                } catch (err) {
                    return null;
                }
            }
        }
    }, {
        tableName: 'tag_value_upload_log'
    });
};
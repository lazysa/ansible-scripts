CREATE TABLE `audience`.`campaign_report` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `segment_id` VARCHAR(255) NOT NULL,
  `status` TINYINT(4) NOT NULL DEFAULT 1,
  `created_at` DATETIME NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`id`));

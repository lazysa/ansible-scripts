'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.downloadFile = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let downloadFile = exports.downloadFile = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        try {
            let {
                token
            } = ctx.params;
            let removeFileToken = true;
            let fileInfo = yield FileTokenService.getFile(token, removeFileToken);
            if (fileInfo) {
                ctx.attachment(fileInfo.fileName);
                ctx.res.connection.setTimeout(0);
                return ctx.body = _fs2.default.createReadStream(fileInfo.filePath);
            } else {
                ctx.status = 404;
            }
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function downloadFile(_x) {
        return _ref.apply(this, arguments);
    };
})();

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _helper = require('../common/util/helper');

var _fileToken = require('./fileToken.service');

var FileTokenService = _interopRequireWildcard(_fileToken);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
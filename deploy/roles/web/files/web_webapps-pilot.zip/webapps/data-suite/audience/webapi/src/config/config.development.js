'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _path = require('path');

let config = {
    env: 'development',
    mongodb: {
        url: 'mongodb://192.168.10.42/webapi'
    },
    mysql: {
        // host: '192.168.10.40',
        // poolSize: 5,
        // user: 'yccs',
        // password: 'neKD@e23=wdEJ1D',
        // database: 'audience',
        // assetsDatabase: 'data_assets'
        host: 'cc-mysql-test.c5s7vgxpiybm.rds.cn-north-1.amazonaws.com.cn',
        poolSize: 5,
        user: 'prs_user',
        password: '$ef#eF134Q',
        database: 'audience',
        assetsDatabase: 'data_assets'
    },
    allowOrigins: ["http://localhost:9102", "http://192.168.10.42:9102", "http://localhost:63342", "http://localhost:8080", "http://localhost:9020"],
    whitePaths: ["/const", '/metrics/campaign', '/api/v1/business', "/fileToken", "/segment/campaign", "/segment/site", "/segment/download"],
    authAPiPath: "http://web-dev.chiefclouds.com:9105/",
    authAppId: "audience",
    port: 9102,
    uploadDir: (0, _path.join)(__dirname, '../../uploads'),
    fileDir: (0, _path.join)(__dirname, '../../files'),
    logDir: (0, _path.join)(__dirname, '../../logs'),
    logLevel: 'info',
    poolSize: 200,
    reportApiPath: "http://web-dev.chiefclouds.com:10085/v1/audience",
    reportDownloadApiPath: "http://web-dev.chiefclouds.com:9100",
    dataServiceApiPath: "http://52.80.90.202:8082/v1/dataservice",
    // reportApiPath: "http://dmp.and-c.com:10085/v1/audience",
    reportBusinessApiPath: "http://web-dev.chiefclouds.com:10088/v1/audience",
    reportBusinessApiSecret: "ucmjwlyhdi2k6w5pxvfgvi",
    analyticsApiPath: "http://web-dev.chiefclouds.com/!/analytics/api",
    analyticsApiSecret: "ucmjwlyhdi2k6w5pxvfgvi",
    dataAssetsApiPath: "http://web-dev.chiefclouds.com/!/data-assets/api",
    dataAssetsApiSecret: "hx4zg1pli8b2aboqi79zfr",
    apiTimeout: 600000,
    fiddlerProxy: "http://127.0.0.1:8888",
    apiSecret: "ucmjwlyhdi2k6w5pxvfgvi",
    s3: {
        accessKeyId: "AKIAOSVPG6T774EQVSOA",
        secretAccessKey: "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",
        region: "cn-north-1",
        bucket: "chiefclouds-etl-dataset-stg" //s3的桶
    },
    HDFS: {
        path: '/tmp/audience-webapi'
    },
    fsProtocol: 's3'

};

exports.default = config;
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createSysUserIdColumns = exports.getThirdTaglistByIds = exports.getFirstTaglistByIds = exports.removeTagValue = exports.isTagValueGenerating = exports.remove = exports.update = exports.updatePriority = exports.shouldPriorityUpdate = exports.query = exports.createSingleTag = exports.create = exports.getTagValuePriority = exports.thirdPartyPages = exports.firstPartyPages = exports.thirdPartyAllList = exports.getTagGroupByDataSourceId = exports.thirdPartyList = exports.appendTagGroupToTagList = exports.firstPartyList = exports.getDepthTagGroupId = exports.getChildrenTagGroup = exports.getWhere = undefined;

var _is = require('babel-runtime/core-js/object/is');

var _is2 = _interopRequireDefault(_is);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

let createSysUserIdColumns = exports.createSysUserIdColumns = (() => {
    var _ref8 = (0, _asyncToGenerator3.default)(function* (models, metaobject) {
        let data = models.filter(function (z) {
            return z.userIdType;
        }).map(function (item) {
            return {
                tableName: metaobject,
                userIdColumn: item.metaObjectField,
                userIdType: item.userIdType,
                relationType: 'A',
                userIdColumnGroup: 1
            };
        });
        return _api.DataAssetsWebApi.sysUserIdColumns(data);
    });

    return function createSysUserIdColumns(_x11, _x12) {
        return _ref8.apply(this, arguments);
    };
})();

var _consts = require('../../config/consts');

var _models = require('../common/models');

var _immutable = require('immutable');

var _immutable2 = _interopRequireDefault(_immutable);

var _lodash = require('lodash');

var _tagGroup = require('../tagGroup/tagGroup.service');

var _tagValue = require('../tagValue/tagValue.service');

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _api = require('../common/api');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let { analyticsApiPath: analyticsApiPathUrl } = _config2.default;

let Status = _consts.Enums.Status;
let TagStatus = _consts.Enums.TagStatus;
let TagValueStatus = _consts.Enums.TagValueStatus;
let TagGroupStatus = _consts.Enums.TagGroupStatus;

/**
 * 分页总数统计
 * @param modelName
 * @param conditions
 * @returns {*}
 */
/*export let count = (modelName,conditions) => {
    return model[modelName].count(conditions);
};*/

/**
 * 构建查询条件
 * @param where
 * @param keywords
 * @returns {void|*}
 */
let getWhere = exports.getWhere = (where, keywords) => {
    if (keywords) {
        (0, _assign2.default)(where, {
            $or: {
                id: {
                    $like: `%${keywords}%`
                },
                name: {
                    $like: `%${keywords}%`
                }
            }
        });
    }
    return (0, _assign2.default)(where, {
        status: {
            $ne: TagStatus.Deleted
        }
    });
};
let getChildrenTagGroup = exports.getChildrenTagGroup = (currentArray, parentId, groupList) => {
    if (!groupList[parentId]) return currentArray;
    for (let item of groupList[parentId]) {
        currentArray.push(item.id);
        currentArray = getChildrenTagGroup(currentArray, item.id, groupList);
    }
    return currentArray;
};

/**
 * 获取深度对象
 * @param parentId
 * @param category
 * @param dataSourceId
 */
let getDepthTagGroupId = exports.getDepthTagGroupId = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (parentId, category, dataSourceId) {
        let where = {
            status: Status.Normal
        };
        if (category) (0, _assign2.default)(where, { category });
        if (dataSourceId) (0, _assign2.default)(where, { dataSourceId });

        let tagList = yield _models.TagGroup.findAll({
            where: where,
            raw: true
        });

        return getChildrenTagGroup([parentId], parentId, (0, _lodash.groupBy)(tagList, 'parentId'));
    });

    return function getDepthTagGroupId(_x, _x2, _x3) {
        return _ref.apply(this, arguments);
    };
})();

/**
 * 第一方标签id,name
 * @param id
 * @param mergeRule
 * @param isUsedForInsight
 * @param isUsedForSegment
 */
let firstPartyList = exports.firstPartyList = (id, mergeRule, isUsedForInsight, isUsedForSegment) => {
    let where = {
        status: TagStatus.Open,
        recordViewable: Status.Normal
    };
    if (id !== 'all') {
        (0, _assign2.default)(where, Array.isArray(id) ? {
            tagGroupId: { $in: id }
        } : {
            tagGroupId: id
        });
    }
    if (mergeRule) {
        (0, _assign2.default)(where, {
            mergeRule
        });
    }
    if (!(0, _is2.default)(isUsedForInsight, undefined)) {
        (0, _assign2.default)(where, {
            isUsedForInsight
        });
    }
    if (!(0, _is2.default)(isUsedForSegment, undefined)) {
        (0, _assign2.default)(where, {
            isUsedForSegment
        });
    }
    return _models.FirstPartyTag.findAll({
        attributes: ['id', 'name', 'tagGroupId', 'remark', 'chartType', 'isUsedForInsight', 'isUsedForSegment'],
        where,
        order: [['createdAt', 'DESC']],
        raw: true
    });
};

/**
 * 给第一方标签id,name添加分组信息
 * @param data
 */
let appendTagGroupToTagList = exports.appendTagGroupToTagList = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (data) {
        if (!data) return [];
        let tagGroupList = yield (0, _tagGroup.getTagGroupListByIds)(data.map(function (item) {
            return item.tagGroupId;
        }));
        if (tagGroupList && tagGroupList.length > 0) {
            let tagMap = (0, _lodash.groupBy)(tagGroupList, 'id');
            data.forEach(function (item) {
                if (tagMap[item.tagGroupId] && tagMap[item.tagGroupId][0] && tagMap[item.tagGroupId][0].name) {
                    item.tagGroupName = tagMap[item.tagGroupId][0].name;
                }
            });
        }
        return data;
    });

    return function appendTagGroupToTagList(_x4) {
        return _ref2.apply(this, arguments);
    };
})();

/**
 * 第三方根据分组id,获取list信息
 * @param id
 * @param isUsedForInsight
 * @returns {*}
 */
let thirdPartyList = exports.thirdPartyList = (id, isUsedForInsight, isUsedForSegment) => {
    let where = {
        tagGroupId: (() => {
            return Array.isArray(id) ? {
                $in: id
            } : id;
        })(),
        status: TagStatus.Open
    };

    if (!(0, _is2.default)(isUsedForInsight, undefined)) {
        (0, _assign2.default)(where, {
            isUsedForInsight
        });
    }

    if (!(0, _is2.default)(isUsedForSegment, undefined)) {
        (0, _assign2.default)(where, {
            isUsedForSegment
        });
    }

    return _models.ThirdPartyTag.findAll({
        attributes: ['id', 'name', 'tagGroupId', 'isUsedForInsight', 'isUsedForSegment'],
        where,
        order: [['createdAt', 'DESC']],
        raw: true
    });
};
/**
 * 根据数据源id获取标签分组list
 * @param id
 * @returns {*}
 */

let getTagGroupByDataSourceId = exports.getTagGroupByDataSourceId = id => {
    return _models.TagGroup.findAll({
        attributes: ['id', 'name'],
        where: {
            dataSourceId: id,
            status: {
                $ne: TagGroupStatus.Deleted
            }
        }
    });
};
/**
 * 第三方所有的list
 * @param ids
 * @param isUsedForInsight
 * @returns {*}
 */
let thirdPartyAllList = exports.thirdPartyAllList = (ids, isUsedForInsight) => {

    let where = {
        tagGroupId: {
            $in: (0, _lodash.uniq)(ids)
        },
        status: TagStatus.Open
    };

    if (!(0, _is2.default)(isUsedForInsight, undefined)) {
        (0, _assign2.default)(where, {
            isUsedForInsight
        });
    }

    return _models.ThirdPartyTag.findAll({
        attributes: ['id', 'name', 'tagGroupId', 'isUsedForInsight', 'isUsedForSegment'],
        where,
        order: [['createdAt', 'DESC']],
        raw: true
    });
};

/**
 * 第一方分页
 * @param conditions
 * @returns {*}
 */
let firstPartyPages = exports.firstPartyPages = conditions => {
    return _models.FirstPartyTag.findAndCount(conditions);
};

/**
 * 第三方分页
 * @param conditions
 * @returns {*}
 */
let thirdPartyPages = exports.thirdPartyPages = conditions => {
    return _models.ThirdPartyTag.findAndCount(conditions);
};

/**
 * 获得标签的随机数
 * @returns {*|Promise.<this>}
 */
let getSeq = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* () {
        let currentTagValueId;
        let seq;
        do {
            let instance = yield _models.Seq.findOne({
                where: {
                    id: 'tagId'
                }
            });
            seq = yield instance.increment('seq', {
                by: 1
            });
            currentTagValueId = yield _models.FirstPartyTag.findOne({
                where: {
                    id: 'FT' + seq.seq
                }
            });
        } while (currentTagValueId);
        return seq;
    });

    return function getSeq() {
        return _ref3.apply(this, arguments);
    };
})();

/**
 *根据tagid获取标签值的优先级list
 */
let getTagValuePriority = exports.getTagValuePriority = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (id) {
        return _models.FirstPartyTagValue.findAll({
            attributes: ['id', 'name', 'priority'],
            where: {
                tagId: id,
                status: {
                    $ne: TagValueStatus.Deleted
                }
            },
            order: [['priority', 'ASC']],
            raw: true
        });
    });

    return function getTagValuePriority(_x5) {
        return _ref4.apply(this, arguments);
    };
})();

/**
 * 第一方新建标签(多个)
 * @param model
 * @returns {model}
 */
let create = exports.create = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (model, isBulkCreate = 0) {
        let seq;
        let obj = (0, _lodash.pick)(model, ['name', 'tagType', 'tagGroupId', 'updatePeriod', 'remark', 'status', 'isUsedForInsight', 'isUsedForSegment', 'chartType', 'expires']);
        seq = yield getSeq();
        (0, _assign2.default)(obj, {
            id: 'FT' + seq.seq
        });
        if (isBulkCreate) {
            obj.isBulkCreate = 1;
        }
        // if (model.mergeRule && model.mergeRule.length > 0) {
        //     for (let item of model.mergeRule) {
        //         seq = await getSeq();
        //         models.push(Object.assign({
        //             mergeRule: item,
        //             id: 'FT' + seq.seq
        //         },obj));
        //     }
        // }
        return _models.FirstPartyTag.create(obj);
    });

    return function create(_x6) {
        return _ref5.apply(this, arguments);
    };
})();
/**
 * 创建一个标签
 * @param model
 * @returns {model}
 */
let createSingleTag = exports.createSingleTag = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (model) {
        let seq = yield getSeq();
        return _models.FirstPartyTag.create((0, _assign2.default)({
            id: 'FT' + seq.seq
        }, model));
    });

    return function createSingleTag(_x7) {
        return _ref6.apply(this, arguments);
    };
})();

let query = exports.query = id => {
    return _models.FirstPartyTag.findOne({
        where: {
            id
        },
        attributes: {
            exclude: ['created_at', 'updated_at']
        },
        raw: true
    });
};
/**
 * 是否优先级变动了
 * @param tagId
 * @param newPriority
 * @param tagType
 */
let shouldPriorityUpdate = exports.shouldPriorityUpdate = (() => {
    var _ref7 = (0, _asyncToGenerator3.default)(function* (tagId, newPriority, tagType) {
        let oldPriorityObj = yield getTagValuePriority(tagId);
        let tagRecord = yield query(tagId);
        let oldPriorityIM = _immutable2.default.fromJS(oldPriorityObj);
        let newPriorityIM = _immutable2.default.fromJS(newPriority);

        if (!oldPriorityIM.equals(newPriorityIM) || tagRecord.tagType != tagType) {
            yield (0, _tagValue.updateTagValueStatusToGenerating)(newPriority.map(function (item) {
                return item.id;
            }));
            yield updatePriority(tagId, newPriority);
        }
    });

    return function shouldPriorityUpdate(_x8, _x9, _x10) {
        return _ref7.apply(this, arguments);
    };
})();

/**
 * 更新标签值得优先级
 * @param tagId
 * @param priority
 * @returns {*}
 */
let updatePriority = exports.updatePriority = (tagId, priority) => {
    return _models.sequelize.query(`UPDATE first_party_tag_value SET 
        priority = CASE id
        ${priority.map((item, index) => {
        return `WHEN '${item.id}' THEN ${index + 1}`;
    }).join('\n\t')}
        END 
        WHERE id IN (${priority.map(item => `'${item.id}'`)})`);
};

/**
 * 更新标签
 * @param id
 * @param model
 */
let update = exports.update = (id, model) => {
    let obj = (0, _lodash.pick)(model, ['name', 'tagType', 'tagGroupId', 'updatePeriod', 'remark', 'status', 'isUsedForInsight', 'isUsedForSegment', 'chartType', 'expires']);
    return _models.FirstPartyTag.update(obj, {
        where: { id }
    });
};

/**
 * 移除标签
 * @param id
 */
let remove = exports.remove = id => {
    return _models.FirstPartyTag.update({
        status: TagStatus.Deleted
    }, {
        where: { id }
    });
};

/**
 * 判斷标签是否有正在生成的标签
 * @param tagId
 * @returns {*}
 */
let isTagValueGenerating = exports.isTagValueGenerating = tagId => {
    return _models.FirstPartyTagValue.count({
        where: {
            status: Status.Normal,
            dataStatus: TagValueStatus.Generating,
            tagId: tagId
        }
    });
};

let removeTagValue = exports.removeTagValue = tagId => {
    return _models.FirstPartyTagValue.update({
        status: TagStatus.Deleted
    }, {
        where: {
            tagId
        }
    });
};

/**
 * 开启关闭标签
 * @param modelName
 * @param id
 * @param openStatus
 * @returns {*}
 */
/*
export let closeOrOpen = (modelName,id,openStatus) => {
    return model[modelName].update({
        status: TagStatus[openStatus]
    },{
        where: {id}
    });
};
*/

let getFirstTaglistByIds = exports.getFirstTaglistByIds = ids => {
    return _models.FirstPartyTag.findAll({
        attributes: ['id', 'name', 'status', 'remark'],
        where: {
            id: {
                $in: ids
            }
        },
        raw: true
    });
};

let getThirdTaglistByIds = exports.getThirdTaglistByIds = ids => {
    return _models.ThirdPartyTag.findAll({
        attributes: ['id', 'name', 'status'],
        where: {
            id: {
                $in: ids
            }
        },
        raw: true
    });
};
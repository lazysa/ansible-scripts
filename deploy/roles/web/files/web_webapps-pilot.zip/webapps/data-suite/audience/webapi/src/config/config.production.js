'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});


let config = {
    env: 'production',
    mongodb: {
        url: 'mongodb://127.0.0.1/webapi'
    },
    mysql: {
        host: 'cc-mysql-test.c5s7vgxpiybm.rds.cn-north-1.amazonaws.com.cn',
        poolSize: 5,
        user: 'prs_user',
        password: '$ef#eF134Q',
        database: 'audience',
        assetsDatabase: 'data_assets'
    },
    allowOrigins: ["http://localhost:9102", "http://localhost:6060", "http://localhost:8080"],
    whitePaths: ["/const", '/metrics/campaign', '/api/v1/business', "/fileToken", "/segment/campaign", "/segment/site", "/segment/download"],
    authAPiPath: "http://localhost:9105/",
    authAppId: "audience",
    port: 9102,
    uploadDir: "/mnt/tmp",
    fileDir: "/mnt/webapps/files/audience",
    logDir: "/mnt/logs/audience/webapi",
    logLevel: 'info',
    poolSize: 200,
    reportApiPath: "http://localhost:10085/v1/audience",
    reportDownloadApiPath: "http://web-dev.chiefclouds.com:9100",
    dataServiceApiPath: "http://web-dev.chiefclouds.com:8082/v1/dataservice",
    reportBusinessApiPath: "http://localhost:10088/v1/audience",
    reportBusinessApiSecret: "ucmjwlyhdi2k6w5pxvfgvi",
    analyticsApiPath: "http://web-dev.chiefclouds.com/!/analytics/api",
    analyticsApiSecret: "ucmjwlyhdi2k6w5pxvfgvi",
    dataAssetsApiPath: "http://web-dev.chiefclouds.com/!/data-assets/api",
    dataAssetsApiSecret: "hx4zg1pli8b2aboqi79zfr",
    apiTimeout: 60000,
    apiSecret: "ucmjwlyhdi2k6w5pxvfgvi",
    s3: {
        accessKeyId: "",
        secretAccessKey: "",
        region: "cn-north-1",
        bucket: "chiefclouds-dev-transfer" //s3的桶
    },
    HDFS: {
        path: 'hdfs:///tmp/audience-webapi'
    },
    fsProtocol: 's3'
};

exports.default = config;
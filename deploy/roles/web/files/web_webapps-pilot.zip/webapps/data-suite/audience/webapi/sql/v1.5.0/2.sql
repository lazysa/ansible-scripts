
DROP TABLE IF EXISTS `insight_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insight_field` (
  `id` varchar(255) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `category` int(10) NOT NULL,
  `data_source_id` int(10) DEFAULT NULL,
  `col_num` int(10) NOT NULL,
  `col_type` varchar(255) NOT NULL DEFAULT 'number',
  `is_default` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`col_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
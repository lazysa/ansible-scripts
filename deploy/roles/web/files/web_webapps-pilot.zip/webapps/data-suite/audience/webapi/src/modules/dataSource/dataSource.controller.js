'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.idFieldList = exports.idMetricList = exports.mergeList = exports.InsightFieldList = exports.updatePeriodFirstlist = exports.behaviourTypeList = exports.chartTypeList = exports.updatePeriodlist = exports.list = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _consts = require('../../config/consts');

var _helper = require('../common/util/helper');

var _dataSourceService = require('./dataSource.service.js');

var dataSourceService = _interopRequireWildcard(_dataSourceService);

var _api = require('../common/api');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let list = exports.list = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = yield dataSourceService.list();
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function list(_x) {
        return _ref.apply(this, arguments);
    };
})();
/**
 * get updatePeriod by dataSourceId
 *
 */
let updatePeriodlist = exports.updatePeriodlist = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let id = ctx.params.dataSourceId;
            data = yield dataSourceService.updatePeriodlist(id);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function updatePeriodlist(_x2) {
        return _ref2.apply(this, arguments);
    };
})();
let chartTypeList = exports.chartTypeList = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = yield dataSourceService.chartTypeList();
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function chartTypeList(_x3) {
        return _ref3.apply(this, arguments);
    };
})();
let behaviourTypeList = exports.behaviourTypeList = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = yield dataSourceService.behaviourTypeList();
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function behaviourTypeList(_x4) {
        return _ref4.apply(this, arguments);
    };
})();

let updatePeriodFirstlist = exports.updatePeriodFirstlist = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = _consts.Enums.SegmentUpdatePeriod;
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function updatePeriodFirstlist(_x5) {
        return _ref5.apply(this, arguments);
    };
})();
let InsightFieldList = exports.InsightFieldList = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = yield dataSourceService.InsightFieldList();
            data = data.map(function ({ colType, id, name, category, dataSourceId, isDefault }) {
                return { id, name, category, dataSourceId, isDefault, vtype: colType };
            });
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function InsightFieldList(_x6) {
        return _ref6.apply(this, arguments);
    };
})();

let mergeList = exports.mergeList = (() => {
    var _ref7 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = yield dataSourceService.mergeList();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function mergeList(_x7) {
        return _ref7.apply(this, arguments);
    };
})();

let idMetricList = exports.idMetricList = (() => {
    var _ref8 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = yield dataSourceService.IdMetricList();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function idMetricList(_x8) {
        return _ref8.apply(this, arguments);
    };
})();

let idFieldList = exports.idFieldList = (() => {
    var _ref9 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = yield _api.DataAssetsWebApi.getFirstPartyUserIdType();
            data = data.map(function ({ userIdTypeName, userIdTypeDesc }) {
                return { id: userIdTypeName, name: userIdTypeDesc };
            });
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function idFieldList(_x9) {
        return _ref9.apply(this, arguments);
    };
})();
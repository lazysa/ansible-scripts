'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getTagGroupByCategory = exports.getTagGroupListByIds = exports.removeTagToOther = exports.isHaveChildren = exports.remove = exports.updateSequence = exports.update = exports.create = exports.thirdPartyList = exports.getThirdTagCountByGroupList = exports.getFirstTagCountByGroupList = exports.firstPartyList = exports.constructorData = undefined;

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _models = require('../common/models');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let { TagGroupStatus, Status, DataSourceCategory, OtherStatus, TagStatus } = _consts.Enums;

let constructorData = exports.constructorData = (res, parentIdGroup) => {
    for (let item of res) {
        if (item.id && parentIdGroup[item.id]) {
            item.children = constructorData(parentIdGroup[item.id], parentIdGroup);
        }
    }
    return res;
};

let firstPartyList = exports.firstPartyList = () => {
    return _models.TagGroup.findAll({
        attributes: ['id', 'name', 'sequence', 'parentId'],
        where: {
            category: DataSourceCategory.FirstParty,
            status: TagGroupStatus.Normal
        },
        order: [['sequence', 'ASC']],
        raw: true
    });
};

let getFirstTagCountByGroupList = exports.getFirstTagCountByGroupList = () => {
    return _models.FirstPartyTag.findAll({
        attributes: [[_models.sequelize.fn('count', '*'), 'tagCount'], 'tagGroupId'],
        where: {
            status: TagStatus.Open,
            recordViewable: Status.Normal
        },
        group: ['tagGroupId'],
        raw: true
    });
};

let getThirdTagCountByGroupList = exports.getThirdTagCountByGroupList = () => {
    return _models.ThirdPartyTag.findAll({
        attributes: [[_models.sequelize.fn('count', '*'), 'tagCount'], 'tagGroupId'],
        where: {
            status: TagStatus.Open
        },
        group: ['tagGroupId'],
        raw: true
    });
};

let thirdPartyList = exports.thirdPartyList = dataSourceId => {
    return _models.TagGroup.findAll({
        attributes: ['id', 'name', 'sequence', 'parentId'],
        where: {
            dataSourceId: dataSourceId,
            category: DataSourceCategory.ThirdParty,
            status: TagGroupStatus.Normal
        },
        order: [['sequence', 'ASC']],
        raw: true
    });
};

/**
 * 获取分组自增
 * @returns {*}
 */
let getSeq = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* () {
        let currentTagGroupId;
        let seq;
        do {
            let instance = yield _models.Seq.findOne({ where: { id: 'tagGroupId' } });
            seq = yield instance.increment('seq', {
                by: 1
            });
            currentTagGroupId = yield _models.TagGroup.findOne({
                where: { id: 'FTG' + seq.seq }
            });
        } while (currentTagGroupId);
        return seq;
    });

    return function getSeq() {
        return _ref.apply(this, arguments);
    };
})();

let create = exports.create = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (model) {
        let seq = yield getSeq();
        (0, _assign2.default)(model, {
            id: 'FTG' + seq.seq
        });
        return _models.TagGroup.create(model);
    });

    return function create(_x) {
        return _ref2.apply(this, arguments);
    };
})();

let update = exports.update = (id, model) => {
    let updateModel = (0, _lodash.pick)(model, ['name', 'status', 'parentId', 'sequence']);
    return _models.TagGroup.update(updateModel, {
        where: { id }
    });
};

let updateSequence = exports.updateSequence = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (id, parentId, afterId) {
        let needUpdateSequence;
        if (afterId) {
            let afterRecord = yield _models.TagGroup.findOne({
                where: { id: afterId },
                raw: true
            });
            needUpdateSequence = afterRecord.sequence;
        } else {
            let where = {};
            if (parentId) {
                where = {
                    parentId
                };
            } else {
                where = {
                    parentId: {
                        $eq: null
                    }
                };
            }
            let maxSequenceRecord = yield _models.TagGroup.findOne({
                where,
                order: [['sequence', 'DESC']],
                raw: true
            });
            if (!maxSequenceRecord) {
                let parentIdRecord = yield _models.TagGroup.findOne({
                    where: {
                        id: parentId
                    },
                    raw: true
                });
                needUpdateSequence = parentIdRecord.sequence + 1;
            } else {
                needUpdateSequence = maxSequenceRecord.sequence + 1;
            }
        }
        let instance = yield _models.TagGroup.findAll({
            where: {
                sequence: { $gte: needUpdateSequence }
            }
        });
        if (instance && instance.length > 0) {
            for (let instanceItem of instance) {
                yield instanceItem.increment('sequence');
            }
        }
        return needUpdateSequence;
    });

    return function updateSequence(_x2, _x3, _x4) {
        return _ref3.apply(this, arguments);
    };
})();

let remove = exports.remove = id => {
    return _models.TagGroup.update({
        status: TagGroupStatus.Deleted
    }, {
        where: { id }
    });
};

let isHaveChildren = exports.isHaveChildren = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (parentId) {
        return _models.TagGroup.findOne({
            where: {
                parentId,
                status: TagGroupStatus.Normal
            },
            raw: true
        });
    });

    return function isHaveChildren(_x5) {
        return _ref4.apply(this, arguments);
    };
})();
/**
 * 把标签组移动到 ‘其它’组
 * @param tagGroupId
 * @returns {boolean}
 */
let removeTagToOther = exports.removeTagToOther = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (tagGroupId) {
        let otherTagGroup = yield _models.TagGroup.findOne({
            attributes: ['id'],
            where: {
                id: OtherStatus.tag
            },
            raw: true
        });

        if (otherTagGroup && otherTagGroup.id == tagGroupId) {
            throw new _errors2.default.TagGroupCannotDelete();
        }
        if (otherTagGroup) {
            yield _models.FirstPartyTag.update({
                tagGroupId: otherTagGroup.id
            }, {
                where: {
                    tagGroupId
                }
            });
            return true;
        }
        return false;
    });

    return function removeTagToOther(_x6) {
        return _ref5.apply(this, arguments);
    };
})();

/**
 * 获取标签组list
 * @param ids
 * @returns {*}
 */
let getTagGroupListByIds = exports.getTagGroupListByIds = ids => {
    return _models.TagGroup.findAll({
        attributes: ['id', 'name'],
        where: {
            id: { $in: (0, _lodash.uniq)(ids) },
            status: TagGroupStatus.Normal
        }
    });
};

/**
 * 根据来源获取分组id
 * @param category
 * @param dataSourceId
 * @returns {*}
 */
let getTagGroupByCategory = exports.getTagGroupByCategory = (category, dataSourceId) => {
    let where = {
        category,
        status: TagGroupStatus.Normal
    };

    if (category == DataSourceCategory.ThirdParty && dataSourceId) {
        (0, _assign2.default)(where, {
            dataSourceId
        });
    }
    return _models.TagGroup.findAll({
        attributes: ['id', 'name'],
        where,
        raw: true
    });
};
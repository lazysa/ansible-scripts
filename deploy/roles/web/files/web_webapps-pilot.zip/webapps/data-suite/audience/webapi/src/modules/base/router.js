'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _const = require('./const.controller');

var constController = _interopRequireWildcard(_const);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)();

/**
 * @apiVersion 1.0.0
 * @api {get} /const/enums 枚举
 * @apiName getConstEnums
 * @apiGroup Base
 */
router.get('/const/enums', constController.getEnums);
router.get('/const/options', constController.getOptions);
router.get('/const/optionMaps', constController.getoptionMaps);
router.get('/const/kvmap', constController.getKVMap);
router.get('/const/vkmap', constController.getVKMap);
router.get('/const/vnmap', constController.getVNMap);
router.get('/operator/list', constController.operatorList);
router.get('/sysUserIdColumns/:tableName', constController.sysUserIdColumnsListByTableName);

// router.get('/test/download', constController.testDownload);

exports.default = router;
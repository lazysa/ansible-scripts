'use strict';

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('analytics_report_default_segment', {
        id: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            defaultValue: null
        },
        segmentId: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'segment_id'
        },
        status: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        },
        isCampaignDefault: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 0,
            field: 'is_campaign_default'
        },
        isSiteDefault: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 0,
            field: 'is_site_default'
        }

    }, {
        tableName: 'analytics_report_default_segment',
        timestamps: false
    });
};
/*
Navicat MySQL Data Transfer

Source Server         : dev
Source Server Version : 50711
Source Host           : cc-mysql-test.c5s7vgxpiybm.rds.cn-north-1.amazonaws.com.cn:3306
Source Database       : audience

Target Server Type    : MYSQL
Target Server Version : 50711
File Encoding         : 65001

Date: 2017-03-17 16:52:40
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for behaviour_type
-- ----------------------------
DROP TABLE IF EXISTS `behaviour_type`;
CREATE TABLE `behaviour_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(4) NOT NULL COMMENT '行为类型\n1 站点互动\n2 广告行为\n3 邮件互动\n4 社交互动\n5 表单互动',
  `name` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of behaviour_type
-- ----------------------------
INSERT INTO `behaviour_type` VALUES ('1', '1', '广告互动', 'web');
INSERT INTO `behaviour_type` VALUES ('2', '2', '网站互动', 'picture_in_picture');
INSERT INTO `behaviour_type` VALUES ('5', '5', '表单提交', 'assignment');
SET FOREIGN_KEY_CHECKS=1;

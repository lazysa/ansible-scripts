ALTER TABLE `audience`.`segment`
ADD COLUMN `error_code` VARCHAR(255) NULL AFTER `record_editable`;

ALTER TABLE `audience`.`insight_info`
ADD COLUMN `error_code` VARCHAR(255) NULL AFTER `data_status`;

'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.reportSegment = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

// import {
//     Enums
// } from '../../../../config/consts';
// const {Status} = Enums;
let reportSegment = exports.reportSegment = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* () {
        let idUpdatedAtMap = {},
            idCreatedAtMap = {};
        let campaignList = yield getCampaignReportList();
        let segmentList = yield getSegmentUpdateInfoByIds(campaignList.map(function (z) {
            return z.segmentId;
        }));
        segmentList.forEach(function ({ id, updatedAt, createdAt }) {
            idUpdatedAtMap[id] = updatedAt;
            idCreatedAtMap[id] = createdAt;
        });
        return campaignList.map(function ({ segmentId, status }) {
            return {
                status,
                id: segmentId,
                type: 1,
                lastChanged: idUpdatedAtMap[segmentId],
                settleTime: idCreatedAtMap[segmentId]
            };
        });
    });

    return function reportSegment() {
        return _ref.apply(this, arguments);
    };
})();

exports.getCampaignReportList = getCampaignReportList;
exports.getSegmentUpdateInfoByIds = getSegmentUpdateInfoByIds;
exports.getHash = getHash;

var _models = require('../../../common/models');

var _jssha = require('jssha');

var _jssha2 = _interopRequireDefault(_jssha);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function getCampaignReportList() {
    return _models.CampaignReport.findAll({
        attributes: ['segmentId', 'status']
    });
}

function getSegmentUpdateInfoByIds(ids) {
    return _models.Segment.findAll({
        attributes: ['id', 'updatedAt', 'createdAt'],
        where: {
            id: {
                $in: ids
            }
        }
    });
}

function getHash(timestamp, randomStr, apiSecret) {
    let shaObj = new _jssha2.default("SHA-512", "TEXT");
    shaObj.update('apiSecret=' + apiSecret + '&randomStr=' + randomStr + '&timestamp=' + timestamp);
    return shaObj.getHash("HEX");
}
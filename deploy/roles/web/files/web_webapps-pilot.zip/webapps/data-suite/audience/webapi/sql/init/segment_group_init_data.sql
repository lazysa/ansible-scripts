--初始化人群组
 INSERT INTO `audience`.`segment_group` (`id`,`sequence`, `name`,`status`,`is_default` ) VALUES 
 ('1','1','其它', '1','1')
    ON DUPLICATE KEY UPDATE sequence='1',name='其它',status='1',is_default='1';

 INSERT INTO `audience`.`segment_group` (`id`,`sequence`, `name`,`status`,`is_default` ) VALUES 
 ('2','2','营销触达人群', '1','1')
    ON DUPLICATE KEY UPDATE sequence='2',name='营销触达人群',status='1',is_default='1';  

 INSERT INTO `audience`.`segment_group` (`id`,`sequence`, `name`,`status`,`is_default`,`parent_id` ) VALUES 
 ('3','3','活动人群', '1','1','2')
    ON DUPLICATE KEY UPDATE sequence='3',name='活动人群',status='1',is_default='1',parent_id='2';  


 INSERT INTO `audience`.`segment_group` (`id`,`sequence`, `name`,`status`,`is_default`,`parent_id` ) VALUES 
 ('4','4','看过', '1','1','3')
    ON DUPLICATE KEY UPDATE sequence='4',name='看过',status='1',is_default='1',parent_id='3';  

    
 INSERT INTO `audience`.`segment_group` (`id`,`sequence`, `name`,`status`,`is_default`,`parent_id` ) VALUES 
 ('5','5','点过', '1','1','3')
    ON DUPLICATE KEY UPDATE sequence='5',name='点过',status='1',is_default='1',parent_id='3';  


    
 INSERT INTO `audience`.`segment_group` (`id`,`sequence`, `name`,`status`,`is_default`,`parent_id` ) VALUES 
 ('6','6','到站', '1','1','3')
    ON DUPLICATE KEY UPDATE sequence='6',name='到站',status='1',is_default='1',parent_id='3';  

    
 INSERT INTO `audience`.`segment_group` (`id`,`sequence`, `name`,`status`,`is_default`,`parent_id` ) VALUES 
 ('7','7','站点人群', '1','1','2')
    ON DUPLICATE KEY UPDATE sequence='7',name='站点人群',status='1',is_default='1',parent_id='2'; 

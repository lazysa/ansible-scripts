ALTER TABLE `audience`.`first_party_tag_value`
ADD COLUMN `type` TINYINT(4) NOT NULL DEFAULT 1 AFTER `tag_id`,
ADD COLUMN `tag_value_rules` JSON NULL AFTER `type`;

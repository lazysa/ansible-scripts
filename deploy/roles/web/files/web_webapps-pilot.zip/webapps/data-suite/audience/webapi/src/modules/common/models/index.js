'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.TagValueUploadLog = exports.TagRelyOn = exports.DataTypeHasOperator = exports.Operator = exports.ResourceTeam = exports.ReportTask = exports.ChartType = exports.TagValueOriginal = exports.UserIdMappingThirdPartyId = exports.InsightField = exports.UpdatePeriod = exports.BehaviourType = exports.AnalyticsReportDefaultSegment = exports.CampaignReport = exports.IdMergeReport = exports.InsightInfo = exports.SegmentExport = exports.Segment = exports.ThirdPartyTagValue = exports.ThirdPartyTag = exports.FirstPartyTagValue = exports.FirstPartyTag = exports.SegmentGroup = exports.TagGroup = exports.TagValueGroup = exports.Seq = exports.MergeRule = exports.DataLink = exports.DataSource = exports.Site = exports.City = exports.Campaign = exports.MetaObjectField = exports.MetaObject = exports.assetsSequelize = exports.sequelize = undefined;

var _meta = require('./meta.object');

Object.defineProperty(exports, 'MetaObject', {
    enumerable: true,
    get: function () {
        return _interopRequireDefault(_meta).default;
    }
});

var _metaObject = require('./meta.object.field');

Object.defineProperty(exports, 'MetaObjectField', {
    enumerable: true,
    get: function () {
        return _interopRequireDefault(_metaObject).default;
    }
});

var _campaign = require('./campaign');

Object.defineProperty(exports, 'Campaign', {
    enumerable: true,
    get: function () {
        return _interopRequireDefault(_campaign).default;
    }
});

var _city = require('./city');

Object.defineProperty(exports, 'City', {
    enumerable: true,
    get: function () {
        return _interopRequireDefault(_city).default;
    }
});

var _site = require('./site');

Object.defineProperty(exports, 'Site', {
    enumerable: true,
    get: function () {
        return _interopRequireDefault(_site).default;
    }
});

var _sequelize = require('sequelize');

var _sequelize2 = _interopRequireDefault(_sequelize);

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _path = require('path');

var _log = require('../core/log');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let dbConfig = _config2.default.mysql;
/**
 * 替换promise，连接mongodb
 */
_mongoose2.default.Promise = global.Promise;
_mongoose2.default.connect(_config2.default.mongodb.url, function (err) {
    if (err) {
        _log.log.error({
            type: "mongodb",
            err: err
        });
    }
});

let sequelize = exports.sequelize = new _sequelize2.default(dbConfig.database, dbConfig.user, dbConfig.password, {
    host: dbConfig.host,
    dialect: 'mysql',
    pool: {
        max: dbConfig.poolSize,
        min: 0,
        idle: 10000,
        validateConnection: function () {}
    },
    // logging:false,
    timezone: '+08:00',
    define: {
        underscored: true,
        // timestamps: false,
        hooks: {
            //http://docs.sequelizejs.com/en/latest/docs/hooks/
            beforeBulkCreate: function (rows) {
                rows.forEach(function (row) {
                    if (typeof row.status == 'undefined' || row.status == null) {
                        row.status = 1;
                    }
                    if (typeof row.isDeleted == 'undefined' || row.isDeleted == null) {
                        row.isDeleted = 0;
                    }
                });
            },
            beforeValidate: function (row) {
                if (typeof row.status == 'undefined' || row.status == null) {
                    row.status = 1;
                }
                if (typeof row.isDeleted == 'undefined' || row.isDeleted == null) {
                    row.isDeleted = 0;
                }
            }
        }
    }
});

let assetsSequelize = exports.assetsSequelize = new _sequelize2.default(dbConfig.assetsDatabase, dbConfig.user, dbConfig.password, {
    host: dbConfig.host,
    dialect: 'mysql',
    pool: {
        max: dbConfig.poolSize,
        min: 0,
        idle: 10000
    }
});
const audienceDealError = errors => {
    _log.log.info({
        type: "Mysql",
        err: errors
    });
    // sequelize.release();
};
const dataAssetDealError = errors => {
    _log.log.info({
        type: "Mysql",
        err: errors
    });
    // sequelize.release();
};

sequelize.authenticate().catch(audienceDealError);
assetsSequelize.authenticate().catch(dataAssetDealError);
// sequelize.on('error',audienceDealError);
// assetsSequelize.on('error',dataAssetDealError);

process.on('SIGUSR2', function () {
    sequelize.close();
    assetsSequelize.close();
});
/**
 * analytics 对象，对象字段表
 */


/**
 * data-assets 数据源和分发表
 * @type {Model}
 */
let DataSource = exports.DataSource = assetsSequelize.import((0, _path.join)(__dirname, './data.source'));
let DataLink = exports.DataLink = assetsSequelize.import((0, _path.join)(__dirname, './data.link'));
let MergeRule = exports.MergeRule = assetsSequelize.import((0, _path.join)(__dirname, './merge.rule'));
/**
 * audience表
 * @type {Model}
 */
let Seq = exports.Seq = sequelize.import((0, _path.join)(__dirname, './seq'));
let TagValueGroup = exports.TagValueGroup = sequelize.import((0, _path.join)(__dirname, './tag.value.group'));
let TagGroup = exports.TagGroup = sequelize.import((0, _path.join)(__dirname, './tag.group'));
let SegmentGroup = exports.SegmentGroup = sequelize.import((0, _path.join)(__dirname, './segment.group'));
let FirstPartyTag = exports.FirstPartyTag = sequelize.import((0, _path.join)(__dirname, './first.party.tag'));
let FirstPartyTagValue = exports.FirstPartyTagValue = sequelize.import((0, _path.join)(__dirname, './first.party.tag.value'));
let ThirdPartyTag = exports.ThirdPartyTag = sequelize.import((0, _path.join)(__dirname, './third.party.tag'));
let ThirdPartyTagValue = exports.ThirdPartyTagValue = sequelize.import((0, _path.join)(__dirname, './third.party.tag.value'));
let Segment = exports.Segment = sequelize.import((0, _path.join)(__dirname, './segment'));
let SegmentExport = exports.SegmentExport = sequelize.import((0, _path.join)(__dirname, './segment.export'));
// export let SegmentExplore = sequelize.import(join(__dirname, './segment.explore'));
let InsightInfo = exports.InsightInfo = sequelize.import((0, _path.join)(__dirname, './insight.info'));
let IdMergeReport = exports.IdMergeReport = sequelize.import((0, _path.join)(__dirname, './id.merge.report'));
let CampaignReport = exports.CampaignReport = sequelize.import((0, _path.join)(__dirname, './campaign.report'));
let AnalyticsReportDefaultSegment = exports.AnalyticsReportDefaultSegment = sequelize.import((0, _path.join)(__dirname, './analytics.report.default.segment'));
// export let Explore = sequelize.import(join(__dirname, './explore'));
let BehaviourType = exports.BehaviourType = sequelize.import((0, _path.join)(__dirname, './behaviour.type'));
// export let ExploreId = sequelize.import(join(__dirname, './explore.id'));
let UpdatePeriod = exports.UpdatePeriod = sequelize.import((0, _path.join)(__dirname, './update.period'));
let InsightField = exports.InsightField = sequelize.import((0, _path.join)(__dirname, './insight.field'));
let UserIdMappingThirdPartyId = exports.UserIdMappingThirdPartyId = sequelize.import((0, _path.join)(__dirname, './user.id.mapping.third.party.id'));
let TagValueOriginal = exports.TagValueOriginal = sequelize.import((0, _path.join)(__dirname, './tag.value.original'));
let ChartType = exports.ChartType = sequelize.import((0, _path.join)(__dirname, './chart.type'));
let ReportTask = exports.ReportTask = sequelize.import((0, _path.join)(__dirname, './report.task'));
let ResourceTeam = exports.ResourceTeam = sequelize.import((0, _path.join)(__dirname, './resource.team'));
let Operator = exports.Operator = sequelize.import((0, _path.join)(__dirname, './operator'));
let DataTypeHasOperator = exports.DataTypeHasOperator = sequelize.import((0, _path.join)(__dirname, './data.type.has.operator'));
let TagRelyOn = exports.TagRelyOn = sequelize.import((0, _path.join)(__dirname, './tag.rely.on'));
let TagValueUploadLog = exports.TagValueUploadLog = sequelize.import((0, _path.join)(__dirname, './tag.value.upload.log'));
// TagRelyOn.removeAttribute('id');//去掉id
// export let BasicInfoField = sequelize.import(join(__dirname, './basic.info.field'));
'use strict';

var _sequelize = require('sequelize');

var _sequelize2 = _interopRequireDefault(_sequelize);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Data_source', {
        id: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: false,
            autoIncrement: false,
            primaryKey: true,
            defaultValue: null
        },
        name: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null
        },
        status: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        },
        rollerType: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            field: 'roller_type'
        },
        hasTag: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: 'has_tag'
        },
        maxSegmentFieldMappingCount: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            field: 'max_segment_field_mapping_count'
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'created_at'
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'updated_at'
        }
    }, {
        tableName: 'data_hub'
    });
};
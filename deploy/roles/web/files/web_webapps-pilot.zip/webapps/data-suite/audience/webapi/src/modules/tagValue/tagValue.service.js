'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.preview = exports.convertTagValueRules = exports.getBehaviorMetrics = exports.getBehaviorConditions = exports.queryRelyOnSegmentId = exports.queryRelyOnInfo = exports.getThirdTagValuelistByIds = exports.getFirstTagValuelistByIds = exports.getGroupListByIds = exports.getTagValueParentById = exports.remove = exports.isTagValueGenerating = exports.isTagValueUsedByCampaignOrSite = exports.queryThirdTagValue = exports.query = exports.displaySequenceUpdate = exports.getThirdDisplaySequenceArray = exports.getFirstDisplaySequenceArray = exports.update = exports.updateTagValueStatusToGenerating = exports.shouldUpdateTagValueStatus = exports.create = exports.validateSqlSyntax = exports.valiedateMetaObject = exports.updateTagRelyOn = exports.bulkCreateTagValue = exports.bulkCreateDefaultBatchTagValue = exports.createTagValueUploadLog = exports.updateConstructorTagAndTagValue = exports.shouldUpdateTagValueRulesStatus = exports.createConstructorTagAndTagValue = exports.getMetaObjectTree = exports.getMetaObjectFieldByMetaObjectIds = exports.getMetaObjectList = exports.getSeq = exports.thirdPartyPages = exports.firstPartyPages = exports.thirdPartyTagValueListByTagId = exports.firstPartyTagValueListByTagId = exports.thirdPartyList = exports.firstPartyList = exports.getWhere = undefined;

var _is = require('babel-runtime/core-js/object/is');

var _is2 = _interopRequireDefault(_is);

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _keys = require('babel-runtime/core-js/object/keys');

var _keys2 = _interopRequireDefault(_keys);

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

var _extends2 = require('babel-runtime/helpers/extends');

var _extends3 = _interopRequireDefault(_extends2);

var _objectWithoutProperties2 = require('babel-runtime/helpers/objectWithoutProperties');

var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

/**
 * 创建依赖标签
 * @param tagId
 * @return {Promise.<*>}
 */
let createBehaviorRelyOnTagId = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (tagId) {
        let tagIdRecord = yield (0, _tag.query)(tagId);
        let tagModel = {
            name: `rely_by_${tagIdRecord && tagIdRecord.name}`,
            updatePeriod: tagIdRecord.updatePeriod,
            expires: tagIdRecord.expires,
            tagGroupId: OtherStatus.tag,
            tagType: TagType.Multiple,
            recordViewable: Status.Deleted,
            isUsedForInsight: Status.Deleted,
            tagLevel: TagLevel.behaviorRuleHidden
        };
        let relyOnTagRecord = yield (0, _tag.createSingleTag)(tagModel);
        return relyOnTagRecord && relyOnTagRecord.id;
    });

    return function createBehaviorRelyOnTagId(_x2) {
        return _ref5.apply(this, arguments);
    };
})();

/**
 * 创建依赖的标签值
 * @param rules
 * @param relyOnTagId
 * @return {Promise.<{type: *, tagId: *, value: [null]}>}
 */


let createBehaviorRelyOnTagValue = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (rules, relyOnTagId) {
        let tagValueRecord = {
            name: `rely_on_tag_${relyOnTagId}`,
            type: TagValueType.behavior,
            tagId: relyOnTagId,
            tagValueRules: {
                type: TagValueType.behavior,
                rules
            }
        };
        let record = yield create(tagValueRecord);
        return {
            type: TagValueType.behavior,
            tagId: relyOnTagId,
            value: [record && record.id]
        };
    });

    return function createBehaviorRelyOnTagValue(_x3, _x4) {
        return _ref6.apply(this, arguments);
    };
})();

/**
 * 更新
 * @param id
 * @param rules
 * @param relyOnTagId
 * @return {Promise.<{type: *, tagId: *, value: [null]}>}
 */


let updateBehaviorRelyOnTagValue = (() => {
    var _ref7 = (0, _asyncToGenerator3.default)(function* (id, rules, relyOnTagId) {
        let tagValueRecord = {
            tagValueRules: {
                type: TagValueType.behavior,
                rules
            }
        };
        yield update(id, tagValueRecord);
        return {
            type: TagValueType.behavior,
            tagId: relyOnTagId,
            value: [id]
        };
    });

    return function updateBehaviorRelyOnTagValue(_x5, _x6, _x7) {
        return _ref7.apply(this, arguments);
    };
})();

/**
 * 处理构造标签 创建标签
 * @param tagValueRules
 * @param tagId
 * @return {Promise.<{rules: *, type: *}>}
 */


let createConstructorTagAndTagValue = exports.createConstructorTagAndTagValue = (() => {
    var _ref8 = (0, _asyncToGenerator3.default)(function* (tagValueRules, tagId) {
        let { rules, type } = tagValueRules;
        let relyOnTagId = null;
        let relyOnTagValueId = [];
        for (let keyPath of ['includes', 'excludes']) {
            for (let includesItem of (0, _lodash.result)(rules, keyPath)) {
                for (let [index, ruleItem] of includesItem.entries()) {
                    let { type } = ruleItem,
                        rules = (0, _objectWithoutProperties3.default)(ruleItem, ['type']);
                    if (type === TagValueType.behavior) {
                        if (!relyOnTagId) relyOnTagId = yield createBehaviorRelyOnTagId(tagId);
                        let tempRule = yield createBehaviorRelyOnTagValue(rules, relyOnTagId);
                        includesItem[index] = tempRule;
                        relyOnTagValueId.push(...tempRule.value);
                    }
                }
            }
        }
        return {
            tagValueRules: {
                rules,
                type
            },
            tagId,
            relyOnTagId,
            relyOnTagValueId
        };
    });

    return function createConstructorTagAndTagValue(_x8, _x9) {
        return _ref8.apply(this, arguments);
    };
})();

let shouldUpdateTagValueRulesStatus = exports.shouldUpdateTagValueRulesStatus = (() => {
    var _ref9 = (0, _asyncToGenerator3.default)(function* (newRules, relyOnTagId, relyOnSourceTagValueId, id) {
        let tagValuesList = yield getFirstTagValuelistByIds(relyOnSourceTagValueId, ['id', 'tagValueRules']);
        let map = {};
        tagValuesList.forEach(function (item) {
            let { type, rules } = JSON.parse(item.tagValueRules);
            map[item.id] = (0, _assign2.default)({}, (0, _extends3.default)({}, rules, {
                type
            }), {
                tagId: relyOnTagId,
                value: [item.id]
            });
        });
        let oldRecord = yield query(id);
        let { type, rules: oldRules } = oldRecord && JSON.parse(oldRecord.tagValueRules);
        for (let keyPath of ['includes', 'excludes']) {
            for (let includesItem of (0, _lodash.result)(oldRules, keyPath)) {
                for (let [index, ruleItem] of includesItem.entries()) {
                    let { type, value } = ruleItem;
                    if (type === TagValueType.behavior) {
                        includesItem[index] = map[value[0]];
                    }
                }
            }
        }
        console.log(require('util').inspect((0, _stringify2.default)(oldRules), true, null, true));
        console.log(require('util').inspect((0, _stringify2.default)(newRules), true, null, true));
        let shouldUpdate = _immutable2.default.fromJS(newRules).equals(_immutable2.default.fromJS(oldRules));
        console.log(shouldUpdate);
        if (!shouldUpdate) {
            yield updateTagValueStatusToGenerating([id]);
        }
    });

    return function shouldUpdateTagValueRulesStatus(_x10, _x11, _x12, _x13) {
        return _ref9.apply(this, arguments);
    };
})();

/**
 * 更新
 * @param tagValueRules
 * @param tagId
 * @return {Promise.<{tagValueRules: {rules: *, type: *}, tagId: *, relyOnTagId: *, relyOnTagValueId: Array}>}
 */


let updateConstructorTagAndTagValue = exports.updateConstructorTagAndTagValue = (() => {
    var _ref10 = (0, _asyncToGenerator3.default)(function* (id, tagValueRules, tagId) {
        let { rules, type } = tagValueRules;
        let relyOnRecord = yield _models.TagRelyOn.findOne({
            where: {
                tagValueId: id,
                tagId
            },
            raw: true
        });
        let relyOnTagId = relyOnRecord && relyOnRecord.relyOnTagId;
        let relyOnSourceTagValueId = relyOnRecord && JSON.parse(relyOnRecord.relyOnTagValueId);
        yield shouldUpdateTagValueRulesStatus(rules, relyOnTagId, relyOnSourceTagValueId, id);
        let relyOnTagValueId = [];
        for (let keyPath of ['includes', 'excludes']) {
            for (let includesItem of (0, _lodash.result)(rules, keyPath)) {
                for (let [index, ruleItem] of includesItem.entries()) {
                    let { type } = ruleItem,
                        rules = (0, _objectWithoutProperties3.default)(ruleItem, ['type']);
                    if (type === TagValueType.behavior) {
                        if (!relyOnTagId) relyOnTagId = yield createBehaviorRelyOnTagId(tagId);
                        let tempRule;
                        if (rules.tagId && rules.value) {
                            tempRule = yield updateBehaviorRelyOnTagValue(rules.value[0], rules, relyOnTagId);
                        } else {
                            tempRule = yield createBehaviorRelyOnTagValue(rules, relyOnTagId);
                        }
                        includesItem[index] = tempRule;
                        relyOnTagValueId.push(...tempRule.value);
                    }
                }
            }
        }

        return {
            tagValueRules: {
                rules,
                type
            },
            tagId,
            relyOnTagId,
            relyOnTagValueId,
            relyOnSourceTagValueId
        };
    });

    return function updateConstructorTagAndTagValue(_x14, _x15, _x16) {
        return _ref10.apply(this, arguments);
    };
})();

/**
 * 创建标签值上传log
 * @param model
 * @return {model}
 */


let createTagValueUploadLog = exports.createTagValueUploadLog = (() => {
    var _ref11 = (0, _asyncToGenerator3.default)(function* (model) {
        let exist = yield _models.TagValueUploadLog.findOne({
            where: { tagId: model.tagId }
        });
        if (exist) {
            yield _models.TagValueUploadLog.update(model, {
                where: { tagId: model.tagId }
            });
            return exist;
        }
        return _models.TagValueUploadLog.create(model);
    });

    return function createTagValueUploadLog(_x17) {
        return _ref11.apply(this, arguments);
    };
})();

let bulkCreateDefaultBatchTagValue = exports.bulkCreateDefaultBatchTagValue = (() => {
    var _ref12 = (0, _asyncToGenerator3.default)(function* (list, metaObject, field, tagId) {
        if (!tagId || !metaObject || !field) return;
        let generateTagValues = function (ruleList) {
            return ruleList.reduce(function (sum, current, index) {
                return sum + `${index > 0 ? ' or ' : ''} ${metaObject}.${field} = '${current.name}'`;
            }, '');
        };
        let map = (0, _lodash.groupBy)(list, 'metaObjectFieldValue');
        let nameList = (0, _keys2.default)(map);
        let len = nameList.length;
        let startSeq, endSeq;
        if (len > 1) {
            let seq = yield getSeq(nameList.length);
            startSeq = seq.startSeq;
            endSeq = seq.endSeq;
        } else {
            startSeq = yield getSeq(nameList.length);
            endSeq = startSeq.seq + 1;
        }
        let priority = yield getPriority(tagId);
        let bulkCreateObj = [];
        for (let i = startSeq, j = 0; i <= endSeq; i++, j++, priority++) {
            let tempNameList = map[nameList[j]];
            let tempValueRules = generateTagValues(tempNameList);
            let tagValueModel = {
                id: "FV" + i,
                tagId,
                priority,
                type: TagValueType.batchDefault,
                name: nameList[j],
                valueRules: tempValueRules,
                parseRules: { [metaObject]: [field] },
                tagValueRules: {
                    type: TagValueType.code,
                    rules: {
                        expression: tempValueRules
                    }
                }
            };
            bulkCreateObj.push(tagValueModel);
        }
        yield _models.FirstPartyTagValue.bulkCreate(bulkCreateObj);
    });

    return function bulkCreateDefaultBatchTagValue(_x18, _x19, _x20, _x21) {
        return _ref12.apply(this, arguments);
    };
})();

/**
 * 通过文件批量新建标签值
 * @param list
 * @param tagId
 * @param flag
 * @param inStorage
 * @return {Promise.<Promise.<Array.<Instance>>|*>}
 */


let bulkCreateTagValue = exports.bulkCreateTagValue = (() => {
    var _ref13 = (0, _asyncToGenerator3.default)(function* (list, tagId, flag, inStorage = 0) {
        let { startSeq, endSeq } = yield getSeq(list.length);
        let priority = yield getPriority(tagId);

        let { valueRules, parseRules } = _uploadTagValue.uploadTagValueRules[inStorage];

        let bulkCreateObj = [];
        for (let i = startSeq, j = 0; i <= endSeq; i++, j++, priority++) {
            let tempValueRules = (0, _lodash.template)(valueRules)({
                flag,
                selectField: list[j].srcName
            });
            let tagValueModel = {
                id: "FV" + i,
                tagId,
                priority,
                type: TagValueType.upload,
                name: list[j].tagValueName,
                valueRules: tempValueRules,
                parseRules: parseRules,
                tagValueRules: {
                    type: TagValueType.code,
                    rules: {
                        expression: tempValueRules
                    }
                }
            };
            bulkCreateObj.push(tagValueModel);
        }
        yield removeUploadTagValue(tagId);
        return _models.FirstPartyTagValue.bulkCreate(bulkCreateObj);
    });

    return function bulkCreateTagValue(_x22, _x23, _x24) {
        return _ref13.apply(this, arguments);
    };
})();

let updateTagRelyOn = exports.updateTagRelyOn = (() => {
    var _ref14 = (0, _asyncToGenerator3.default)(function* ({ tagId, relyOnTagId, relyOnTagValueId }, tagValueId, relyOnSourceTagValueId) {
        if (!tagValueId || !tagId || !relyOnTagId) return;
        let deleteTagValueIds = (0, _lodash.difference)(relyOnSourceTagValueId, relyOnTagValueId);
        if (deleteTagValueIds) yield remove(...deleteTagValueIds);
        return _models.TagRelyOn.update({
            tagId,
            relyOnTagId,
            relyOnTagValueId
        }, {
            where: {
                tagValueId
            }
        });
    });

    return function updateTagRelyOn(_x25, _x26, _x27) {
        return _ref14.apply(this, arguments);
    };
})();

/**
 * 判断是and or 逻辑运算符
 * @param logic
 * @returns {boolean}
 */


let getFirstDisplaySequenceArray = exports.getFirstDisplaySequenceArray = (() => {
    var _ref19 = (0, _asyncToGenerator3.default)(function* (displaySequenceArray) {
        let tagValueRecord = yield query(displaySequenceArray[0].tagValueId);
        return firstPartyTagValueListByTagId(tagValueRecord.tagId);
    });

    return function getFirstDisplaySequenceArray(_x33) {
        return _ref19.apply(this, arguments);
    };
})();

let getThirdDisplaySequenceArray = exports.getThirdDisplaySequenceArray = (() => {
    var _ref20 = (0, _asyncToGenerator3.default)(function* (displaySequenceArray) {
        let tagValueRecord = yield queryThirdTagValue(displaySequenceArray[0].tagValueId);
        return thirdPartyTagValueListByTagId(tagValueRecord.tagId);
    });

    return function getThirdDisplaySequenceArray(_x34) {
        return _ref20.apply(this, arguments);
    };
})();

/**
 * 构造更新list
 * @param displaySequenceArray
 * @param tagValueList
 */


/**
 * 判断标签值是否被analytics活动或站点占用
 * @param tagValueId
 */
let isTagValueUsedByCampaignOrSite = exports.isTagValueUsedByCampaignOrSite = (() => {
    var _ref24 = (0, _asyncToGenerator3.default)(function* (tagValueId) {
        let tagValueRecord = yield query(tagValueId);
        if (!tagValueRecord) return false;
        return _api.AnalyticsWebApi.isTagUsedByCampaignOrSite(tagValueRecord.tagId);
    });

    return function isTagValueUsedByCampaignOrSite(_x37) {
        return _ref24.apply(this, arguments);
    };
})();

/**
 * tagValue是否正在生成中
 * @param id
 */


/**
 * 查询所依赖的type为3的标签值
 * @param tagValueId
 * @return {Promise.<{}>}
 */
let queryRelyOnInfo = exports.queryRelyOnInfo = (() => {
    var _ref26 = (0, _asyncToGenerator3.default)(function* (tagValueId) {
        let map = {};
        let tagRelyOnRecord = yield _models.TagRelyOn.findOne({
            where: {
                tagValueId
            },
            raw: true
        });
        if (tagRelyOnRecord) {
            let data = yield getFirstTagValuelistByIds(JSON.parse(tagRelyOnRecord.relyOnTagValueId), ['id', 'tagValueRules']);
            for (let _ref27 of data) {
                let { id, tagValueRules } = _ref27;

                map[id] = yield convertTagValueRules(tagValueRules);
            }
        }
        return map;
    });

    return function queryRelyOnInfo(_x39) {
        return _ref26.apply(this, arguments);
    };
})();

let queryRelyOnSegmentId = exports.queryRelyOnSegmentId = (() => {
    var _ref28 = (0, _asyncToGenerator3.default)(function* ({ type, rules }) {
        let segmentIds = [];
        for (let item of ['excludes', 'includes']) {
            let tempRule = (0, _lodash.result)(rules, item, [[]]);
            tempRule.forEach(function (r) {
                r.forEach(function (z) {
                    if (z.segmentId) segmentIds.push(z.segmentId);
                });
            });
        }
        let list = yield (0, _segment.getSegmentListByIds)(segmentIds);
        let map = {};
        list.forEach(function ({ id, name }) {
            map[id] = name;
        });
        return map;
    });

    return function queryRelyOnSegmentId(_x40) {
        return _ref28.apply(this, arguments);
    };
})();

/**
 * 构造前端格式
 * @param time
 * @param businessId
 * @return {Promise.<*>}
 */


let getBehaviorTime = (() => {
    var _ref29 = (0, _asyncToGenerator3.default)(function* (time, businessId) {
        let timeOperatorList = yield (0, _const.getOperatorList)(4);
        let defaultUnitList = yield (0, _dimension.getBusinessDataDimensionList)(businessId);
        switch (time.operatorId) {
            case '$offset':
                let unitItem = yield (0, _dimension.getBusinessDataDimensionList)(businessId, time.unit);
                return {
                    detailDisplayValue: `近${time.detailValue.value}${unitItem.name}`,
                    defaultUnitList,
                    detailValue: {
                        value: time.detailValue.value,
                        unit: unitItem
                    },
                    unit: time.unit,
                    operator: timeOperatorList.find(function (z) {
                        return z.operatorId == time.operatorId;
                    })
                };
                break;
            case '$range':
                return {
                    detailDisplayValue: (0, _moment2.default)(time.detailValue.min).format('YYYY-MM-DD') + '-' + (0, _moment2.default)(time.detailValue.max).format('YYYY-MM-DD'),
                    detailValue: {
                        startDate: new Date(time.detailValue.min),
                        endDate: new Date(time.detailValue.max)
                    },
                    defaultUnitList,
                    unit: time.unit,
                    operator: timeOperatorList.find(function (z) {
                        return z.operatorId == time.operatorId;
                    })
                };
                break;
            default:
                return {
                    detailDisplayValue: time.detailValue,
                    detailValue: new Date(time.detailValue),
                    defaultUnitList,
                    unit: time.unit,
                    operator: timeOperatorList.find(function (z) {
                        return z.operatorId == time.operatorId;
                    })
                };
                break;
        }
    });

    return function getBehaviorTime(_x41, _x42) {
        return _ref29.apply(this, arguments);
    };
})();

let getBehaviorConditions = exports.getBehaviorConditions = (() => {
    var _ref30 = (0, _asyncToGenerator3.default)(function* (filterClause, { actionId, subjectId, businessId }) {
        let conditions = [];
        for (let item of filterClause) {
            let tempObj = {};
            tempObj.dimensionAttribute = yield (0, _dimension.getActionDimensionAttrList)({
                subjectId,
                actionId,
                businessId
            }, item.filterId);
            tempObj.operatorList = yield (0, _const.getOperatorList)(tempObj.dimensionAttribute.dataType);
            tempObj.dimensionOptionsList = yield (0, _dimension.getDimensionMetaList)(tempObj.dimensionAttribute.id);
            tempObj.operatorId = item.operatorId;
            tempObj.dimensionOption = item.detailValue;
            conditions.push(tempObj);
        }
        return conditions;
    });

    return function getBehaviorConditions(_x43, _x44) {
        return _ref30.apply(this, arguments);
    };
})();

let getBehaviorMetrics = exports.getBehaviorMetrics = (() => {
    var _ref31 = (0, _asyncToGenerator3.default)(function* (metrics, { actionId, subjectId, businessId }) {
        let convertDetailValue = function (detailValue, dataType) {
            if (dataType === DataType.Percent) {
                return detailValue && typeof detailValue === 'object' ? {
                    max: detailValue.max * 100,
                    min: detailValue.min * 100
                } : detailValue * 100;
            }
            return detailValue;
        };
        let res = [];
        for (let item of metrics) {
            let tempObj = {};
            tempObj.metric = yield (0, _dimension.getActionMetricList)({
                actionId,
                subjectId,
                businessId
            }, item.metricsId);
            tempObj.metricOperatorList = yield (0, _const.getOperatorList)(tempObj.metric.dataType);
            tempObj.operator = tempObj.metricOperatorList.find(function (z) {
                return z.operatorId == item.operatorId;
            });

            tempObj.detailValue = convertDetailValue(item.detailValue, tempObj.metric.dataType);
            res.push(tempObj);
        }
        return res;
    });

    return function getBehaviorMetrics(_x45, _x46) {
        return _ref31.apply(this, arguments);
    };
})();

/**
 * 添加行为规则的展示name
 * @param tagValueRules
 * @return {Promise.<{type, rules}>}
 */


let convertTagValueRules = exports.convertTagValueRules = (() => {
    var _ref32 = (0, _asyncToGenerator3.default)(function* (tagValueRules) {
        try {
            let sRules = JSON.parse(tagValueRules);
            let { type, rules } = sRules;
            let { businessId, actionId, subjectId } = rules;
            rules.action = yield (0, _dimension.getActionByBusiness)(businessId, actionId);
            rules.time = yield getBehaviorTime(rules.time, businessId);
            rules.conditions = yield getBehaviorConditions(rules.filterClause, {
                actionId,
                subjectId,
                businessId
            });
            rules.metrics = yield getBehaviorMetrics(rules.metrics, {
                actionId,
                subjectId,
                businessId
            });
            return {
                type,
                rules
            };
        } catch (err) {
            console.log(err);
        }
    });

    return function convertTagValueRules(_x47) {
        return _ref32.apply(this, arguments);
    };
})();

let preview = exports.preview = (() => {
    var _ref33 = (0, _asyncToGenerator3.default)(function* (filePath, isPreviewAll = false) {
        const HEADER_ROW = 1;
        const PREVIEW_DATA_LENGTH = 11;
        const READ_OPTION = { includeEmpty: false };
        const READ_CELL_OPTION = { includeEmpty: true };
        let fields = [];
        let total = 0;
        let previewList = [];
        let worksheet = yield workbook.csv.readFile(filePath);
        worksheet.eachRow(READ_OPTION, function (row, rowNumber) {
            if (rowNumber === HEADER_ROW) {
                row.eachCell(READ_OPTION, cell => fields.push(cell.value));
            } else {
                total += 1;
                if (isPreviewAll || rowNumber <= PREVIEW_DATA_LENGTH) {
                    let tempRowData = [];
                    row.eachCell(READ_CELL_OPTION, cell => {
                        tempRowData.push(cell.value);
                    });
                    if (tempRowData.some(z => !(0, _is2.default)(z, undefined))) previewList.push(tempRowData);
                }
            }
        });
        let preList = previewList.map(function (z) {
            return (0, _lodash.zipObject)(fields, z);
        });
        let fieldMap = {};
        for (let item of fields) {
            let temp = (0, _lodash.uniq)(preList.map(function (z) {
                return z[item];
            }));
            // temp = temp.filter(a => !Object.is(a,null) && !Object.is(a,undefined) && !Object.is(a,NaN));
            fieldMap[item] = temp;
        }
        return {
            fields,
            total,
            list: preList,
            fieldMap
        };
    });

    return function preview(_x48) {
        return _ref33.apply(this, arguments);
    };
})();

exports.getFirstAllList = getFirstAllList;
exports.removeUploadTagValue = removeUploadTagValue;
exports.createTagRelyOn = createTagRelyOn;
exports.updateFirstDisplaySequence = updateFirstDisplaySequence;
exports.updateThirdDisplaySequence = updateThirdDisplaySequence;

var _consts = require('../../config/consts');

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _immutable = require('immutable');

var _immutable2 = _interopRequireDefault(_immutable);

var _models = require('../common/models');

var _api = require('../common/api');

var _sqliteParser = require('sqlite-parser');

var _sqliteParser2 = _interopRequireDefault(_sqliteParser);

var _lodash = require('lodash');

var _tag = require('../tag/tag.service');

var _dimension = require('../dimension/dimension.service');

var _segment = require('../segment/segment.service');

var _const = require('../base/const.controller');

var _uploadTagValue = require('../../config/uploadTagValueRule/upload.tagValue.rules');

var _exceljs = require('exceljs');

var _exceljs2 = _interopRequireDefault(_exceljs);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let { TagValueStatus, Status, ParameterDataType, TagValueType, OtherStatus, TagLevel, TagType, DataType } = _consts.Enums;

let getWhere = exports.getWhere = (where, keywords) => {
    if (keywords) {
        (0, _assign2.default)(where, {
            $or: {
                id: {
                    $like: `%${keywords}%`
                },
                name: {
                    $like: `%${keywords}%`
                }
            }
        });
    }
    return (0, _assign2.default)(where, {
        status: {
            $ne: Status.Deleted
        }
    });
};

function getFirstAllList(keywords) {
    let where = getWhere({}, keywords);
    return _models.FirstPartyTagValue.findAll({
        where,
        attributes: ['id', 'name', 'dataStatus'],
        order: [['createdAt', 'DESC']]
    });
}

let firstPartyList = exports.firstPartyList = (id, defaultWhere = {}) => {

    return _models.FirstPartyTagValue.findAll({
        attributes: ['id', 'name', 'dataStatus'],
        where: (0, _assign2.default)({
            tagId: id,
            /**
             * 第一方的标签值 取dataStatus的状态 Normal，Generating状态
             */
            dataStatus: {
                $in: [TagValueStatus.Normal, TagValueStatus.Generating]
            },
            status: {
                $ne: Status.Deleted
            }
        }, defaultWhere),
        order: [['createdAt', 'DESC']]
    });
};

let thirdPartyList = exports.thirdPartyList = id => {
    return _models.ThirdPartyTagValue.findAll({
        attributes: ['id', 'name'],
        where: {
            tagId: id,
            status: Status.Normal
        },
        order: [['createdAt', 'DESC']]
    });
};

/**
 * 第一方根据标签id获取标签值id
 * @param tagId
 * @return {*}
 */
let firstPartyTagValueListByTagId = exports.firstPartyTagValueListByTagId = tagId => {
    return _models.FirstPartyTagValue.findAll({
        where: {
            tagId,
            status: {
                $ne: Status.Deleted
            }
        },
        order: [['displaySequence', 'ASC'], ['createdAt', 'DESC']],
        raw: true
    });
};
/**
 * 第三方根据标签id获取标签值id
 * @param tagId
 * @return {*}
 */
let thirdPartyTagValueListByTagId = exports.thirdPartyTagValueListByTagId = tagId => {
    return _models.ThirdPartyTagValue.findAll({
        where: {
            tagId,
            status: {
                $ne: Status.Deleted
            }
        },
        order: [['displaySequence', 'ASC'], ['createdAt', 'DESC']],
        raw: true
    });
};

let firstPartyPages = exports.firstPartyPages = conditions => {
    return _models.FirstPartyTagValue.findAndCount(conditions);
};

let thirdPartyPages = exports.thirdPartyPages = conditions => {
    return _models.ThirdPartyTagValue.findAndCount(conditions);
};

let getSeq = exports.getSeq = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (len = 1) {
        let currentTagValueId;
        let seq;
        do {
            let instance = yield _models.Seq.findOne({
                where: {
                    id: 'tagValueId'
                }
            });
            seq = yield instance.increment('seq', {
                by: len
            });
            if (len > 1) return {
                startSeq: seq.seq,
                endSeq: seq.seq + len - 1
            };
            currentTagValueId = yield _models.FirstPartyTagValue.findOne({
                where: {
                    id: 'FV' + seq.seq
                }
            });
        } while (currentTagValueId);
        return seq;
    });

    return function getSeq() {
        return _ref.apply(this, arguments);
    };
})();
/**
 * 获得目前最大的优先级数字
 * @param tagId
 * @returns {*|Object|Query|number}
 */
let getPriority = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (tagId) {
        let maxPriority = yield _models.FirstPartyTagValue.findOne({
            where: {
                tagId
            },
            order: [['priority', 'DESC']]
        });

        return maxPriority && ++maxPriority.priority || 1;
    });

    return function getPriority(_x) {
        return _ref2.apply(this, arguments);
    };
})();

/**
 * 获取可用对象
 * isUnique 1
 * @returns {Promise}
 */
let getMetaObjectList = exports.getMetaObjectList = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* () {

        let metaObjects = yield _models.MetaObjectField.find({
            status: Status.Normal
        }, {
            _id: 0,
            metaObjectId: 1,
            isUnique: 1,
            isUserId: 1
        }).lean().exec();

        let map = (0, _lodash.groupBy)(metaObjects, 'metaObjectId');
        //有userId的metaObject
        let hasUniqueMetaObjectIds = [];
        (0, _lodash.each)(map, function (fields, metaObjectId) {
            if (
            // find(fields,{
            //     isUnique: 1
            // })
            // &&
            (0, _lodash.find)(fields, {
                isUserId: 1
            })) {
                hasUniqueMetaObjectIds.push(metaObjectId);
            }
        });

        return _models.MetaObject.find({
            status: Status.Normal,
            id: {
                $in: hasUniqueMetaObjectIds
            }
        }, {
            _id: 0,
            id: 1,
            name: 1
        }).sort({
            settleTime: -1
        }).lean().exec();
    });

    return function getMetaObjectList() {
        return _ref3.apply(this, arguments);
    };
})();
/**
 * 获取对象字段
 * @param ids
 * @returns {Promise}
 */
let getMetaObjectFieldByMetaObjectIds = exports.getMetaObjectFieldByMetaObjectIds = ids => {
    return _models.MetaObjectField.find({
        status: Status.Normal,
        metaObjectId: {
            $in: ids
        }
    }, {
        _id: 0,
        id: 1,
        name: 1,
        metaObjectId: 1,
        dataType: 1
    }).sort({
        settleTime: -1
    }).lean().exec();
};

/**
 * 获取对象树结构
 * @returns {{}}
 */
let getMetaObjectTree = exports.getMetaObjectTree = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* () {
        let treeObject = {};
        let metaObjectData = yield getMetaObjectList();
        let metaObjectFieldData = yield getMetaObjectFieldByMetaObjectIds(metaObjectData.map(function (item) {
            return item.id;
        }));
        metaObjectFieldData = (0, _lodash.groupBy)(metaObjectFieldData, 'metaObjectId');

        metaObjectData.forEach(function (item) {
            let fieldItemList = metaObjectFieldData[item.id];
            if (fieldItemList) {
                treeObject[String(item.id).toLowerCase()] = (0, _lodash.zipObject)(fieldItemList.map(function (item) {
                    return String(item.id).toLowerCase();
                }), fieldItemList.map(function (z) {
                    return z.dataType === ParameterDataType.Number ? Number((0, _lodash.random)(100, 200)) : String((0, _lodash.random)(1, 100));
                }));
            }
        });
        return treeObject;
    });

    return function getMetaObjectTree() {
        return _ref4.apply(this, arguments);
    };
})();function removeUploadTagValue(tagId) {
    return _models.FirstPartyTagValue.update({
        status: Status.Deleted
    }, {
        where: {
            type: TagValueType.upload,
            tagId
        }
    });
}

/**
 * 新建标签依赖关系
 * @param tagId
 * @param relyOnTagId
 * @param relyOnTagValueId
 * @param tagValueId
 */
function createTagRelyOn({ tagId, relyOnTagId, relyOnTagValueId }, tagValueId) {
    if (!tagValueId || !tagId || !relyOnTagId) return;
    return _models.TagRelyOn.create({
        tagId,
        tagValueId,
        relyOnTagId,
        relyOnTagValueId
    });
}

let isAndOr = logic => {
    const logicArray = ['and', 'or'];
    return logicArray.indexOf(logic) > -1;
};

/**
 * 判断算术运算符两边不能全是常量
 * @param obj
 */
let isSubtract = obj => {
    const DECIMAL_TYPE = 'decimal';
    if (obj) {
        if (obj.left && obj.right && obj.left.variant === DECIMAL_TYPE && obj.right.variant === DECIMAL_TYPE) {
            throw new Error(`规则语法不正确`);
        }
    }
};

let dealWithSql = (obj, tree, isCalculate) => {
    if (isCalculate) {
        /**
         * 对于and or 运算符分隔的 需要两边必须是逻辑表达式
         */
        if (!obj.operation) throw new Error(`规则语法不正确`);
    }

    if (obj.operation) {
        isSubtract(obj);
    }
    let metaObjectName = [];
    if (obj.left) {
        metaObjectName = [...metaObjectName, ...dealWithSql(obj.left, tree, isAndOr(obj.operation))];
    }
    if (obj.right) {
        metaObjectName = [...metaObjectName, ...dealWithSql(obj.right, tree, isAndOr(obj.operation))];
    }
    if (obj.args && obj.args.expression) {
        for (let item of obj.args.expression) {
            metaObjectName = [...metaObjectName, ...dealWithSql(item, tree, isAndOr(obj.operation))];
        }
    }
    if (obj.type == 'identifier' && obj.variant == 'column' && obj.name) {
        let metaObjectId = obj.name.slice(0, obj.name.indexOf('.'));
        if (metaObjectId) {
            if (!tree[metaObjectId]) throw new Error(`对象${metaObjectId}不存在`);
        }
        let metaObjectFieldId = obj.name.slice(obj.name.indexOf('.') + 1);
        if (metaObjectFieldId) {
            if (!tree[metaObjectId][metaObjectFieldId]) throw new Error(`对象${metaObjectId}下无字段${metaObjectFieldId}`);
        }
        metaObjectName.push(obj.name);
    }
    return metaObjectName;
};
/**
 * 验证对象存在与否
 * @param ast
 * @returns {boolean}
 */
let valiedateMetaObject = exports.valiedateMetaObject = (() => {
    var _ref15 = (0, _asyncToGenerator3.default)(function* (ast) {
        if (!ast || !ast.statement || !ast.statement[0]) return false;
        let treeObject = yield getMetaObjectTree();
        let whereAst = ast.statement[0].where;
        let res = {
            validate: true,
            parseRules: {}
        },
            metaObjectName = [];
        for (let item of whereAst) {
            metaObjectName = [...metaObjectName, ...dealWithSql(item, treeObject)];
        }

        metaObjectName.forEach(function (z) {
            let tempKey = z.slice(0, z.indexOf('.'));
            let tempField = z.slice(z.indexOf('.') + 1);
            if (res.parseRules[tempKey]) {
                res.parseRules[tempKey].push(tempField);
            } else {
                res.parseRules[tempKey] = [tempField];
            }
            res.parseRules[tempKey] = (0, _lodash.uniq)(res.parseRules[tempKey]);
        });

        return res;
    });

    return function valiedateMetaObject(_x28) {
        return _ref15.apply(this, arguments);
    };
})();
/**
 * 规则sql语法验证
 * @param rules
 */
let validateSqlSyntax = exports.validateSqlSyntax = (() => {
    var _ref16 = (0, _asyncToGenerator3.default)(function* (rules) {

        try {
            let index = String(rules).search(/[=><\+\-][><\+\-]+/g);
            if (index > 0) throw new Error(`规则语法不正确`);
            let isHaveLogicCalculate = String(rules).search(/[=><]|(!=)/g);
            if (isHaveLogicCalculate < 0) throw new Error(`规则语法不正确`);
            let sql = `select * from tableName where ${rules};`;
            let ast = yield new _promise2.default(function (resolve, reject) {
                (0, _sqliteParser2.default)(sql, function (err, ast) {
                    if (err) {
                        reject();
                    }
                    resolve(ast);
                });
            }).catch(function () {
                throw new Error(`规则语法不正确`);
            });
            if (!ast) {
                throw new Error(`规则语法不正确`);
            }
            let res = yield valiedateMetaObject(ast);
            if ((0, _lodash.isEmpty)(res.parseRules)) {
                throw new Error(`规则必须包含对象字段`);
            }
            return res;
        } catch (err) {
            return {
                validate: false,
                message: err.message
            };
        }
    });

    return function validateSqlSyntax(_x29) {
        return _ref16.apply(this, arguments);
    };
})();

/**
 * 参数值规则验证
 * @param rules
 * @returns {boolean}
 */
/*export let validateRules = async(rules) => {
 if (!rules) return;
 let treeObject = await getMetaObjectTree();
 let parseObj = null;

 try {
 /!**
 * TODO 数学表达式验证
 *!/
 // rules = '( t_car_360.next_maintain_date )=1.1';
 rules = String(rules);
 rules = rules.replace(/>|</g,'=');
 rules = rules.replace(/=+/g,'==');
 rules = rules.replace(/\+/g,'-');
 if (rules.search(/;/g) > -1) {
 throw new Error(`不支持分号`);
 }
 console.log(rules)
 let node = mathjs.parse(rules);

 node.traverse((node,path,parent) => {
 // console.log(node);
 //  console.log(util.inspect(parent, true, null, true));
 switch (node.type) {
 case 'OperatorNode':
 // console.log(node.type, node.op);
 break;
 case 'ConstantNode':
 // console.log(node.type, node.value,parent);
 if (node.value && parent.dotNotation && parent.dimensions[0]) {
 if (parseObj.key) {
 if (!treeObject[parseObj.key][node.value]) {
 throw new Error(`${parseObj.key}下无字段${node.value}`);
 } else {
 parseObj.value.push(node.value)
 }
 }
 }

 break;
 case 'SymbolNode':
 if (!treeObject[node.name]) {
 throw new Error(`对象${node.name}不存在`);
 }
 if (!parseObj) {
 parseObj = {
 key: node.name,
 value: []
 };
 } else if (parseObj.key !== node.name) {
 throw new Error(`仅支持单对象`);
 }

 // console.log(node.type, node.name);
 break;
 default:
 // console.log(node.type);
 }
 });
 let code = node.compile();
 // console.log(code.eval(treeObject));
 return {
 validate: true,
 parseRules: {
 [parseObj['key']]: uniq(parseObj['value'])
 }
 };
 } catch (err) {
 return {
 validate: false,
 message: err.message
 };
 }
 };*/

/**
 * 新建标签值
 * @param model
 * @returns {model}
 */
let create = exports.create = (() => {
    var _ref17 = (0, _asyncToGenerator3.default)(function* (model) {
        let seq = yield getSeq();
        let priority = yield getPriority(model.tagId);
        (0, _assign2.default)(model, {
            id: 'FV' + seq.seq,
            priority
        });
        return _models.FirstPartyTagValue.create(model);
    });

    return function create(_x30) {
        return _ref17.apply(this, arguments);
    };
})();

/**
 * 是否应该更新标签值的状态
 * @param id
 * @param newValueRules
 */
let shouldUpdateTagValueStatus = exports.shouldUpdateTagValueStatus = (() => {
    var _ref18 = (0, _asyncToGenerator3.default)(function* (id, newValueRules) {
        let tagValueObj = yield _models.FirstPartyTagValue.findOne({
            where: {
                id: id
            },
            raw: true
        });
        if (tagValueObj && tagValueObj.valueRules) {
            if (newValueRules != tagValueObj.valueRules) {
                yield updateTagValueStatusToGenerating([id]);
            }
        }
    });

    return function shouldUpdateTagValueStatus(_x31, _x32) {
        return _ref18.apply(this, arguments);
    };
})();
/**
 * 更新状态
 * @param ids
 * @returns {*}
 */
let updateTagValueStatusToGenerating = exports.updateTagValueStatusToGenerating = ids => {
    return _models.FirstPartyTagValue.update({
        dataStatus: TagValueStatus.Generating
    }, {
        where: {
            id: {
                $in: ids
            }
        }
    });
};

let update = exports.update = (id, model) => {
    return _models.FirstPartyTagValue.update(model, {
        where: {
            id
        }
    });
};

let displaySequenceUpdate = exports.displaySequenceUpdate = (() => {
    var _ref21 = (0, _asyncToGenerator3.default)(function* (displaySequenceArray, tagValueList) {

        let data = [];
        const SEQUENCE_STEP = 10;
        let displayLen = displaySequenceArray.length;
        let sortDisplaySequenceArray = (0, _lodash.orderBy)(displaySequenceArray, 'displaySequence');
        if (tagValueList.every(function (z) {
            return !z.displaySequence;
        })) {
            let autoChangeIndex = 0;
            for (let _ref22 of tagValueList) {
                let { id } = _ref22;

                let dispalyIndex = (0, _lodash.findIndex)(sortDisplaySequenceArray, function (d) {
                    return d.tagValueId == id;
                });
                data.push({
                    id,
                    displaySequence: dispalyIndex > -1 ? SEQUENCE_STEP * (dispalyIndex + 1) : SEQUENCE_STEP * (1 + displayLen + autoChangeIndex++)
                });
            }
            return data;
        }
        data = tagValueList;
        for (let _ref23 of sortDisplaySequenceArray) {
            let { tagValueId, displaySequence } = _ref23;

            data = [...data.filter(function (b) {
                return b.id !== tagValueId && b.displaySequence < displaySequence;
            }), {
                id: tagValueId,
                displaySequence
            }, ...data.filter(function (c) {
                return c.id !== tagValueId && c.displaySequence >= displaySequence;
            })];
        }

        return data.map(function (item, index) {
            return {
                id: item.id,
                displaySequence: SEQUENCE_STEP * (index + 1)
            };
        });
    });

    return function displaySequenceUpdate(_x35, _x36) {
        return _ref21.apply(this, arguments);
    };
})();

function updateFirstDisplaySequence(tagValueList) {
    return _models.sequelize.query(`UPDATE first_party_tag_value SET 
        display_sequence = CASE id
        ${tagValueList.map(item => {
        return `WHEN '${item.id}' THEN ${item.displaySequence}`;
    }).join('\n\t')}
        END 
        WHERE id IN (${tagValueList.map(item => `'${item.id}'`)})`, { raw: true });
}

function updateThirdDisplaySequence(tagValueList) {
    return _models.sequelize.query(`UPDATE third_party_tag_value SET 
        display_sequence = CASE id
        ${tagValueList.map(item => {
        return `WHEN '${item.id}' THEN ${item.displaySequence}`;
    }).join('\n\t')}
        END 
        WHERE id IN (${tagValueList.map(item => `'${item.id}'`)})`, { raw: true });
}

let query = exports.query = id => {
    return _models.FirstPartyTagValue.findOne({
        where: {
            id
        },
        raw: true
    });
};

let queryThirdTagValue = exports.queryThirdTagValue = id => {
    return _models.ThirdPartyTagValue.findOne({
        where: {
            id
        },
        raw: true
    });
};let isTagValueGenerating = exports.isTagValueGenerating = id => {
    return _models.FirstPartyTagValue.count({
        where: {
            id: id,
            status: Status.Normal,
            dataStatus: TagValueStatus.Generating
        }
    });
};

let remove = exports.remove = (...ids) => {
    if (!ids || !ids.length) return;
    return _models.FirstPartyTagValue.update({
        status: Status.Deleted
    }, {
        where: {
            id: {
                $in: ids
            }
        }
    });
};

/**
 * 获取父级的name
 * @param ids
 * @returns {{}}
 */

let getTagValueParentById = exports.getTagValueParentById = (() => {
    var _ref25 = (0, _asyncToGenerator3.default)(function* (ids) {
        let groupList = yield getGroupListByIds(ids);
        let listMap = {};
        while ((0, _lodash.some)(groupList, function (it) {
            return it.parentId;
        })) {
            let parentIds = groupList.filter(function (item) {
                return item.parentId;
            }).map(function (z) {
                return z.parentId;
            });
            let parentList = yield getGroupListByIds(parentIds);
            groupList = groupList.map(function (zz) {
                let plitem = (0, _lodash.find)(parentList, {
                    id: zz.parentId
                });
                if (plitem) {
                    return {
                        name: `${zz.name},${plitem.name}`,
                        parentId: plitem.parentId,
                        id: zz.id
                    };
                }
                return zz;
            });
        }
        if (groupList) {
            groupList.forEach(function (item) {
                listMap[item.id] = item.name;
            });
        }

        return listMap;
    });

    return function getTagValueParentById(_x38) {
        return _ref25.apply(this, arguments);
    };
})();
let getGroupListByIds = exports.getGroupListByIds = (ids, attributes = ['id', 'name', 'parentId']) => {
    return _models.TagValueGroup.findAll({
        attributes,
        where: {
            id: {
                $in: (0, _lodash.uniq)(ids)
            },
            status: Status.Normal
        },
        raw: true
    });
};

let getFirstTagValuelistByIds = exports.getFirstTagValuelistByIds = (ids, attributes = ['id', 'name', 'status', 'dataStatus']) => {
    return _models.FirstPartyTagValue.findAll({
        attributes,
        where: {
            id: {
                $in: ids
            }
        },
        raw: true
    });
};

let getThirdTagValuelistByIds = exports.getThirdTagValuelistByIds = (ids, attributes = ['id', 'name', 'status']) => {
    return _models.ThirdPartyTagValue.findAll({
        attributes,
        where: {
            id: {
                $in: ids
            }
        },
        raw: true
    });
};

const workbook = new _exceljs2.default.Workbook();
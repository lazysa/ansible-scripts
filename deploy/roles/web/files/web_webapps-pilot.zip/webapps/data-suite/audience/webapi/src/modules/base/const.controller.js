'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.findAll = exports.getOperatorList = exports.sysUserIdColumnsListByTableName = exports.operatorList = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let operatorList = exports.operatorList = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let {
                dataType, uiType
            } = ctx.request.query;
            data = yield getOperatorList(dataType, uiType);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function operatorList(_x) {
        return _ref.apply(this, arguments);
    };
})();

let sysUserIdColumnsListByTableName = exports.sysUserIdColumnsListByTableName = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let {
                tableName
            } = ctx.params;
            data = yield _api.DataAssetsWebApi.getSysUserIdColumnsListByTableName(tableName);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function sysUserIdColumnsListByTableName(_x2) {
        return _ref2.apply(this, arguments);
    };
})();

let getOperatorList = exports.getOperatorList = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (dataType, uiType = 2) {
        let sql = `select op.operator_id as operatorId , op.name as operatorName
from data_type_has_operator dop
left join operator op
on dop.operator_id = op.id
where dop.data_type=:dataType and ui_type=:uiType and  dop.status=:status and op.status=:status`;
        return findAll(sql, {
            dataType: dataType,
            uiType: uiType,
            status: Status.Normal
        }, false);
    });

    return function getOperatorList(_x3) {
        return _ref3.apply(this, arguments);
    };
})();

let findAll = exports.findAll = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (sql, replacements = {}, renameKey = true) {
        let result = [];
        let data = yield _index.sequelize.query(sql, {
            replacements: replacements,
            type: _index.sequelize.QueryTypes.SELECT
        });
        if (data.length) {
            result = data;
            if (renameKey) {
                result = renameKeys(result);
            }
        }
        return result;
    });

    return function findAll(_x4) {
        return _ref4.apply(this, arguments);
    };
})();

exports.getEnums = getEnums;
exports.getOptions = getOptions;
exports.getoptionMaps = getoptionMaps;
exports.getKVMap = getKVMap;
exports.getVKMap = getVKMap;
exports.getVNMap = getVNMap;

var _consts = require('../../config/consts');

var _helper = require('../common/util/helper');

var _index = require('../common/models/index');

var _api = require('../common/api');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const { Status } = _consts.Enums;

function getEnums(ctx) {
    let data = null;
    let error = null;
    try {
        data = _consts.Enums;
    } catch (ex) {

        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}

function getOptions(ctx) {
    let data = null;
    let error = null;
    try {
        data = _consts.Options;
    } catch (ex) {
        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}

function getoptionMaps(ctx) {
    let data = null;
    let error = null;
    try {
        data = _consts.OptionMaps;
    } catch (ex) {
        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}

function getKVMap(ctx) {
    let data = null;
    let error = null;
    try {
        data = _consts.KeyValMaps;
    } catch (ex) {
        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}

function getVKMap(ctx) {
    let data = null;
    let error = null;
    try {
        data = _consts.ValKeyMaps;
    } catch (ex) {
        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}

function getVNMap(ctx) {
    let data = null;
    let error = null;
    try {
        data = _consts.ValNameMaps;
    } catch (ex) {
        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}
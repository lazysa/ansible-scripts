'use strict';

var _sequelize = require('sequelize');

var _sequelize2 = _interopRequireDefault(_sequelize);

var _helper = require('../util/helper');

var _consts = require('../../../config/consts');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('First_party_tag', {
        id: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: true,
            defaultValue: null
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null
        },
        tagType: {
            type: DataTypes.INTEGER(4).UNSIGNED,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: 'tag_type'
        },
        tagGroupId: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'tag_group_id'
        },
        mergeRule: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 0,
            field: 'merge_rule'
        },
        updatePeriod: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _consts.Enums.TagUpdatePeriod.auto,
            field: 'update_period'
        },
        remark: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: ''
        },
        status: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        },
        coverage: {
            type: DataTypes.INTEGER(10),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'created_at'
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'updated_at'
        },
        chartType: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'chart_type'
        },
        belongedTableName: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'belonged_table_name'
        },
        tagLevel: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: 'tag_level'
        },
        recordEditable: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: 'record_editable'
        },
        isUsedForInsight: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: 'is_used_for_insight'
        },
        isUsedForSegment: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: 'is_used_for_segment'
        },
        recordViewable: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: 'record_viewable'
        },
        expires: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _helper.FOREVER_TIME,
            field: 'expires'
        },
        isBulkCreate: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            defaultValue: '0',
            field: 'is_bulk_create'
        }
    }, {
        tableName: 'first_party_tag'
    });
};
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _tagController = require('./tag.controller.js');

var ctrl = _interopRequireWildcard(_tagController);

var _tagFilter = require('./tag.filter.js');

var filter = _interopRequireWildcard(_tagFilter);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
  prefix: '/tag'
});

//根据组id获取标签list

/**
 * tagGroupId ：标签组id ; all
 */

router.get('/first/:tagGroupId/list', ctrl.firstPartyList);
router.get('/first/:tagGroupId/depthList', ctrl.firstPartyDepthList);

router.get('/third/:tagGroupId/list', ctrl.thirdPartyList);
router.get('/third/:tagGroupId/depthList', ctrl.thirdPartyDepthList);
router.get('/third/:dataSourceId/all/list', ctrl.thirdPartyAllList);

//根据组id获取标签pages
router.get('/first/:tagGroupId/pages', filter.pages, ctrl.firstPartyPages);
router.get('/third/:tagGroupId/pages', filter.pages, ctrl.thirdPartyPages);
router.get('/third/:dataSourceId/all/pages', filter.pages, ctrl.thirdPartyAllPages);

/*
 * 开启，关闭标签
 * dimensions:first/third
 * status:close
 * id:tagId
 * */
// router.get('/:dimensions/:status/:id',ctrl.close);
//新增标签
router.post('/first', filter.create, ctrl.create);
router.post('/first/bulkCreate', ctrl.bulkCreate);
//根据标签id查询单一标签的信息
router.get('/first/:id', ctrl.query);
//删除标签
router.delete('/first/:id', ctrl.removeTagBaseAuth, ctrl.removeTagAuth, ctrl.remove);
//删除标签之前验证
router.delete('/first/validate/:id', ctrl.removeTagBaseAuth, ctrl.removeValidate);
//更新标签
router.put('/first/:id', filter.update, ctrl.update);

exports.default = router;
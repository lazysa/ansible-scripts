ALTER TABLE `audience`.`first_party_tag`
ADD COLUMN `is_used_for_segment` TINYINT(4) NOT NULL DEFAULT 1 AFTER `is_used_for_insight`;


ALTER TABLE `audience`.`third_party_tag`
ADD COLUMN `is_used_for_segment` TINYINT(4) NOT NULL DEFAULT 1 AFTER `is_used_for_insight`;

'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _dataSourceController = require('./dataSource.controller.js');

var ctrl = _interopRequireWildcard(_dataSourceController);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({});

//常量
router.get('/dataSource/list', ctrl.list);
router.get('/mergeRule/list', ctrl.mergeList);
router.get('/chartType/list', ctrl.chartTypeList);
router.get('/behaviourType/list', ctrl.behaviourTypeList);
router.get('/updatePeriod/:dataSourceId', ctrl.updatePeriodlist);
router.get('/updatePeriod/first', ctrl.updatePeriodFirstlist);
router.get('/insight/field/list', ctrl.InsightFieldList);
router.get('/idMerge/idMetric/list', ctrl.idMetricList);
router.get('/idMerge/idField/list', ctrl.idFieldList);

exports.default = router;
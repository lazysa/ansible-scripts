ALTER TABLE `audience`.`tag_group` 
ADD COLUMN `sequence` INT NOT NULL AUTO_INCREMENT FIRST,
DROP PRIMARY KEY,
ADD PRIMARY KEY (`sequence`, `id`);



ALTER TABLE `audience`.`tag_group` 
ADD COLUMN `parent_id` VARCHAR(255) NULL AFTER `updated_at`;

ALTER TABLE `audience`.`segment_group`
CHANGE COLUMN `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT,
ADD COLUMN `parent_id` INT(10) NULL AFTER `updated_at`;



ALTER TABLE `audience`.`first_party_tag` 
ADD COLUMN `is_used_for_insight` TINYINT(4) NOT NULL DEFAULT 1 AFTER `record_editable`;

ALTER TABLE `audience`.`third_party_tag` 
ADD COLUMN `is_used_for_insight` TINYINT(4) NOT NULL DEFAULT 1 AFTER `remark`;


-- CREATE TABLE `audience`.`segment_upload_field` (
--   `id` INT NOT NULL AUTO_INCREMENT,
--     `name` VARCHAR(255)  NULL,
--   `field_id` VARCHAR(255) NOT NULL,
--   `encrypt_type` VARCHAR(255) NULL,
--   `data_source_id` INT(10) NULL,
--    `category` INT(10) NULL,
--       `column_field_id` VARCHAR(255) NULL,
--   PRIMARY KEY (`id`));

-- INSERT INTO `segment_upload_field` VALUES (1,'phone','phone',NULL,1,2,'phone_key'),(2,'phone_MD5','phone','MD5',1,2,'phone_key'),(3,'IMEI','IMEI',NULL,1,2,'imei_key'),(4,'IMEI_MD5','IMEI','MD5',1,2,'imei_key'),(5,'IDFA','IDFA',NULL,1,2,'idfa_key'),(6,'IDFA_MD5','IDFA','MD5',1,2,'idfa_key');



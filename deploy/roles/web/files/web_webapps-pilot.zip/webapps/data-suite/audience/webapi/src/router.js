'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

exports.default = function (app) {
    app.use(_router2.default.routes());
    app.use(_router10.default.routes());
    app.use(_router12.default.routes());
    app.use(_router4.default.routes());
    app.use(_router8.default.routes());
    app.use(_router6.default.routes());
    app.use(_router18.default.routes());
    app.use(_router14.default.routes());
    app.use(_router16.default.routes());
    app.use(_router20.default.routes());
    app.use(_router22.default.routes());
    app.use(_router24.default.routes());
    app.use(_router28.default.routes());
    app.use(_router26.default.routes());
};

var _router = require('./modules/base/router');

var _router2 = _interopRequireDefault(_router);

var _router3 = require('./modules/tagGroup/router');

var _router4 = _interopRequireDefault(_router3);

var _router5 = require('./modules/segmentGroup/router');

var _router6 = _interopRequireDefault(_router5);

var _router7 = require('./modules/segment/router');

var _router8 = _interopRequireDefault(_router7);

var _router9 = require('./modules/tag/router');

var _router10 = _interopRequireDefault(_router9);

var _router11 = require('./modules/tagValue/router');

var _router12 = _interopRequireDefault(_router11);

var _router13 = require('./modules/insight/router');

var _router14 = _interopRequireDefault(_router13);

var _router15 = require('./modules/explore/router');

var _router16 = _interopRequireDefault(_router15);

var _router17 = require('./modules/dataSource/router');

var _router18 = _interopRequireDefault(_router17);

var _router19 = require('./modules/export/router');

var _router20 = _interopRequireDefault(_router19);

var _router21 = require('./modules/fileToken/router');

var _router22 = _interopRequireDefault(_router21);

var _router23 = require('./modules/metrics/router');

var _router24 = _interopRequireDefault(_router23);

var _router25 = require('./modules/dimension/router');

var _router26 = _interopRequireDefault(_router25);

var _router27 = require('./modules/api/v1/business/router');

var _router28 = _interopRequireDefault(_router27);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
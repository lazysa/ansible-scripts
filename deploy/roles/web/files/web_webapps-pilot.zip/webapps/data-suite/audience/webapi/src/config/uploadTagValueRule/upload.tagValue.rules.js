'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
const uploadTagValueRules = exports.uploadTagValueRules = {
    1: {
        valueRules: `system_uploaded_tag_options.file_flag = '<%= flag %>' and system_uploaded_tag_options.attribute_value = '<%= selectField %>'`,
        parseRules: { system_uploaded_tag_options: ['file_flag', 'attribute_value'] }
    },
    0: {
        valueRules: `system_uploaded_no_store_tag_options.file_flag = '<%= flag %>' and system_uploaded_no_store_tag_options.attribute_value = '<%= selectField %>'`,
        parseRules: { system_uploaded_no_store_tag_options: ['file_flag', 'attribute_value'] }
    }
};
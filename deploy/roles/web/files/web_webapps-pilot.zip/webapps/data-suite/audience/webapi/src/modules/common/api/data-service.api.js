'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _helper = require('../util/helper');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class ReportApi {
    constructor() {
        this.baseUrl = _config2.default.dataServiceApiPath;
    }

    //业务中心(返回业务中心列表):
    getBusinessList() {
        let url = `${this.baseUrl}/ba/business_list`;
        let body = { "attributes": {} };
        return (0, _helper.getReportApi)(url, body);
    }

    //时间(返回日期维度列表):
    getBusinessDataDimensionList(businessId) {
        let url = `${this.baseUrl}/ba/business_date_dimension_list`;
        let body = {
            "attributes": {
                businessId
            }
        };

        return (0, _helper.getReportApi)(url, body);
    }

    //行为(返回行为列表,包含主题):
    getBusinessActionList(businessId) {
        let url = `${this.baseUrl}/ba/business_action_list`;
        let body = {
            "attributes": {
                businessId
            }
        };
        return (0, _helper.getReportApi)(url, body);
    }

    //条件-根据主题返回所有维度属性
    getActionDimensionAttrList({ businessId, subjectId, actionId }) {
        let url = `${this.baseUrl}/ba/action_dimension_list`;
        let body = {
            "attributes": {
                businessId,
                subjectId,
                actionId
            }
        };
        return (0, _helper.getReportApi)(url, body);
    }

    //条件-根据指定维度属性返回对应的维度值
    getDimensionMetaList(dimensionAttribute) {
        let url = `${this.baseUrl}/ba/dimension_meta_list`;
        let body = {
            "attributes": {
                dimensionAttribute: Number(dimensionAttribute),
                "version": 2
            }
        };
        return (0, _helper.getReportApi)(url, body);
    }

    //指标(返回主题下所有指标):
    getActionMetricList({ subjectId, actionId, businessId }) {
        let url = `${this.baseUrl}/ba/action_metric_list`;
        let body = {
            "attributes": {
                subjectId,
                actionId,
                businessId
            }
        };
        return (0, _helper.getReportApi)(url, body);
    }
}

exports.default = new ReportApi();
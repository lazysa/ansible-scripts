'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.create = exports.updateInsight = exports.pages = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

exports.getKeyPathArray = getKeyPathArray;
exports.getKeyPathOriginalObject = getKeyPathOriginalObject;
exports.getKeyPathArrayShallow = getKeyPathArrayShallow;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _validation = require('./validation.schemas');

var schemas = _interopRequireWildcard(_validation);

var _helper = require('../common/util/helper');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _lodash = require('lodash');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let pages = exports.pages = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let schema = schemas.SegmentPages;
        try {
            const result = _joi2.default.validate(ctx.request.query, schema);
            if (result.error) {
                throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
            }
            // ctx.state.query = result.value;
            yield next();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function pages(_x, _x2) {
        return _ref.apply(this, arguments);
    };
})();
let updateInsight = exports.updateInsight = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let schema = schemas.updateInsight;
        try {
            const result = _joi2.default.validate(ctx.request.body, schema);
            if (result.error) {
                throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
            }

            // ctx.state.query = result.value;
            yield next();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function updateInsight(_x3, _x4) {
        return _ref2.apply(this, arguments);
    };
})();

const segmentResultPath = ['firstPartyRules.includes.rules', 'firstPartyRules.excludes.rules', 'thirdPartyRules.includes.rules', 'thirdPartyRules.excludes.rules'];

/**
 * map遍历 与原先的segmentRules结构一致 (不过返回的规则的数组)
 * @param segmentRules
 * @param callback
 * @return {Array}
 */
function getKeyPathArray(segmentRules, callback) {
    let res = [];
    for (let keyPath of segmentResultPath) {
        res = [...res, (0, _lodash.result)(segmentRules, keyPath, []).map(callback)];
    }
    return res;
}
/**
 * rules map遍历 与原先的segmentRules结构一致,返回的跟原segmentRules结构一致（深度复制），且不修改原segmentRules
 * @param srcSegmentRules
 * @param callback
 * @return {Object}
 */
function getKeyPathOriginalObject(srcSegmentRules, callback) {
    let segmentRules = (0, _lodash.defaultsDeep)({}, srcSegmentRules);
    for (let keyPath of segmentResultPath) {
        if (!(0, _lodash.result)(segmentRules, keyPath)) continue;
        let rules = (0, _lodash.result)(segmentRules, keyPath, []).map(callback);
        (0, _lodash.set)(segmentRules, keyPath, rules);
    }
    return segmentRules;
}
/**
 * 浅层的遍历
 * @param segmentRules
 * @param callback
 * @return {Array}
 */
function getKeyPathArrayShallow(segmentRules, callback) {
    let res = [];
    for (let keyPath of segmentResultPath) {
        res = [...res, callback && callback.call(null, (0, _lodash.result)(segmentRules, keyPath, []))];
    }
    return res;
}

let create = exports.create = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        function sum(...args) {
            return args.reduce((p, c) => p + c);
        }

        let schema = schemas.create;
        try {
            const result = _joi2.default.validate(ctx.request.body, schema);
            if (result.error) {
                throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
            }
            let segmentRules = ctx.request.body.segmentRules;
            // let firstPartyRules = segmentRules.firstPartyRules;
            // let thirdPartyRules = segmentRules.thirdPartyRules;
            let fileRules = segmentRules.fileRules;

            let count = 0;
            let arrayLength = getKeyPathArray(segmentRules, function (item) {
                return item.length;
            });
            count = arrayLength.reduce(function (pre, cur) {
                return sum(pre, ...cur);
            }, 0);
            // if (firstPartyRules && firstPartyRules.includes && firstPartyRules.excludes) {
            //     firstPartyRules.includes.rules.forEach(item=> {
            //         count += item.length;
            //     });
            //     firstPartyRules.excludes.rules.forEach(item=> {
            //         count += item.length;
            //     });
            // }
            // if (thirdPartyRules && thirdPartyRules.includes && thirdPartyRules.excludes) {
            //     thirdPartyRules.includes.rules.forEach(item=> {
            //         count += item.length;
            //     });
            //     thirdPartyRules.excludes.rules.forEach(item=> {
            //         count += item.length;
            //     });
            // }
            if (count === 0 && !fileRules) {
                throw new _errors2.default.ParamsInvalid("rules can not be null");
            }
            yield next();
        } catch (ex) {
            console.log(ex);
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function create(_x5, _x6) {
        return _ref3.apply(this, arguments);
    };
})();
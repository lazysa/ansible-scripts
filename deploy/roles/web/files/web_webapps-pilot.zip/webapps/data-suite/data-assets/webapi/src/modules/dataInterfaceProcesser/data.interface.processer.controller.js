'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.list = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let list = exports.list = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let rollerType = rollerTypeMap[ctx.params.rollerType];
			data = yield DataInterfaceProcesserService.list(rollerType);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function list(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

var _helper = require('../common/util/helper');

var _dataInterfaceProcesserService = require('./data.interface.processer.service.js');

var DataInterfaceProcesserService = _interopRequireWildcard(_dataInterfaceProcesserService);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _lodash = require('lodash');

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let rollerTypeMap = _config2.default.rollerTypeMap;
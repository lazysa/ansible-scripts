'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.open = exports.close = exports.update = exports.query = exports.create = exports.pages = exports.list = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let list = exports.list = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let dataHubId = ctx.params.dataHubId;
			data = yield DataInterfaceService.list(dataHubId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function list(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let pages = exports.pages = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let dataHubId = ctx.params.dataHubId;
			let {
				pageSize,
				pageIndex,
				keyword
			} = ctx.query;
			let condition = {
				dataHubId: dataHubId
			};
			if (keyword) {
				condition["$or"] = {
					id: {
						$like: '%' + keyword + '%'
					},
					name: {
						$like: '%' + keyword + '%'
					}
				};
			}
			pageSize = pageSize * 1;
			pageIndex = pageIndex * 1;
			let offset = (pageIndex - 1) * pageSize;
			let count = yield DataInterfaceService.count(condition);
			let list = yield DataInterfaceService.pages(pageSize, offset, condition);
			data = {
				list: list,
				pageIndex: pageIndex,
				pageSize: pageSize,
				total: count
			};
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function pages(_x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let dataHubId = ctx.params.dataHubId;
			let body = ctx.request.body;
			let info = _lodash2.default.pick(body, ['name', 'dataInterfaceProcesserId', 'dataInterfaceProcesserConfig', 'status']);
			info.dataHubId = dataHubId;
			data = yield DataInterfaceService.create(info);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function create(_x5, _x6) {
		return _ref3.apply(this, arguments);
	};
})();

let query = exports.query = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				dataHubId,
				dataInterfaceId
			} = ctx.params;
			data = yield DataInterfaceService.query(dataHubId, dataInterfaceId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function query(_x7, _x8) {
		return _ref4.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				dataHubId,
				dataInterfaceId
			} = ctx.params;
			let body = ctx.request.body;
			let info = _lodash2.default.pick(body, ['name', 'dataInterfaceProcesserId', 'dataInterfaceProcesserConfig', 'status']);
			info.dataHubId = dataHubId;
			data = yield DataInterfaceService.update(dataInterfaceId, info);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function update(_x9, _x10) {
		return _ref5.apply(this, arguments);
	};
})();

let close = exports.close = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let dataInterfaceId = ctx.params.dataInterfaceId;
			data = yield DataInterfaceService.close(dataInterfaceId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function close(_x11, _x12) {
		return _ref6.apply(this, arguments);
	};
})();

let open = exports.open = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let dataInterfaceId = ctx.params.dataInterfaceId;
			data = yield DataInterfaceService.open(dataInterfaceId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function open(_x13, _x14) {
		return _ref7.apply(this, arguments);
	};
})();

var _helper = require('../common/util/helper');

var _dataInterfaceService = require('./data.interface.service.js');

var DataInterfaceService = _interopRequireWildcard(_dataInterfaceService);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let rollerTypeMap = _config2.default.rollerTypeMap;
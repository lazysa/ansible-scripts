'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.previewMetaObjectFieldCountBak = exports.previewMetaObjectFieldBak = exports.previewMetaObjectFieldCount = exports.previewMetaObjectField = exports.objectList = exports.previewMetaObject = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let previewMetaObject = exports.previewMetaObject = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (objectName) {
        let url = _config2.default.reportMetaBaseUrl + `/preview/${objectName}/list`;
        let data = yield (0, _helper.getReportData)(url, {
            "searchField": [],
            "likeKeyword": ""
        });
        return data;
    });

    return function previewMetaObject(_x) {
        return _ref.apply(this, arguments);
    };
})();

let objectList = exports.objectList = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* () {
        let url = _config2.default.reportMetaBaseUrl + `/object_list`;
        let data = yield (0, _helper.getReportData)(url, {
            attributes: {}
        });
        return data.list;
    });

    return function objectList() {
        return _ref2.apply(this, arguments);
    };
})();

let previewMetaObjectField = exports.previewMetaObjectField = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (objectName, field = '') {
        let url = _config2.default.reportMetaBaseUrl + `/object_field_value`;
        let data = yield (0, _helper.getReportData)(url, {
            attributes: {
                objectName: objectName,
                field: field,
                limit: 200
            }
        });
        return data.list;
    });

    return function previewMetaObjectField(_x2) {
        return _ref3.apply(this, arguments);
    };
})();

let previewMetaObjectFieldCount = exports.previewMetaObjectFieldCount = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (objectName, field = '') {
        let url = _config2.default.reportMetaBaseUrl + `/object_info`;
        let data = yield (0, _helper.getReportData)(url, { attributes: { objectName: objectName } });
        if (data.length > 0) {
            return data[0];
        }
        return {};
    });

    return function previewMetaObjectFieldCount(_x3) {
        return _ref4.apply(this, arguments);
    };
})();

let previewMetaObjectFieldBak = exports.previewMetaObjectFieldBak = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (objectName, field = '') {
        let url = _config2.default.reportMetaBaseUrl + `/preview/${objectName}/field`;
        let data = yield (0, _helper.getReportData)(url, {
            "searchField": field,
            "limit": 200
        });
        return data;
    });

    return function previewMetaObjectFieldBak(_x4) {
        return _ref5.apply(this, arguments);
    };
})();

let previewMetaObjectFieldCountBak = exports.previewMetaObjectFieldCountBak = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (objectName, field = '') {
        let url = _config2.default.reportMetaBaseUrl + `/preview/${objectName}/fieldCount`;
        let data = yield (0, _helper.getReportData)(url, {});
        return data;
    });

    return function previewMetaObjectFieldCountBak(_x5) {
        return _ref6.apply(this, arguments);
    };
})();

var _consts = require('../../config/consts');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _helper = require('../common/util/helper');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
    Status
} = _consts.Enums;
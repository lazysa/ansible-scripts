'use strict';

var _koa = require('koa');

var _koa2 = _interopRequireDefault(_koa);

var _koaConvert = require('koa-convert');

var _koaConvert2 = _interopRequireDefault(_koaConvert);

var _koaError = require('koa-error');

var _koaError2 = _interopRequireDefault(_koaError);

var _koaCors = require('koa-cors');

var _koaCors2 = _interopRequireDefault(_koaCors);

var _config = require('./config/config');

var _config2 = _interopRequireDefault(_config);

var _router = require('./router');

var _router2 = _interopRequireDefault(_router);

var _koaBody = require('koa-body');

var _koaBody2 = _interopRequireDefault(_koaBody);

var _upmAuth = require('upm-auth');

var _log = require('./modules/common/core/log');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const app = new _koa2.default();

app.use((0, _koaConvert2.default)((0, _upmAuth.auth)({
	whitePaths: _config2.default.whitePaths,
	appId: _config2.default.authAppId,
	basePath: _config2.default.authAPiPath,
	logger: _log.log,
	disable: _config2.default.env == "development" ? true : false,
	disableCache: _config2.default.env == "development" ? true : true,
	token: "testtoken2"
})));

//body解析
app.use((0, _koaConvert2.default)((0, _koaBody2.default)({
	formidable: {
		uploadDir: _config2.default.uploadDir
	},
	multipart: true
})));
/*
跨域支持
todo 白名单
*/
app.use((0, _koaConvert2.default)((0, _koaCors2.default)({
	credentials: true
})));

//禁止缓存
if (_config2.default.env == 'development') {
	app.use(function (ctx, next) {
		ctx.set('Cache-Control', 'no-cache, no-store, must-revalidate'); // HTTP 1.1.
		ctx.set('Pragma', 'no-cache'); // HTTP 1.0.
		ctx.set('Expires', '0'); // Proxies.
		return next();
	});
}
//输出错误日志 开发环境使用
if (_config2.default.env == 'development') {
	app.use((0, _koaConvert2.default)((0, _koaError2.default)()));
} else {
	app.on('error', function (err, ctx) {
		ctx.status = err.status || 500;
		ctx.body = err.message;
		if (ctx.status != 404) {
			_log.log.error({
				type: "System",
				err: _koaError2.default
			});
		}
	});
}
//路由
(0, _router2.default)(app);

app.listen(_config2.default.port, function () {
	console.info('listen on', _config2.default.port);
});
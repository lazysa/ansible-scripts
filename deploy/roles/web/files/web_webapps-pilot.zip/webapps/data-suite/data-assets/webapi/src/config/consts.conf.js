"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});


let consts = {};

//返回结果
consts.ResponseStatus = [{
	id: "Normal",
	code: "E0",
	message: "ok"
}];

//状态
consts.Status = [{
	id: "Deleted",
	value: 0,
	name: "删除"
}, {
	id: "Normal",
	value: 1,
	name: "正常"
}];

//数据角色
consts.DataRollerType = [{
	id: "Provider",
	value: 1,
	name: "数据源"
}, {
	id: "Receiver",
	value: 2,
	name: "数据分发"
}];

consts.DataOwnerType = [{
	id: "First",
	value: 1,
	name: "第一方数据源"
}, {
	id: "Thrid",
	value: 2,
	name: "第三方数据源"
}];

consts.DataHubStatus = [{
	id: "Open",
	value: 1,
	name: "开启"
}, {
	id: "Close",
	value: 2,
	name: "关闭"
}];

consts.Encoding = [{
	id: "Utf8",
	value: 1,
	encoding: "utf8",
	name: "UTF-8"
}, {
	id: "Gbk",
	value: 2,
	encoding: "gbk",
	name: "GBK/GB2312"
}];

consts.DataUpdateType = [{
	id: "Insert",
	value: 1,
	name: "添加新记录"
}, {
	id: "Update",
	value: 2,
	name: "更新现有记录"
}, {
	id: "Upsert",
	value: 3,
	name: "添加新记录并更新现有记录"
}, {
	id: "Replace",
	value: 5,
	name: "全表更新"
}];

consts.PreviewDataType = [{
	id: "File",
	value: 1,
	name: "文件"
}, {
	id: "Base64",
	value: 2,
	name: "Base64"
}, {
	id: "FilePath",
	value: 3,
	name: "文件路径"
}];

consts.StorageType = [{
	id: "bigint",
	value: "bigint",
	name: "bigint"
}, {
	id: "double",
	value: "double",
	name: "double"
}, {
	id: "string",
	value: "string",
	name: "string"
}];

consts.TaskType = [{
	id: "Api",
	value: 1,
	name: "api"
}, {
	id: "Upload",
	value: 2,
	name: "upload"
}];

consts.TaskType = [{
	id: "Api",
	value: 1,
	name: "api"
}, {
	id: "Upload",
	value: 2,
	name: "upload"
}];

consts.UploadTaskStatus = [{
	id: "Uploading",
	value: 1,
	name: "文件上传中"
}, {
	id: "Uploaded",
	value: 2,
	name: "文件已上传"
}, {
	id: "Preparing",
	value: 3,
	name: "preparing"
}, {
	id: "Prepared",
	value: 4,
	name: "准备入库"
}, {
	id: "Processing",
	value: 5,
	name: "正在处理"
}, {
	id: "Done",
	value: 6,
	name: "已完成"
}, {
	id: "Error",
	value: -1,
	name: "异常"
}];

consts.DataMappingStatus = [{
	id: "Open",
	value: 1,
	name: "开启"
}, {
	id: "Close",
	value: 2,
	name: "关闭"
}];

consts.DataMappingSendingType = [{
	id: "Own",
	value: 1,
	name: "我方发起"
}, {
	id: "Other",
	value: 2,
	name: "对方发起"
}];

consts.DataInterfaceStatus = [{
	id: "Open",
	value: 1,
	name: "开启"
}, {
	id: "Close",
	value: 2,
	name: "关闭"
}];

consts.UploadFileType = [{
	id: "Log",
	value: 1,
	name: "行为数据"
}, {
	id: "Dictionary",
	value: 2,
	name: "字典文件"
}];

consts.EncryptType = [{
	id: "Md5",
	value: 1,
	name: "md5",
	type: "md5"
}, {
	id: "Sha1",
	value: 2,
	name: "sha1",
	type: "sha1"
}, {
	id: "Base64",
	value: 3,
	name: "base64",
	type: "base64"
}];

consts.MetricsValueType = [{
	id: "Number",
	value: 1,
	name: "number"
}, {
	id: "Percent",
	value: 2,
	name: "percent"
}, {
	id: "Decimal",
	value: 3,
	name: "decimal"
}, {
	id: "String",
	value: 4,
	name: "string"
}];

exports.default = consts;
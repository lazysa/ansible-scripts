'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
let consts = {};

//系统级别
consts.ProgramerException = {
	code: "E300",
	message: "系统程序执行错误"
};

consts.ParamsInvalid = {
	code: "E302",
	message: "数据验证失败"
};

consts.DataIsNull = {
	code: "E303",
	message: "数据为空"
};

consts.DataException = {
	code: "E304",
	message: "数据异常"
};

consts.UrlInvalid = {
	code: "E305",
	message: "非法url"
};

consts.DataApp = [{
	name: "ServerNetError",
	code: "E3051",
	message: "数据应用服务器网络错误"
}, {
	name: "ServerError",
	code: "E3052",
	message: "数据应用服务器错误"
}, {
	name: "QueryError",
	code: "E3053",
	message: "数据应用查询错误"
}];

consts.Api = [{
	name: "NoRight",
	code: "E35001",
	message: "无权限"
}];

consts.DataHub = [{
	name: "NotExists",
	code: "E4101",
	message: "datahub不存在"
}, {
	name: "Closed",
	code: "E4102",
	message: "datahub在关闭状态"
}];

consts.File = [{
	name: "FormatNotSupport",
	code: "E5201",
	message: "文件格式不支持"
}, {
	name: "SizeOverFlow",
	code: "E5202",
	message: "文件超过限制"
}, {
	name: "SaveToS3Error",
	code: "E5203",
	message: "保存到s3发生错误"
}, {
	name: "SaveToHdfsError",
	code: "E5204",
	message: "保存到hdfs发生错误"
}, {
	name: "NotExists",
	code: "E5205",
	message: "服务器端不存在该文件"
}];

consts.DataMapping = [{
	name: "RequireMaro",
	code: "E5301",
	message: "需要宏"
}, {
	name: "HasSetMapping",
	code: "E5302",
	message: "已经设置过Mapping"
}];

exports.default = consts;
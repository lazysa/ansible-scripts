'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _file = require('./file.controller');

var controller = _interopRequireWildcard(_file);

var _file2 = require('./file.filter');

var filter = _interopRequireWildcard(_file2);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
	prefix: "/file"
});

router.get('/pages', filter.pages, controller.pages);

router.get('/:fileId/resumeTask', controller.resumeTask);

router.get('/download/:fileId', controller.downloadUploadFile);

router.post('/upload', filter.upload, controller.upload);

router.post('/preview', filter.preview, controller.preview);

router.post('/', filter.create, controller.create);

exports.default = router;
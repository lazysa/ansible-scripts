'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.previewMetaObjectFieldCount = exports.previewMetaObjectField = exports.objectList = exports.previewMetaObject = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let previewMetaObject = exports.previewMetaObject = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            let { objectName } = ctx.params;

            data = yield Service.previewMetaObject(objectName);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function previewMetaObject(_x, _x2) {
        return _ref.apply(this, arguments);
    };
})();

let objectList = exports.objectList = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            data = yield Service.objectList();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function objectList(_x3, _x4) {
        return _ref2.apply(this, arguments);
    };
})();

let previewMetaObjectField = exports.previewMetaObjectField = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            let { objectName } = ctx.params;
            let { field } = ctx.request.query;
            data = yield Service.previewMetaObjectField(objectName, field);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function previewMetaObjectField(_x5, _x6) {
        return _ref3.apply(this, arguments);
    };
})();

let previewMetaObjectFieldCount = exports.previewMetaObjectFieldCount = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            let { objectName } = ctx.params;
            let fieldCountMap = yield Service.previewMetaObjectFieldCount(objectName);
            let sysList = yield (0, _api.sysUserIdColumnsList)(objectName);
            data = Object.keys(fieldCountMap).map(function (item) {
                let obj = {
                    field: item,
                    fieldCount: fieldCountMap[item]
                };
                let existItem = sysList.find(function (z) {
                    return z.userIdColumn === item;
                });
                console.log(existItem);
                if (existItem) Object.assign(obj, { userIdType: existItem.userIdType, userIdName: existItem.userIdName });
                return obj;
            });
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function previewMetaObjectFieldCount(_x7, _x8) {
        return _ref4.apply(this, arguments);
    };
})();

var _consts = require('../../config/consts');

var _helper = require('../common/util/helper');

var _metaobject = require('./metaobject.service');

var Service = _interopRequireWildcard(_metaobject);

var _api = require('../api/api.service');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
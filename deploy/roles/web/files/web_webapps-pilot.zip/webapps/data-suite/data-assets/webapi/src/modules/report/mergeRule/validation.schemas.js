'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.download = exports.idCountDistribution = exports.associationRatio = exports.idDistribution = exports.trend = exports.overview = undefined;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let overview = exports.overview = _joi2.default.object().keys({
	mergeRuleId: _joi2.default.number().integer().required()
});

let trend = exports.trend = _joi2.default.object().keys({
	mergeRuleId: _joi2.default.number().integer().required(),
	metric: _joi2.default.array().items(_joi2.default.string()).length(2).required()
});

let idDistribution = exports.idDistribution = _joi2.default.object().keys({
	mergeRuleId: _joi2.default.number().integer().required(),
	metric: _joi2.default.array().items(_joi2.default.string()).length(1).required()
});

let associationRatio = exports.associationRatio = _joi2.default.object().keys({
	mergeRuleId: _joi2.default.number().integer().required(),
	contrastUserIdType: _joi2.default.array().items(_joi2.default.alternatives().try(_joi2.default.number(), _joi2.default.string())).required()
});

[_joi2.default.string().required(), _joi2.default.number().required()];

let idCountDistribution = exports.idCountDistribution = _joi2.default.object().keys({
	mergeRuleId: _joi2.default.number().integer().required()
});

let download = exports.download = _joi2.default.object().keys({
	mergeRuleId: _joi2.default.number().integer().required()
});
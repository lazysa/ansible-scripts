'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.download = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let download = exports.download = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				fileToken
			} = ctx.params;
			let removeFileToken = true;
			let fileInfo = yield DownloadService.getFile(fileToken, removeFileToken);
			if (fileInfo) {
				ctx.attachment(fileInfo.fileName);
				return ctx.body = _fs2.default.createReadStream(fileInfo.filePath);
			} else {
				ctx.status = 404;
			}
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function download(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

var _helper = require('../common/util/helper');

var _download = require('./download.service');

var DownloadService = _interopRequireWildcard(_download);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
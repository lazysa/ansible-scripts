'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.baseInfo = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let baseInfo = exports.baseInfo = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				appId
			} = ctx.request.body;
			let url = wechatAppBaseUrl + 'base/info';
			data = yield (0, _helper.getReportData)(url, {
				authorizer_appid: appId
			});
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function baseInfo(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

var _helper = require('../common/util/helper');

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	wechatAppBaseUrl
} = _config2.default;
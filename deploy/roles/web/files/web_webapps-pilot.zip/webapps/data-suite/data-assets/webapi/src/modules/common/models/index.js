'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.DataTypeStorageType = exports.UserIdType = exports.UploadFile = exports.SysUserIdColumns = exports.Metrics = exports.MergeRule = exports.DataMapping = exports.DataInterfaceProcesser = exports.DataInterface = exports.DataHubLink = exports.DataHub = exports.DataCategory = exports.sequelize = undefined;
exports.renameKeys = renameKeys;

var _sequelize = require('sequelize');

var _sequelize2 = _interopRequireDefault(_sequelize);

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _path = require('path');

var _log = require('../core/log');

var _lodash = require('lodash');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
timestamps: false的表
channel.info
industry.info
*/

let dbConfig = _config2.default.mysql;

let sequelize = exports.sequelize = new _sequelize2.default(dbConfig.database, dbConfig.user, dbConfig.password, {
	host: dbConfig.host,
	dialect: 'mysql',
	pool: {
		max: dbConfig.poolSize,
		min: 0,
		idle: 10000
	},
	logging: dbConfig.logging,
	define: {
		underscored: true,
		hooks: { //http://docs.sequelizejs.com/en/latest/docs/hooks/
			beforeBulkCreate: function (rows) {
				rows.forEach(function (row) {
					if (typeof row.status == 'undefined' || row.status == null) {
						row.status = 1;
					}
				});
			},
			beforeValidate: function (row) {
				if (typeof row.status == 'undefined' || row.status == null) {
					row.status = 1;
				}
			}
		}
	}
});

sequelize.authenticate().catch(function (errors) {
	_log.log.info({
		type: "Mysql",
		err: errors
	});
});

function renameKeys(data) {
	if (data.length) {
		data = (0, _lodash.map)(data, function (item) {
			item = (0, _lodash.mapKeys)(item, function (value, key) {
				return (0, _lodash.camelCase)(key);
			});
			return item;
		});
	} else {
		data = (0, _lodash.mapKeys)(data, function (value, key) {
			return (0, _lodash.camelCase)(key);
		});
	}
	return data;
}

let DataCategory = exports.DataCategory = sequelize.import((0, _path.join)(__dirname, './data.category'));
let DataHub = exports.DataHub = sequelize.import((0, _path.join)(__dirname, './data.hub'));
let DataHubLink = exports.DataHubLink = sequelize.import((0, _path.join)(__dirname, './data.hub.link'));
let DataInterface = exports.DataInterface = sequelize.import((0, _path.join)(__dirname, './data.interface'));
let DataInterfaceProcesser = exports.DataInterfaceProcesser = sequelize.import((0, _path.join)(__dirname, './data.interface.processer'));
let DataMapping = exports.DataMapping = sequelize.import((0, _path.join)(__dirname, './data.mapping'));
let MergeRule = exports.MergeRule = sequelize.import((0, _path.join)(__dirname, './merge.rule'));
let Metrics = exports.Metrics = sequelize.import((0, _path.join)(__dirname, './metrics'));
let SysUserIdColumns = exports.SysUserIdColumns = sequelize.import((0, _path.join)(__dirname, './sys.user.id.columns'));
let UploadFile = exports.UploadFile = sequelize.import((0, _path.join)(__dirname, './upload.file'));
let UserIdType = exports.UserIdType = sequelize.import((0, _path.join)(__dirname, './user.id.type'));
let DataTypeStorageType = exports.DataTypeStorageType = sequelize.import((0, _path.join)(__dirname, './data.type.storage.type'));
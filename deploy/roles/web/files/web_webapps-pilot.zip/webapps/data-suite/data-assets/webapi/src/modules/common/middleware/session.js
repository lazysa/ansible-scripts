"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.Store = undefined;

var _asyncToGenerator2 = require("babel-runtime/helpers/asyncToGenerator");

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

exports.default = function (opts = {}) {
    opts.key = opts.key || "koa:sess";
    opts.store = opts.store || new Store();

    return (() => {
        var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
            let id = ctx.cookies.get(opts.key, opts);

            if (!id) {
                ctx.session = {};
                opts.sid = null; //改变id
            } else {
                ctx.session = yield opts.store.get(id);
                ctx.session = typeof ctx.session === "string" ? {} : ctx.session;
            }

            let old = JSON.stringify(ctx.session);

            if (!ctx.session) {
                ctx.session = {};
                opts.sid = null;
            }

            yield next();

            if (old == JSON.stringify(ctx.session)) return;
            if (id) yield opts.store.destroy(id);
            if (ctx.session && Object.keys(ctx.session).length) {
                let sid = yield opts.store.set(ctx.session, opts);
                ctx.cookies.set(opts.key, sid, opts);
            }
        });

        return function (_x, _x2) {
            return _ref.apply(this, arguments);
        };
    })();
};

var _uidSafe = require("uid-safe");

var _uidSafe2 = _interopRequireDefault(_uidSafe);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class Store {
    constructor() {
        this.session = {};
    }

    decode(string) {
        if (!string) return "";

        let session = "";

        try {
            session = new Buffer(string, "base64").toString();
        } catch (e) {}

        return JSON.parse(session);
    }

    encode(obj) {
        return new Buffer(obj).toString("base64");
    }

    getID(length) {
        return _uidSafe2.default.sync(length);
    }

    get(sid) {
        var _this = this;

        return (0, _asyncToGenerator3.default)(function* () {
            return _this.decode(_this.session[sid]);
        })();
    }

    set(session, opts) {
        var _this2 = this;

        return (0, _asyncToGenerator3.default)(function* () {
            opts = opts || {};
            if (!opts.sid) {
                opts.sid = _this2.getID(24);
            }

            _this2.session[opts.sid] = _this2.encode(JSON.stringify(session));

            return opts.sid;
        })();
    }

    destroy(sid) {
        var _this3 = this;

        return (0, _asyncToGenerator3.default)(function* () {
            delete _this3.session[sid];
        })();
    }
}

exports.Store = Store;
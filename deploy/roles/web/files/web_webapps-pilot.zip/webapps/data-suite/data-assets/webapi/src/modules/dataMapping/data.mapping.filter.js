'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.checkDataHubStatus = exports.update = exports.create = exports.pages = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

//filter过滤参数

let pages = exports.pages = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.pages;
		try {
			const result = _joi2.default.validate(ctx.request.query, schema);
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function pages(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.create;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			// let {
			// 	sendingType,
			// 	isTwoWay,
			// 	partnerUrl
			// } = ctx.request.body;
			// if (sendingType == DataMappingSendingType.Other && isTwoWay == 1) {
			// 	if (isEmpty(partnerUrl)) {
			// 		throw new errors.ParamsInvalid("partnerUrl required");
			// 	}
			// }
			let {
				startTime,
				endTime
			} = result.value;
			if (startTime && endTime && endTime <= startTime) {
				throw new _errors2.default.ParamsInvalid("endTime must greater than startTime");
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function create(_x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.update;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			// let {
			// 	sendingType,
			// 	isTwoWay,
			// 	partnerUrl
			// } = ctx.request.body;
			// if (sendingType == DataMappingSendingType.Other && isTwoWay == 1) {
			// 	if (isEmpty(partnerUrl)) {
			// 		throw new errors.ParamsInvalid("partnerUrl required");
			// 	}
			// }
			let {
				startTime,
				endTime
			} = result.value;
			if (startTime && endTime && endTime <= startTime) {
				throw new _errors2.default.ParamsInvalid("endTime must greater than startTime");
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function update(_x5, _x6) {
		return _ref3.apply(this, arguments);
	};
})();

let checkDataHubStatus = exports.checkDataHubStatus = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		try {
			let dataHubId;
			if (ctx.method.toLowerCase() == "post") {
				dataHubId = ctx.request.body.dataHubId;
			} else {
				dataHubId = ctx.params.dataHubId;
			}
			let dataHub = yield DataHubService.query(dataHubId);
			//如果是dataHub是关闭状态，不能开启
			if (!dataHub) {
				throw new _errors2.default.DataHubNotExists();
			} else if (dataHub.status != DataHubStatus.Open) {
				throw new _errors2.default.DataHubClosed();
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function checkDataHubStatus(_x7, _x8) {
		return _ref4.apply(this, arguments);
	};
})();

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _validation = require('./validation.schemas');

var schemas = _interopRequireWildcard(_validation);

var _helper = require('../common/util/helper');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _dataHubService = require('../dataHub/dataHub.service.js');

var DataHubService = _interopRequireWildcard(_dataHubService);

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	DataMappingSendingType,
	DataHubStatus
} = _consts.Enums;
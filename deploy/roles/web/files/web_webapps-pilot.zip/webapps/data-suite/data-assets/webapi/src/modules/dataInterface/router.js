'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _dataInterface = require('./data.interface.controller');

var controller = _interopRequireWildcard(_dataInterface);

var _dataInterface2 = require('./data.interface.filter');

var filter = _interopRequireWildcard(_dataInterface2);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
	prefix: "/dataInterface"
});

router.get('/:dataHubId/list', controller.list);

router.get('/:dataHubId/pages', filter.pages, controller.pages);

router.post('/:dataHubId/create', filter.checkDataHubStatus, filter.create, controller.create);

router.get('/:dataHubId/:dataInterfaceId', controller.query);

router.put('/:dataHubId/:dataInterfaceId', filter.checkDataHubStatus, filter.update, controller.update);

router.get('/:dataHubId/:dataInterfaceId/close', controller.close);

router.get('/:dataHubId/:dataInterfaceId/open', filter.checkDataHubStatus, controller.open);

exports.default = router;
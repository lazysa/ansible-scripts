"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _errors = require("../../../config/errors.conf");

var _errors2 = _interopRequireDefault(_errors);

var _util = require("util");

var _util2 = _interopRequireDefault(_util);

var _lodash = require("lodash");

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let defineError = function (name, code, defaultMessage) {
	defaultMessage = defaultMessage || "发生错误";
	let SelfError = function (message) {
		Error.captureStackTrace(this, this.constructor);
		this.name = name;
		this.code = code;
		this.message = message || defaultMessage;
	};
	_util2.default.inherits(SelfError, Error);
	return SelfError;
};

function confToError(conf) {
	let errors = {};
	for (let k in conf) {
		let item = conf[k];
		if (_lodash2.default.isArray(item)) {
			for (let i = 0; i < item.length; i++) {
				let subItem = item[i];
				let name = k + subItem.name;
				errors[name] = defineError(name, subItem.code, subItem.message);
			}
		} else if (_lodash2.default.isObject(item)) {
			let name = k;
			errors[name] = defineError(name, item.code, item.message);
		}
	}
	return errors;
}

let errors = confToError(_errors2.default);

errors.defineError = defineError;

exports.default = errors;
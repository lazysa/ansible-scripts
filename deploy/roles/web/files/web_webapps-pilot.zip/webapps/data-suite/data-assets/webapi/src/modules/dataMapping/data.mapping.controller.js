'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.close = exports.open = exports.remove = exports.update = exports.create = exports.generMappingUrl = exports.query = exports.pages = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let pages = exports.pages = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				pageSize,
				pageIndex,
				keyword
			} = ctx.query;
			pageSize = pageSize * 1;
			pageIndex = pageIndex * 1;
			let offset = (pageIndex - 1) * pageSize;
			let count = yield DataMappingService.count(keyword);
			let list = yield DataMappingService.pages(pageSize, offset, keyword);
			data = {
				list: list,
				pageIndex: pageIndex,
				pageSize: pageSize,
				total: count
			};
		} catch (ex) {
			//console.info(ex);
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function pages(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let query = exports.query = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let dataHubId = ctx.params.dataHubId;
			let urlData = {
				accountId: accountId,
				dataHubId: dataHubId
			};
			let info = yield DataMappingService.query(dataHubId);
			/*
   	launchUrl 自动生成
   	partnerUrl 
   	singleReceiverUrl 自动生成
   	mappingReceiverUrl 自动生成
   		http://baidu.com/cgi?cc_p_open_id=48d361ca544c95c6a56d7a3745aba92f&cc_pid=44&cc_acid=33&cc_domain=www.nick_local.com
   		http://baidu.com/cgi?cc_p_open_id={cc_p_open_id}
   	&cc_domain={cc_domain}&cc_pid=#datahubId#&cc_acid=#accountId#
   		cc_pid=#datahubId#&cc_acid=#accountId#
   */
			if (info == null) {
				data = {};
			} else {
				data = info;
			}
			// let fullPartnerUrl;
			let formatStr = DataMappingService.formatStr;
			data.launchUrl = formatStr(mappingUrl.launchUrl, urlData);
			data.singleReceiverUrl = formatStr(mappingUrl.singleReceiverUrl, urlData);
			data.mappingReceiverUrl = formatStr(mappingUrl.mappingReceiverUrl, urlData);

			// if (info != null) {
			// 	if (info.sendingType == DataMappingSendingType.Own || info.sendingType == DataMappingSendingType.Other && info.isTwoWay == 1) {
			// 		if (info.partnerUrl.indexOf("&") != -1) {
			// 			fullPartnerUrl = info.partnerUrl + "&cc_pid=#dataHubId#&cc_acid=#accountId#";
			// 		} else {
			// 			fullPartnerUrl = info.partnerUrl + "?cc_pid=#dataHubId#&cc_acid=#accountId#";
			// 		}
			// 		data.fullPartnerUrl = formatStr(fullPartnerUrl, urlData);
			// 	}
			// }
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function query(_x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

let generMappingUrl = exports.generMappingUrl = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let dataHubId = ctx.params.dataHubId;
			let urlData = {
				accountId: accountId,
				dataHubId: dataHubId
			};
			data = {};
			let formatStr = DataMappingService.formatStr;
			data.launchUrl = formatStr(mappingUrl.launchUrl, urlData);
			data.singleReceiverUrl = formatStr(mappingUrl.singleReceiverUrl, urlData);
			data.mappingReceiverUrl = formatStr(mappingUrl.mappingReceiverUrl, urlData);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function generMappingUrl(_x5, _x6) {
		return _ref3.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let body = ctx.request.body;
			let dataHubId = body.dataHubId;
			let dataMapping = yield DataMappingService.query(dataHubId);
			if (dataMapping) {
				throw new _errors2.default.DataMappingHasSetMapping();
			}
			let info = (0, _lodash.pick)(body, ['dataHubId', 'status', 'sendingType', 'isTwoWay', 'publicKey', 'autoMapping', 'startTime', 'endTime', 'priority']);
			data = yield DataMappingService.create(info);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function create(_x7, _x8) {
		return _ref4.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let body = ctx.request.body;
			let dataHubId = ctx.params.dataHubId;
			let info = (0, _lodash.pick)(body, ['status', 'sendingType', 'isTwoWay', 'publicKey', 'autoMapping', 'startTime', 'endTime', 'priority']);
			info.dataHubId = dataHubId;

			/*
   	http://baidu.com/cgi?cc_p_open_id=48d361ca544c95c6a56d7a3745aba92f&cc_pid=44&cc_acid=33&cc_domain=www.nick_local.com
   		http://baidu.com/cgi?cc_p_open_id={cc_p_open_id}
   	&cc_domain={cc_domain}&cc_pid=#datahubId#&cc_acid=#accountId#
   		cc_pid=#datahubId#&cc_acid=#accountId#
   		{CC_OPEN_ID}：我方域下CookieID。即驰骛监测域，或驰骛客户第一方域的CookieID。
   	{CC_P_OPEN_ID}：对接方域下CookieID。例如AdExchange域下CookieID。
   	{CC_DOMAIN}：发起请求的客户端域名。
   	*/

			// let requirePartnerUrl = false;
			// let partnerOpenIdMacro = "{CC_OPEN_ID}";
			// if (info.sendingType == DataMappingSendingType.Own) {
			// 	//我方发送
			// 	requirePartnerUrl = true;
			// 	if (info.partnerUrl.indexOf(partnerOpenIdMacro) == -1) {
			// 		throw new errors.DataMappingRequireMaro("缺少宏:{CC_OPEN_ID}");
			// 	}
			// } else {
			// 	//对方发送双向
			// 	if (info.isTwoWay == 1) {
			// 		requirePartnerUrl = true;
			// 		if (info.partnerUrl.indexOf(partnerOpenIdMacro) == -1) {
			// 			throw new errors.DataMappingRequireMaro("缺少宏:{CC_OPEN_ID}");
			// 		}
			// 	}
			// }
			// if (requirePartnerUrl) {
			// 	if (!isURL(info.partnerUrl)) {
			// 		throw new errors.UrlInvalid();
			// 	}
			// }

			data = yield DataMappingService.update(dataHubId, info);
		} catch (ex) {
			//console.info(ex);
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function update(_x9, _x10) {
		return _ref5.apply(this, arguments);
	};
})();

let remove = exports.remove = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let dataHubId = ctx.params.dataHubId;
			data = yield DataMappingService.remove(dataHubId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function remove(_x11, _x12) {
		return _ref6.apply(this, arguments);
	};
})();

let open = exports.open = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let dataHubId = ctx.params.dataHubId;
			data = yield DataMappingService.open(dataHubId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function open(_x13, _x14) {
		return _ref7.apply(this, arguments);
	};
})();

let close = exports.close = (() => {
	var _ref8 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let dataHubId = ctx.params.dataHubId;
			data = yield DataMappingService.close(dataHubId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function close(_x15, _x16) {
		return _ref8.apply(this, arguments);
	};
})();

var _helper = require('../common/util/helper');

var _dataMappingService = require('./data.mapping.service.js');

var DataMappingService = _interopRequireWildcard(_dataMappingService);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _lodash = require('lodash');

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _consts = require('../../config/consts');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	DataMappingSendingType,
	DataHubStatus
} = _consts.Enums;
let {
	mappingUrl,
	accountId,
	rollerTypeMap
} = _config2.default;
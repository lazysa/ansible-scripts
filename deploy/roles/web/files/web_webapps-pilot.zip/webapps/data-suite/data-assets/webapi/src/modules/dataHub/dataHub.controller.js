'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.update = exports.create = exports.pages = exports.allList = exports.listFliterByMapped = exports.list = exports.open = exports.close = exports.query = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let query = exports.query = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let rollerType = rollerTypeMap[ctx.params.rollerType];
			let {
				dataHubId
			} = ctx.params;
			data = yield DataHubService.query(dataHubId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function query(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let close = exports.close = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let rollerType = rollerTypeMap[ctx.params.rollerType];
			let {
				dataHubId
			} = ctx.params;
			data = yield DataHubService.close(rollerType, dataHubId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function close(_x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

let open = exports.open = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let rollerType = rollerTypeMap[ctx.params.rollerType];
			let {
				dataHubId
			} = ctx.params;
			data = yield DataHubService.open(rollerType, dataHubId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function open(_x5, _x6) {
		return _ref3.apply(this, arguments);
	};
})();

let list = exports.list = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				rollerType
			} = ctx.params.rollerType;
			let {
				hasTag
			} = ctx.state.query;
			let condition = {
				rollerType: rollerTypeMap[ctx.params.rollerType]
			};
			if (hasTag != undefined) {
				condition.hasTag = hasTag;
			}
			data = yield DataHubService.list(condition);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function list(_x7, _x8) {
		return _ref4.apply(this, arguments);
	};
})();

let listFliterByMapped = exports.listFliterByMapped = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let rollerType = rollerTypeMap[ctx.params.rollerType];
			data = yield DataHubService.listFliterByMapped(rollerType);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function listFliterByMapped(_x9, _x10) {
		return _ref5.apply(this, arguments);
	};
})();

let allList = exports.allList = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			data = yield DataHubService.allList();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function allList(_x11, _x12) {
		return _ref6.apply(this, arguments);
	};
})();

let pages = exports.pages = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let rollerType = rollerTypeMap[ctx.params.rollerType];
			let {
				pageSize,
				pageIndex,
				keyword
			} = ctx.query;
			let condition = {
				rollerType: rollerType
			};
			if (keyword) {
				condition["$or"] = {
					id: {
						$like: '%' + keyword + '%'
					},
					name: {
						$like: '%' + keyword + '%'
					}
				};
			}
			pageSize = pageSize * 1;
			pageIndex = pageIndex * 1;
			let offset = (pageIndex - 1) * pageSize;
			let count = yield DataHubService.count(condition);
			let list = yield DataHubService.pages(pageSize, offset, condition);
			data = {
				list: list,
				pageIndex: pageIndex,
				pageSize: pageSize,
				total: count
			};
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function pages(_x13, _x14) {
		return _ref7.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref8 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let rollerType = rollerTypeMap[ctx.params.rollerType];
			let body = ctx.request.body;
			let info = (0, _lodash.pick)(body, ["name", "dataCategoryId", 'status', "dataOwnerType"]);
			info.rollerType = rollerType;
			data = yield DataHubService.create(info);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function create(_x15, _x16) {
		return _ref8.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref9 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let rollerType = rollerTypeMap[ctx.params.rollerType];
			let body = ctx.request.body;
			let {
				dataHubId
			} = ctx.params;
			let exists = yield DataHubService.checkExists(dataHubId);
			if (!exists) {
				throw new _errors2.default.DataHubNotExists();
			}
			let info = (0, _lodash.pick)(body, ["name", "dataCategoryId", 'status', "dataOwnerType"]);
			data = yield DataHubService.update(dataHubId, info);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function update(_x17, _x18) {
		return _ref9.apply(this, arguments);
	};
})();

var _helper = require('../common/util/helper');

var _dataHubService = require('./dataHub.service.js');

var DataHubService = _interopRequireWildcard(_dataHubService);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _lodash = require('lodash');

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let rollerTypeMap = _config2.default.rollerTypeMap;
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.update = exports.create = exports.pages = undefined;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	DataMappingSendingType
} = _consts.Enums;
let pages = exports.pages = _joi2.default.object().keys({
	pageIndex: _joi2.default.number().integer().min(1).required(),
	pageSize: _joi2.default.number().integer().min(5).max(100).required(),
	keyword: _joi2.default.string().min(1).max(30).allow("", null)
});
let create = exports.create = _joi2.default.object().keys({
	"dataHubId": _joi2.default.number().required(),
	"status": _joi2.default.number().integer().valid([1, 2]).required(),
	"sendingType": _joi2.default.number().integer().valid(_lodash2.default.values(DataMappingSendingType)).required(),
	"isTwoWay": _joi2.default.number().integer().valid([0, 1]).required(),
	// "partnerUrl": Joi.string().max(512).when("sendingType", {
	// 	is: DataMappingSendingType.Own,
	// 	then: Joi.required()
	// }),
	"publicKey": _joi2.default.string().max(256).allow(["", null]),
	"autoMapping": _joi2.default.number().integer().valid([0, 1]),
	"startTime": _joi2.default.date().format("YYYY-MM-DD").allow(null),
	"endTime": _joi2.default.date().format("YYYY-MM-DD").allow(null),
	"priority": _joi2.default.number().integer().min(1).max(10)
}).and("startTime", "endTime");

let update = exports.update = _joi2.default.object().keys({
	"status": _joi2.default.number().integer().valid([1, 2]).required(),
	"sendingType": _joi2.default.number().integer().valid(_lodash2.default.values(DataMappingSendingType)).required(),
	"isTwoWay": _joi2.default.number().integer().valid([0, 1]).required(),
	// "partnerUrl": Joi.string().max(512).when("sendingType", {
	// 	is: DataMappingSendingType.Own,
	// 	then: Joi.required()
	// }),
	"publicKey": _joi2.default.string().max(256).allow(["", null]),
	"autoMapping": _joi2.default.number().integer().valid([0, 1]),
	"startTime": _joi2.default.date().format("YYYY-MM-DD").allow(null),
	"endTime": _joi2.default.date().format("YYYY-MM-DD").allow(null),
	"priority": _joi2.default.number().integer().min(1).max(10)
}).and("startTime", "endTime");

/*
["dataHubId","sendingType","twoWay","launchUrl","partnerUrl","singleReceiverUrl","mappingReceiverUrl","publicKey","autoMapping"]

launchUrl 自动生成
partnerUrl
singleReceiverUrl 自动生成
mappingReceiverUrl 自动生成
*/
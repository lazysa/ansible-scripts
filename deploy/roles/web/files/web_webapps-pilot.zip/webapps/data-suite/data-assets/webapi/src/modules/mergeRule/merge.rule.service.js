'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.remove = exports.query = exports.update = exports.create = exports.resetDefault = exports.pages = exports.list = exports.count = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let count = exports.count = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (condition) {
		condition.status = {
			$ne: Status.Deleted
		};
		return _models.MergeRule.count({
			where: condition
		});
	});

	return function count(_x) {
		return _ref.apply(this, arguments);
	};
})();

let list = exports.list = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (dataHubId) {
		return _models.MergeRule.findAll({
			attributes: ['id', 'name'],
			where: {
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function list(_x2) {
		return _ref2.apply(this, arguments);
	};
})();

let pages = exports.pages = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (pageSize, offset, condition) {
		condition.status = {
			$ne: Status.Deleted
		};
		let data = yield _models.MergeRule.findAll({
			attributes: ['id', 'name', 'isDefault'],
			where: condition,
			limit: pageSize,
			offset: offset,
			order: [['id', 'desc']],
			raw: true
		});
		if (data.length) {
			let url = _config2.default.reportAppBaseUrl + '/merge/list';
			let reportData;
			try {
				reportData = yield (0, _helper.getReportData)(url, {
					mergeRuleIds: (0, _lodash.map)(data, "id")
				});
			} catch (ex) {
				reportData = [];
			}
			let reportMap = (0, _helper.dataToMap)(reportData, 'mergeRuleId');
			data.forEach(function (mergeRule) {
				let mergeRuleId = mergeRule.id;
				Object.assign(mergeRule, {
					ccidCount: null,
					mergeRate: null
				});
				if (reportMap[mergeRuleId]) {
					Object.assign(mergeRule, (0, _lodash.pick)(reportMap[mergeRuleId], ['ccidCount', 'mergeRate']));
				}
			});
		}

		return data;
	});

	return function pages(_x3, _x4, _x5) {
		return _ref3.apply(this, arguments);
	};
})();

let resetDefault = exports.resetDefault = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* () {
		return yield _models.MergeRule.update({
			isDefault: 0
		}, {
			where: {
				status: Status.Normal
			}
		});
	});

	return function resetDefault() {
		return _ref4.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (info) {
		//如果是默认重置其它默认
		if (info.isDefault) {
			yield resetDefault();
		}
		return _models.MergeRule.create(info);
	});

	return function create(_x6) {
		return _ref5.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (ruleId, info) {
		if (info.isDefault) {
			yield resetDefault();
		}
		return _models.MergeRule.update(info, {
			where: {
				id: ruleId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function update(_x7, _x8) {
		return _ref6.apply(this, arguments);
	};
})();

let query = exports.query = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* (ruleId) {
		return _models.MergeRule.findOne({
			where: {
				id: ruleId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function query(_x9) {
		return _ref7.apply(this, arguments);
	};
})();

let remove = exports.remove = (() => {
	var _ref8 = (0, _asyncToGenerator3.default)(function* (ruleId) {
		return _models.MergeRule.update({
			status: Status.Deleted
		}, {
			where: {
				id: ruleId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function remove(_x10) {
		return _ref8.apply(this, arguments);
	};
})();

var _models = require('../common/models');

var _helper = require('../common/util/helper');

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Status
} = _consts.Enums;
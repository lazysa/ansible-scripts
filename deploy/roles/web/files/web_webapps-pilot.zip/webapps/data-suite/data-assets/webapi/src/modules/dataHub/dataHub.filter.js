'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.update = exports.create = exports.pages = exports.list = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

//filter过滤参数

let list = exports.list = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.list;
		try {
			const result = _joi2.default.validate(ctx.query, schema);
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			ctx.state.query = result.value;
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function list(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let pages = exports.pages = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.pages;
		try {
			const result = _joi2.default.validate(ctx.request.query, schema);
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function pages(_x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.create;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema);
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function create(_x5, _x6) {
		return _ref3.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.update;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema);
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function update(_x7, _x8) {
		return _ref4.apply(this, arguments);
	};
})();

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _validation = require('./validation.schemas');

var schemas = _interopRequireWildcard(_validation);

var _helper = require('../common/util/helper');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
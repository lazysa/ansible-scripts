'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createSysUserIdColumns = exports.sysUserIdColumnsList = exports.userIdType = exports.mergeRule = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let mergeRule = exports.mergeRule = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* () {
        return _models.MergeRule.findAll({
            attributes: {
                exclude: ["created_at", "updated_at", "createUserId", "updateUserId"]
            }
        });
    });

    return function mergeRule() {
        return _ref.apply(this, arguments);
    };
})();

let userIdType = exports.userIdType = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (where = {
        status: Status.Normal
    }) {
        return _models.UserIdType.findAll({
            attributes: {
                exclude: ["created_at", "updated_at", "createUserId", "updateUserId"]
            },
            where
        });
    });

    return function userIdType() {
        return _ref2.apply(this, arguments);
    };
})();

let sysUserIdColumnsList = exports.sysUserIdColumnsList = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (tableName) {
        let where = {};
        if (tableName) {
            Object.assign(where, { tableName });
        }
        let data = yield _models.SysUserIdColumns.findAll({
            attributes: {
                exclude: ["created_at", "updated_at", "createUserId", "updateUserId"]
            },
            where,
            raw: true
        });
        let userIdTypeList = yield userIdType();

        let userIdTypeMap = (0, _lodash.keyBy)(userIdTypeList, 'id');
        return data.map(function ({ tableName, userIdColumn, userIdType }) {
            let obj = { tableName, userIdColumn, userIdType };
            if (userIdTypeMap[userIdType]) {
                obj.userIdName = userIdTypeMap[userIdType].userIdTypeDesc;
            }
            return obj;
        });
    });

    return function sysUserIdColumnsList(_x) {
        return _ref3.apply(this, arguments);
    };
})();

let createSysUserIdColumns = exports.createSysUserIdColumns = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (models) {
        return _models.SysUserIdColumns.bulkCreate(models);
    });

    return function createSysUserIdColumns(_x2) {
        return _ref4.apply(this, arguments);
    };
})();

var _models = require('../common/models');

var _helper = require('../common/util/helper');

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _jssha = require('jssha');

var _jssha2 = _interopRequireDefault(_jssha);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
    Status
} = _consts.Enums;


exports.getHash = function (timestamp, randomStr, apiSecret) {
    let shaObj = new _jssha2.default("SHA-512", "TEXT");
    shaObj.update('apiSecret=' + apiSecret + '&randomStr=' + randomStr + '&timestamp=' + timestamp);
    return shaObj.getHash("HEX");
};
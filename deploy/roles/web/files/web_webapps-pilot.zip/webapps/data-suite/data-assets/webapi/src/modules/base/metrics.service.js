'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.getMetrics = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let getMetrics = exports.getMetrics = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* () {
		let data = yield _models.Metrics.findAll({
			attributes: [['metrics_id', 'id'], 'name', ['value_type', 'vtype']],
			where: {
				status: Status.Normal
			},
			raw: true
		});
		data.forEach(function (metric) {
			let valueType = metric.vtype;
			let type = MetricsValueTypeVMap[valueType];
			if (type) {
				metric.vtype = type.name;
			}
		});
		return data;
	});

	return function getMetrics() {
		return _ref.apply(this, arguments);
	};
})();

var _models = require('../common/models');

var _consts = require('../../config/consts');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Status
} = _consts.Enums;
let {
	MetricsValueTypeVMap
} = _consts.ValMaps;
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.getFile = exports.getToken = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let getToken = exports.getToken = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (filePath, fileName) {
		if (!fileName) {
			fileName = _path2.default.basename(filePath);
		}
		let fileToken = yield FileToken.findOneAsync({
			filePath: filePath
		});
		let token = null;
		if (fileToken) {
			token = fileToken.token;
			yield FileToken.updateAsync({
				filePath: filePath
			}, {
				fileName: fileName
			}, {});
		} else {
			token = chance.hash();
			yield FileToken.insertAsync({
				token: token,
				filePath: filePath,
				fileName: fileName
			});
		}
		return token;
	});

	return function getToken(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let getFile = exports.getFile = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (token, removeFileToken) {
		let fileToken = yield FileToken.findOneAsync({
			token: token
		});
		let result = null;
		if (fileToken) {
			result = {
				filePath: fileToken.filePath,
				fileName: fileToken.fileName
			};
			if (removeFileToken) {
				yield FileToken.removeAsync({
					token: token
				});
			}
		}
		return result;
	});

	return function getFile(_x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _chance = require('chance');

var _chance2 = _interopRequireDefault(_chance);

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

var _nedb = require('nedb');

var _nedb2 = _interopRequireDefault(_nedb);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const chance = new _chance2.default();
let FileToken = new _nedb2.default();
FileToken = _bluebird2.default.promisifyAll(FileToken);

;

;
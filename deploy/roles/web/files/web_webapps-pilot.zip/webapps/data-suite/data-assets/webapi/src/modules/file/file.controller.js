'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.preview = exports.upload = exports.create = exports.downloadUploadFile = exports.resumeTask = exports.pages = exports.list = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let list = exports.list = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			data = yield FileService.list();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function list(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let pages = exports.pages = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				pageSize,
				pageIndex,
				keyword
			} = ctx.query;
			var condition = {};
			if (keyword) {
				condition["$or"] = {
					id: {
						$like: '%' + keyword + '%'
					},
					fileName: {
						$like: '%' + keyword + '%'
					}
				};
			}
			pageSize = pageSize * 1;
			pageIndex = pageIndex * 1;
			let offset = (pageIndex - 1) * pageSize;
			let count = yield FileService.count(condition);
			let list = yield FileService.pages(pageSize, offset, condition);
			data = {
				list: list,
				pageIndex: pageIndex,
				pageSize: pageSize,
				total: count
			};
		} catch (ex) {
			console.info(ex);
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function pages(_x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

let resumeTask = exports.resumeTask = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let fileId = ctx.params.fileId;
			let file = yield FileService.query(fileId);
			if (file.taskId) {
				yield FileService.resumeTask(file.taskId);
			}
			//todo请求
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function resumeTask(_x5, _x6) {
		return _ref3.apply(this, arguments);
	};
})();

let downloadUploadFile = exports.downloadUploadFile = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let fileId = ctx.params.fileId;
			let resolvePath = yield FileService.getUploadFilePath(fileId);
			console.log(resolvePath);
			if (!resolvePath || !_fs2.default.existsSync(resolvePath)) throw new _errors2.default.FileNotExists();
			data = yield (0, _download.getToken)(resolvePath);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function downloadUploadFile(_x7, _x8) {
		return _ref4.apply(this, arguments);
	};
})();

/*
	{"columns":["col1","col2","col3","col4"],"mapping":{"col1":"A","col4":"B"}}
	attributesMapping = {
		columnNum:10,
		mapping: {
			1:"user.id",
			2:"user.name"
		}
	}
*/


let create = exports.create = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			ctx.res.connection.setTimeout(_config2.default.apiTimeout);
			let body = ctx.request.body;

			let {
				type
			} = body;
			let file = (0, _lodash.pick)(body, ['dataHubId', 'type', 'objectId', 'updateType', 'encodeType', 'fileName', 'filePath', 'attributesMapping']);
			file.taskStatus = UploadTaskStatus.Uploaded;
			file.taskType = TaskType.Upload;

			let attributesMapping = file.attributesMapping;
			let apiMapping = {
				columns: [],
				mapping: {}
			};
			for (let i = 1; i <= attributesMapping.columnNum; i++) {
				apiMapping.columns.push("col" + i);
			}
			(0, _lodash.each)(attributesMapping.mapping, function (v, k) {
				apiMapping.mapping["col" + k] = v;
			});
			file.attributesMapping = apiMapping;
			file.fileSize = yield FileService.getFileSize(file.filePath);
			if (type == UploadFileType.Log) {
				let fileStorageType = _config2.default.fileStorageType;
				if (!fileStorageType) {
					fileStorageType = "s3";
				}
				file.s3FilePath = FileService.generStoragePath(fileStorageType, file.filePath);
				console.info(file.s3FilePath);
				if (fileStorageType == "s3") {
					yield FileService.saveFileToS3(file.filePath, file.s3FilePath, file.encodeType);
				} else if (fileStorageType == "hdfs") {
					yield FileService.saveFileToHdfs(file.filePath, file.s3FilePath, file.encodeType);
				}
			}
			let taskId = yield FileService.saveFiletoDataApp(file);
			file.taskId = taskId;
			data = yield FileService.create(file);
		} catch (ex) {
			console.info(ex);
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function create(_x9, _x10) {
		return _ref5.apply(this, arguments);
	};
})();

let upload = exports.upload = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let body = ctx.request.body;
			body = Object.assign({}, body.fields, body.files);
			let {
				file,
				encoding
			} = body;
			if (!(0, _helper.isCsvFile)(file.type)) {
				throw new _errors2.default.FileFormatNotSupport();
			}
			if (file.size > _config2.default.maxUploadFileSize) {
				throw new _errors2.default.FileSizeOverFlow();
			}
			let filePath = yield FileService.save(file);
			let lineCount = 10;
			let lines = yield FileService.readLine(filePath, encoding, lineCount);
			data = {
				filePath: filePath,
				size: file.size,
				lines: lines
			};
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function upload(_x11, _x12) {
		return _ref6.apply(this, arguments);
	};
})();

let preview = exports.preview = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let body = ctx.request.body;
			body = Object.assign({}, body.fields, body.files);
			//console.info(body);
			let {
				encoding,
				data: partData,
				type
			} = body;
			if (type == PreviewDataType.File) {
				if (!(0, _helper.isCsvFile)(partData.type)) {
					throw new _errors2.default.FileFormatNotSupport();
				}
			}
			let lineCount = 10;
			if (type == PreviewDataType.FilePath) {
				data = yield FileService.readLine(partData, encoding, 10);
			} else {
				data = yield FileService.readPartData(encoding, partData, type);
			}
		} catch (ex) {
			console.info(ex.stack);
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function preview(_x13, _x14) {
		return _ref7.apply(this, arguments);
	};
})();

var _helper = require('../common/util/helper');

var _fileService = require('./file.service.js');

var FileService = _interopRequireWildcard(_fileService);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _lodash = require('lodash');

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _consts = require('../../config/consts');

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _download = require('../download/download.service');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	PreviewDataType,
	UploadTaskStatus,
	TaskType,
	UploadFileType
} = _consts.Enums;
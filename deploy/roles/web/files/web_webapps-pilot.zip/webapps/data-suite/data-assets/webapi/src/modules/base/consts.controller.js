'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.storageTypeList = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let storageTypeList = exports.storageTypeList = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            let { dataTypeId, storageId } = ctx.request.query;
            let where = {
                status: Status.Normal
            };
            if (storageId) {
                Object.assign(where, { storageId });
            }
            if (dataTypeId) {
                Object.assign(where, { dataTypeId });
            }
            data = yield _models.DataTypeStorageType.findAll({
                where: where
            });
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function storageTypeList(_x, _x2) {
        return _ref.apply(this, arguments);
    };
})();

exports.getEnums = getEnums;
exports.getOptions = getOptions;
exports.getOptionsMap = getOptionsMap;
exports.getValMaps = getValMaps;
exports.getValKeyMaps = getValKeyMaps;
exports.getValNameMaps = getValNameMaps;

var _consts = require('../../config/consts');

var _helper = require('../common/util/helper');

var _models = require('../common/models');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const { Status } = _consts.Enums;

function getEnums(ctx) {
    let data = null;
    let error = null;
    try {
        data = _consts.Enums;
    } catch (ex) {
        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}

function getOptions(ctx, next) {
    let data = null;
    let error = null;
    try {
        data = _consts.Options;
    } catch (ex) {
        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}

function getOptionsMap(ctx, next) {
    let data = null;
    let error = null;
    try {
        data = _consts.OptionMaps;
    } catch (ex) {
        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}

function getValMaps(ctx, next) {
    let data = null;
    let error = null;
    try {
        data = _consts.ValMaps;
    } catch (ex) {
        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}

function getValKeyMaps(ctx, next) {
    let data = null;
    let error = null;
    try {
        data = _consts.ValKeyMaps;
    } catch (ex) {
        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}

function getValNameMaps(ctx, next) {
    let data = null;
    let error = null;
    try {
        data = _consts.ValNameMaps;
    } catch (ex) {
        return ctx.body = (0, _helper.wrapBody)(ex);
    }
    ctx.body = (0, _helper.wrapBody)(error, data);
}
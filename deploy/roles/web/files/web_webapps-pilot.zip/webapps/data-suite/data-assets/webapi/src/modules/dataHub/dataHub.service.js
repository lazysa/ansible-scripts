'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.update = exports.create = exports.pages = exports.allList = exports.listFliterByMapped = exports.list = exports.open = exports.close = exports.query = exports.checkName = exports.checkExists = exports.count = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let count = exports.count = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (condition) {
		condition.status = {
			$ne: Status.Deleted
		};
		return _models.DataHub.count({
			where: condition
		});
	});

	return function count(_x) {
		return _ref.apply(this, arguments);
	};
})();

let checkExists = exports.checkExists = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (dataHubId) {
		return _models.DataHub.count({
			where: {
				id: dataHubId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function checkExists(_x2) {
		return _ref2.apply(this, arguments);
	};
})();

let checkName = exports.checkName = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (name) {
		return _models.DataHub.count({
			where: {
				name: {
					$like: name
				},
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function checkName(_x3) {
		return _ref3.apply(this, arguments);
	};
})();

let query = exports.query = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (dataHubId) {
		return _models.DataHub.findOne({
			where: {
				id: dataHubId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function query(_x4) {
		return _ref4.apply(this, arguments);
	};
})();

let close = exports.close = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (rollerType, dataHubId) {
		yield dataMappingService.close(dataHubId);
		yield dataInterfaceService.closeAll(dataHubId);
		return _models.DataHub.update({
			status: DataHubStatus.Close
		}, {
			where: {
				id: dataHubId,
				rollerType: rollerType,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function close(_x5, _x6) {
		return _ref5.apply(this, arguments);
	};
})();

let open = exports.open = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (rollerType, dataHubId) {
		return _models.DataHub.update({
			status: DataHubStatus.Open
		}, {
			where: {
				id: dataHubId,
				rollerType: rollerType,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function open(_x7, _x8) {
		return _ref6.apply(this, arguments);
	};
})();

let list = exports.list = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* (condition) {
		Object.assign(condition, {
			status: {
				$ne: Status.Deleted
			}
		});
		return _models.DataHub.findAll({
			attributes: ['id', 'name', 'dataOwnerType', 'status'],
			where: condition
		});
	});

	return function list(_x9) {
		return _ref7.apply(this, arguments);
	};
})();

let listFliterByMapped = exports.listFliterByMapped = (() => {
	var _ref8 = (0, _asyncToGenerator3.default)(function* () {
		let data = [];
		let sql = 'select id,name,data_owner_type,status from data_hub where id not in (select data_hub_id from data_mapping where status != :status)';
		let result = yield _models.sequelize.query(sql, {
			replacements: {
				status: Status.Deleted
			},
			type: _models.sequelize.QueryTypes.SELECT
		});
		if (result.length) {
			data = (0, _models.renameKeys)(result);
		}
		return data;
	});

	return function listFliterByMapped() {
		return _ref8.apply(this, arguments);
	};
})();

let allList = exports.allList = (() => {
	var _ref9 = (0, _asyncToGenerator3.default)(function* () {
		return _models.DataHub.findAll({
			attributes: ['id', 'name', 'rollerType', 'dataOwnerType', 'status'],
			where: {
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function allList() {
		return _ref9.apply(this, arguments);
	};
})();

let pages = exports.pages = (() => {
	var _ref10 = (0, _asyncToGenerator3.default)(function* (pageSize, offset, condition) {
		condition.status = {
			$ne: Status.Deleted
		};
		let data = yield _models.DataHub.findAll({
			attributes: ['id', 'name', "dataCategoryId", "dataOwnerType", "status"],
			where: condition,
			limit: pageSize,
			offset: offset,
			order: [['id', 'desc']],
			raw: true
		});
		let dataCategoryIds = _lodash2.default.map(data, "dataCategoryId");
		let dataCategorys = yield _models.DataCategory.findAll({
			attributes: ['id', 'name'],
			where: {
				status: Status.Normal
			},
			raw: true
		});
		let map = (0, _helper.dataToMap)(dataCategorys, "id");
		data.forEach(function (n) {
			if (map[n.dataCategoryId]) {
				n.dataCategoryName = map[n.dataCategoryId].name;
			}
		});
		return data;
	});

	return function pages(_x10, _x11, _x12) {
		return _ref10.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref11 = (0, _asyncToGenerator3.default)(function* (info) {
		return _models.DataHub.create(info);
	});

	return function create(_x13) {
		return _ref11.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref12 = (0, _asyncToGenerator3.default)(function* (dataHubId, info) {
		return _models.DataHub.update(info, {
			where: {
				status: {
					$ne: Status.Deleted
				},
				id: dataHubId
			}
		});
	});

	return function update(_x14, _x15) {
		return _ref12.apply(this, arguments);
	};
})();

var _models = require('../common/models');

var _helper = require('../common/util/helper');

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _dataMappingService = require('../dataMapping/data.mapping.service.js');

var dataMappingService = _interopRequireWildcard(_dataMappingService);

var _dataInterfaceService = require('../dataInterface/data.interface.service.js');

var dataInterfaceService = _interopRequireWildcard(_dataInterfaceService);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Status,
	DataHubStatus
} = _consts.Enums;
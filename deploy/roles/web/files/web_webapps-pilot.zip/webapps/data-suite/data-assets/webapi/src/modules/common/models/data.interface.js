"use strict";

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('DataInterface', {
        id: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            defaultValue: null,
            field: "id"
        },
        name: {
            type: DataTypes.STRING(256),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "name"
        },
        dataHubId: {
            type: DataTypes.INTEGER(11),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "data_hub_id"
        },
        dataInterfaceProcesserId: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "data_interface_processer_id"
        },
        dataInterfaceProcesserConfig: {
            type: DataTypes.STRING(2048),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "data_interface_processer_config",
            get: function () {
                var val = this.getDataValue('dataInterfaceProcesserConfig');
                if (val) {
                    val = JSON.parse(val);
                }
                return val;
            },
            set: function (val) {
                if (val) {
                    val = JSON.stringify(val);
                }
                this.setDataValue("dataInterfaceProcesserConfig", val);
            }
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "created_at"
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "updated_at"
        },
        createUserId: {
            type: DataTypes.INTEGER(10),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "create_userid"
        },
        updateUserId: {
            type: DataTypes.INTEGER(10),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "update_userid"
        },
        status: {
            type: DataTypes.INTEGER(4).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: "status"
        }
    }, {
        tableName: 'data_interface',
        timestamps: true
    });
};
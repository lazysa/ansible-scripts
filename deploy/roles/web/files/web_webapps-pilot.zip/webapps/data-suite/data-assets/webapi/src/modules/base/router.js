'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _consts = require('./consts.controller');

var constsController = _interopRequireWildcard(_consts);

var _metrics = require('./metrics.controller');

var metricsController = _interopRequireWildcard(_metrics);

var _wechat = require('./wechat.controller');

var wechatController = _interopRequireWildcard(_wechat);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)();

//常量
router.get('/consts/enums', constsController.getEnums);
router.get('/consts/options', constsController.getOptions);
router.get('/consts/optionsMaps', constsController.getOptionsMap);
router.get('/consts/vmaps', constsController.getValMaps);
router.get('/consts/vkmaps', constsController.getValKeyMaps);
router.get('/consts/vnmaps', constsController.getValNameMaps);

router.get('/metrics/list', metricsController.list);
router.post('/wechat/baseInfo', wechatController.baseInfo);
router.get('/storagetype/list', constsController.storageTypeList);

exports.default = router;
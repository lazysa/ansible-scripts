"use strict";

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('DataTypeStorageType', {
        id: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            defaultValue: null,
            field: "id"
        },
        dataTypeId: {
            type: DataTypes.INTEGER(10),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "data_type_id"
        },
        storageId: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "storage_id"
        },
        status: {
            type: DataTypes.INTEGER(4).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: "status"
        }
    }, {
        tableName: 'data_type_storage_type',
        timestamps: false
    });
};
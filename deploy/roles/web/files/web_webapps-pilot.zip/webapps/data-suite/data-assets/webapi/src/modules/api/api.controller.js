'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createSysUserIdColumns = exports.sysUserIdColumnsListByTableName = exports.sysUserIdColumns = exports.userIdType = exports.mergeRule = exports.auth = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let auth = exports.auth = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            if (_config2.default.env == "development") {
                return yield next();
            }
            let headers = ctx.request.headers;
            let timestamp = headers.timestamp;
            let randomStr = headers.randomstr;
            let token = headers.token;
            let apiSecret = _config2.default.apiSecret;
            if (!(timestamp && randomStr && timestamp.toString().length >= 10 && randomStr.length >= 10)) {
                throw new _errors2.default.ApiNoRight();
            }
            let hash = ApiService.getHash(timestamp, randomStr, apiSecret);
            if (hash == token) {
                return yield next();
            } else {
                throw new _errors2.default.ApiNoRight();
            }
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function auth(_x, _x2) {
        return _ref.apply(this, arguments);
    };
})();

let mergeRule = exports.mergeRule = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            data = yield ApiService.mergeRule();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function mergeRule(_x3, _x4) {
        return _ref2.apply(this, arguments);
    };
})();

let userIdType = exports.userIdType = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            data = yield ApiService.userIdType();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function userIdType(_x5, _x6) {
        return _ref3.apply(this, arguments);
    };
})();

let sysUserIdColumns = exports.sysUserIdColumns = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            data = yield ApiService.sysUserIdColumns();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function sysUserIdColumns(_x7, _x8) {
        return _ref4.apply(this, arguments);
    };
})();

let sysUserIdColumnsListByTableName = exports.sysUserIdColumnsListByTableName = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            let { tableName } = ctx.params;
            data = yield ApiService.sysUserIdColumns(tableName);
            let userIdTypeList = yield ApiService.userIdType();
            let userIdTypeMap = (0, _lodash.keyBy)(userIdTypeList, 'id');
            data = data.map(function ({ tableName, userIdColumn, userIdType }) {
                let obj = { tableName, userIdColumn, userIdType };
                if (userIdTypeMap[userIdType]) {
                    obj.userIdName = userIdTypeMap[userIdType].userIdTypeDesc;
                }
                return obj;
            });
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function sysUserIdColumnsListByTableName(_x9, _x10) {
        return _ref5.apply(this, arguments);
    };
})();

let createSysUserIdColumns = exports.createSysUserIdColumns = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            data = yield ApiService.createSysUserIdColumns(body);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function createSysUserIdColumns(_x11, _x12) {
        return _ref6.apply(this, arguments);
    };
})();

var _helper = require('../common/util/helper');

var _apiService = require('./api.service.js');

var ApiService = _interopRequireWildcard(_apiService);

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _lodash = require('lodash');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

;
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.readPartData = exports.readLine = exports.save = exports.create = exports.stripFirstLineAndConvert = exports.saveFileToHdfs = exports.saveFileToS3 = exports.saveFiletoAnalyticsApp = exports.saveFiletoLogDataApp = exports.saveFiletoDataApp = exports.queryDictionaryTask = exports.queryLogTask = exports.queryTask = exports.getUploadFilePath = exports.resumeTask = exports.pages = exports.query = exports.list = exports.count = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let count = exports.count = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (condition) {
        condition.status = Status.Normal;
        return _models.UploadFile.count({
            where: condition
        });
    });

    return function count(_x) {
        return _ref.apply(this, arguments);
    };
})();

let list = exports.list = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* () {
        return _models.UploadFile.findAll({
            attributes: ['id', 'fileName'],
            where: {
                status: Status.Normal
            }
        });
    });

    return function list() {
        return _ref2.apply(this, arguments);
    };
})();

let query = exports.query = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (fileId) {
        return _models.UploadFile.findOne({
            where: {
                id: fileId,
                status: Status.Normal
            }
        });
    });

    return function query(_x2) {
        return _ref3.apply(this, arguments);
    };
})();

let pages = exports.pages = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (pageSize, offset, condition) {
        condition.status = Status.Normal;
        let files = yield _models.UploadFile.findAll({
            attributes: ['id', 'type', 'fileName', 'uploadRowCount', 'insertRowCount', 'updateRowCount', 'failedRowCount', 'taskId', 'taskStatus', 'statusMessage', 'createdAt', 'objectId', 'filePath', 'fileSize'],
            where: condition,
            limit: pageSize,
            offset: offset,
            order: [['id', 'desc']],
            raw: true //raw: true 如果是json需要去掉这个设置
        });
        if (files.length) {
            files = yield queryTask(files);
            files = yield convertFileSize(files);
        }
        return files;
    });

    return function pages(_x3, _x4, _x5) {
        return _ref4.apply(this, arguments);
    };
})();

let resumeTask = exports.resumeTask = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (taskId) {
        let url = _config2.default.dataAppBaseUrl + "datafile/upload";
        let data = yield (0, _helper.getData)(url, {
            taskId: taskId
        });
        return data;
    });

    return function resumeTask(_x6) {
        return _ref5.apply(this, arguments);
    };
})();

let getUploadFilePath = exports.getUploadFilePath = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (fileId) {
        let fileRecord = yield query(fileId);
        return fileRecord && _path2.default.join(_config2.default.fileDir, fileRecord.filePath);
    });

    return function getUploadFilePath(_x7) {
        return _ref6.apply(this, arguments);
    };
})();

let queryTask = exports.queryTask = (() => {
    var _ref7 = (0, _asyncToGenerator3.default)(function* (files) {
        yield queryLogTask(files);
        yield queryDictionaryTask(files);
        return files;
    });

    return function queryTask(_x8) {
        return _ref7.apply(this, arguments);
    };
})();

let queryLogTask = exports.queryLogTask = (() => {
    var _ref8 = (0, _asyncToGenerator3.default)(function* (files) {
        let taskIds = [];
        files.forEach(function (file) {
            if (file.type == UploadFileType.Log) {
                taskIds.push(file.taskId);
            }
        });
        if (!taskIds.length) {
            return;
        }
        let url = _config2.default.dataAppBaseUrl + "query/task/status";
        let data = yield (0, _helper.getData)(url, {
            taskIds: taskIds
        });
        let map = (0, _helper.dataToMap)(data, "taskId");
        files.forEach(function (file) {
            let ext = map[file.taskId];
            if (ext) {
                var keyMap = {
                    "errorMsg": "statusMessage",
                    "failedRowCount": "failedRowCount",
                    "insertRowCount": "insertRowCount",
                    "status": "taskStatus",
                    "taskId": "taskId",
                    "updateRowCount": "updateRowCount",
                    "uploadRowCount": "uploadRowCount"
                };
                var subExt = _lodash2.default.pick(ext, ['errorMsg', 'failedRowCount', 'insertRowCount', 'status', 'taskId', 'updateRowCount', 'uploadRowCount']);
                var extData = {};
                _lodash2.default.each(keyMap, function (dk, ek) {
                    extData[dk] = subExt[ek];
                });
                Object.assign(file, extData);
            }
        });
        return files;
    });

    return function queryLogTask(_x9) {
        return _ref8.apply(this, arguments);
    };
})();

let queryDictionaryTask = exports.queryDictionaryTask = (() => {
    var _ref9 = (0, _asyncToGenerator3.default)(function* (files) {
        let taskIds = [];
        files.forEach(function (file) {
            if (file.type == UploadFileType.Dictionary) {
                taskIds.push(file.taskId);
            }
        });
        if (!taskIds.length) {
            return;
        }
        let url = _config2.default.analyticsApiPath + "metaObject/dictionary/task/status";
        let data = yield (0, _helper.getDataFromAnalytics)({
            url: url,
            method: "post",
            body: {
                taskIds: taskIds
            }
        });
        let map = (0, _helper.dataToMap)(data, "id");
        files.forEach(function (file) {
            let ext = map[file.taskId];
            if (ext) {
                var keyMap = {
                    "statusMessage": "statusMessage",
                    "failedRowCount": "failedRowCount",
                    "insertRowCount": "insertRowCount",
                    "taskStatus": "taskStatus",
                    "id": "taskId",
                    "updateRowCount": "updateRowCount",
                    "uploadRowCount": "uploadRowCount"
                };
                var subExt = _lodash2.default.pick(ext, ['statusMessage', 'failedRowCount', 'insertRowCount', 'taskStatus', 'id', 'updateRowCount', 'uploadRowCount']);
                var extData = {};
                _lodash2.default.each(keyMap, function (dk, ek) {
                    extData[dk] = subExt[ek];
                });
                Object.assign(file, extData);
            }
        });
        return files;
    });

    return function queryDictionaryTask(_x10) {
        return _ref9.apply(this, arguments);
    };
})();

let saveFiletoDataApp = exports.saveFiletoDataApp = (() => {
    var _ref10 = (0, _asyncToGenerator3.default)(function* (file) {
        //let file = pick(body, ['dataHubId', 'objectId', 'updateType', 'encodeType', 'fileName', 'filePath', 'attributesMapping']);
        let {
            type
        } = file;
        if (type == UploadFileType.Log) {
            return yield saveFiletoLogDataApp(file);
        } else {
            return yield saveFiletoAnalyticsApp(file);
        }
    });

    return function saveFiletoDataApp(_x11) {
        return _ref10.apply(this, arguments);
    };
})();

let saveFiletoLogDataApp = exports.saveFiletoLogDataApp = (() => {
    var _ref11 = (0, _asyncToGenerator3.default)(function* (file) {
        //let file = pick(body, ['dataHubId', 'objectId', 'updateType', 'encodeType', 'fileName', 'filePath', 'attributesMapping']);
        let url = _config2.default.dataAppBaseUrl + "datafile/upload";
        let data = yield (0, _helper.getData)(url, {
            acid: _config2.default.accountId.toString(),
            srid: file.dataHubId.toString(),
            obj: file.objectId,
            uptype: file.updateType.toString(),
            ectype: EncodingVMap[file.encodeType].encoding,
            s3path: file.s3FilePath,
            filename: file.fileName,
            attrmapping: JSON.stringify(file.attributesMapping)
        });
        return data.task_id;
    });

    return function saveFiletoLogDataApp(_x12) {
        return _ref11.apply(this, arguments);
    };
})();

let saveFiletoAnalyticsApp = exports.saveFiletoAnalyticsApp = (() => {
    var _ref12 = (0, _asyncToGenerator3.default)(function* (file) {
        let url = _config2.default.analyticsApiPath + "metaObject/dictionary/task";
        console.log(url);
        return yield (0, _helper.getDataFromAnalytics)({
            url: url,
            method: "post",
            formData: {
                file: _fsExtra2.default.createReadStream(_path2.default.join(_config2.default.fileDir, file.filePath)),
                dataHubId: file.dataHubId.toString(),
                metaObjectId: file.objectId,
                updateType: file.updateType,
                encoding: file.encodeType,
                fileName: file.fileName,
                fieldMapping: JSON.stringify(file.attributesMapping)
            }
        });
    });

    return function saveFiletoAnalyticsApp(_x13) {
        return _ref12.apply(this, arguments);
    };
})();

/*
 chiefclouds-dataasset-tmp

 upload路径 有变化:
 s3://chiefclouds-data-assets-preparing/datahub_dev/dw_das/custom_upload/2016/08/02/14/20/${guid}/
 例子:
 s3://chiefclouds-data-assets-preparing/datahub_dev/dw_das/custom_upload/2016/08/02/14/20/2193296c-596e-11e6-82c6-645a045d7ff8/filename.csv

 //let res = await s3.putObject(params).promise();
 //let res = await s3.listObjects({"Bucket":"chiefclouds-dataasset-tmp"}).promise();
 let res = await s3.getObject({Bucket:"chiefclouds-dataasset-tmp",Key:"datahub_dev/dw_das/custom_upload/2016/08/11/14/22/074a9ca5-d706-542d-875d-a05ea7cd375d/filename.csv"}).promise();

 { ETag: '"098f6bcd4621d373cade4e832627b4f6"' }

 aws cli

 文档：
 http://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/S3.html#getObject-property
 http://docs.aws.amazon.com/AWSJavaScriptSDK/guide/index.html
 */

let saveFileToS3 = exports.saveFileToS3 = (() => {
    var _ref13 = (0, _asyncToGenerator3.default)(function* (filePath, s3Path, encoding) {
        let tmpFilePath = yield stripFirstLineAndConvert(filePath, s3Path, encoding);
        let urlObj = _url2.default.parse(s3Path);
        let params = {
            Bucket: urlObj.host,
            Key: urlObj.path.substr(1),
            Body: _fsExtra2.default.createReadStream(tmpFilePath)
        };
        let s3Config = _config2.default.s3Config;
        if (_config2.default.env == "development") {
            _awsSdk2.default.config.update(s3Config);
        }
        _awsSdk2.default.config.update({
            region: 'cn-north-1'
        });
        let s3 = new _awsSdk2.default.S3();
        console.time("s3");
        try {
            let res = yield s3.putObject(params).promise();
            return res;
        } catch (ex) {
            throw new _errors2.default.FileSaveToS3Error(ex.message);
        }
        console.timeEnd("s3");
    });

    return function saveFileToS3(_x14, _x15, _x16) {
        return _ref13.apply(this, arguments);
    };
})();

let saveFileToHdfs = exports.saveFileToHdfs = (() => {
    var _ref14 = (0, _asyncToGenerator3.default)(function* (filePath, hdfsPath, encoding) {
        let tmpFilePath = yield stripFirstLineAndConvert(filePath, hdfsPath, encoding);
        let hdfsFileDir = _path2.default.dirname(hdfsPath);
        try {
            yield new Promise(function (resolve, reject) {
                (0, _child_process.exec)(`hdfs dfs -mkdir -p ${hdfsFileDir}  && hdfs dfs -put ${tmpFilePath} ${hdfsPath}`, (error, stdout, stderr) => {
                    if (error) {
                        reject(error);
                    } else {
                        if (stderr) {
                            reject(stderr);
                        } else {
                            resolve(stdout);
                        }
                    }
                });
            });
        } catch (ex) {
            throw new _errors2.default.FileSaveToHdfsError(ex.message);
        }
    });

    return function saveFileToHdfs(_x17, _x18, _x19) {
        return _ref14.apply(this, arguments);
    };
})();

let stripFirstLineAndConvert = exports.stripFirstLineAndConvert = (() => {
    var _ref15 = (0, _asyncToGenerator3.default)(function* (filePath, s3Path, encoding) {
        filePath = _path2.default.join(_config2.default.fileDir, filePath);
        let tmpFilePath = _path2.default.join(_config2.default.uploadDir, _path2.default.basename(filePath) + ".tmp");
        //去除首行
        yield new Promise(function (resolve, reject) {
            try {
                let st = _fsExtra2.default.createReadStream(filePath);
                let wt = _fsExtra2.default.createWriteStream(tmpFilePath);
                let skip = false;
                let data = [];
                st.on("data", function (thunk) {
                    if (!skip) {
                        let i = 0;
                        while (i < thunk.length) {
                            i++;
                            if (thunk[i] == 10 || thunk[i] == 13) {
                                if (thunk[i + 1] == 10) {
                                    data.push(thunk.slice(i + 2));
                                    skip = true;
                                    break;
                                } else {
                                    data.push(thunk.slice(i + 1));
                                    skip = true;
                                    break;
                                }
                            }
                        }
                    } else {
                        data.push(thunk);
                    }
                });
                st.on("close", function () {
                    data = Buffer.concat(data);
                    if (encoding != Encoding.Utf8) {
                        encoding = EncodingVMap[encoding].encoding;
                        data = _iconvLite2.default.decode(data, encoding);
                    }
                    wt.write(data);
                    wt.end();
                    resolve(true);
                });
                st.on("error", function (err) {
                    reject(err);
                });
            } catch (ex) {
                reject(ex);
            }
        });
        return tmpFilePath;
    });

    return function stripFirstLineAndConvert(_x20, _x21, _x22) {
        return _ref15.apply(this, arguments);
    };
})();

let create = exports.create = (() => {
    var _ref16 = (0, _asyncToGenerator3.default)(function* (file) {
        return _models.UploadFile.create(file);
    });

    return function create(_x23) {
        return _ref16.apply(this, arguments);
    };
})();

let save = exports.save = (() => {
    var _ref17 = (0, _asyncToGenerator3.default)(function* (file) {
        let sourceFilePath = file.path;
        let fileName = chance.guid() + ".csv";
        let filePath = (0, _moment2.default)().format("YYYY-MM-DD");
        filePath = _path2.default.join(filePath, fileName);
        let savePath = _path2.default.join(_config2.default.fileDir, filePath);
        _fsExtra2.default.ensureDirSync(_path2.default.dirname(savePath));
        yield _bluebird2.default.fromCallback(function (callback) {
            _fsExtra2.default.move(sourceFilePath, savePath, callback);
        });
        return filePath;
    });

    return function save(_x24) {
        return _ref17.apply(this, arguments);
    };
})();

let readLine = exports.readLine = (() => {
    var _ref18 = (0, _asyncToGenerator3.default)(function* (filePath, encoding, lineCount) {
        filePath = _path2.default.join(_config2.default.fileDir, filePath);
        let lines = yield _bluebird2.default.fromCallback(function (callback) {
            let data = [];
            let strLen = 0;
            let st = _fsExtra2.default.createReadStream(filePath);
            st.on("data", function (thunk) {
                strLen += thunk.length;
                data.push(thunk);
                if (strLen > 1024 * 10) {
                    st.close();
                }
            });
            st.on("close", function () {
                data = Buffer.concat(data);
                if (encoding != Encoding.Utf8) {
                    encoding = EncodingVMap[encoding].encoding;
                    data = _iconvLite2.default.decode(data, encoding);
                } else {
                    data = data.toString("utf-8");
                }
                callback(null, data.split(/[\r\n]+/).slice(0, 11));
            });
        }).timeout(2000);
        return lines;
    });

    return function readLine(_x25, _x26, _x27) {
        return _ref18.apply(this, arguments);
    };
})();

let readPartData = exports.readPartData = (() => {
    var _ref19 = (0, _asyncToGenerator3.default)(function* (encoding, partData, type) {
        let data;
        encoding = parseInt(encoding);
        if (type == PreviewDataType.Base64) {
            data = new Buffer(partData, "base64");
        } else if (type == PreviewDataType.File) {
            data = _fsExtra2.default.readFileSync(partData.path);
            _fsExtra2.default.removeSync(partData.path);
        }
        if (encoding != Encoding.Utf8) {
            data = _iconvLite2.default.decode(data, EncodingVMap[encoding].encoding);
        } else {
            data = data.toString("utf-8");
        }
        let lines = data.split(/[\r\n]+/);
        return lines;
    });

    return function readPartData(_x28, _x29, _x30) {
        return _ref19.apply(this, arguments);
    };
})();

exports.convertFileSize = convertFileSize;
exports.getFileSize = getFileSize;
exports.generStoragePath = generStoragePath;

var _models = require('../common/models');

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _helper = require('../common/util/helper');

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _chance = require('chance');

var _chance2 = _interopRequireDefault(_chance);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _awsSdk = require('aws-sdk');

var _awsSdk2 = _interopRequireDefault(_awsSdk);

var _url = require('url');

var _url2 = _interopRequireDefault(_url);

var _child_process = require('child_process');

var _filesize = require('filesize');

var _filesize2 = _interopRequireDefault(_filesize);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
    Status,
    Encoding,
    PreviewDataType,
    UploadFileType
} = _consts.Enums;
let {
    EncodingVMap
} = _consts.ValMaps;
let chance = new _chance2.default();

_awsSdk2.default.config.setPromisesDependency(_bluebird2.default);

function convertFileSize(files) {
    return files.map(file => {
        console.log(file);
        if (!file.fileSize) return file;
        return Object.assign(file, { fileSizeObject: (0, _filesize2.default)(file.fileSize, { output: "object" }) });
    });
}
function getFileSize(filePath) {
    return new Promise((resolve, reject) => {
        let resolveFilePath = _path2.default.join(_config2.default.fileDir, filePath);
        if (!_fsExtra2.default.existsSync(resolveFilePath)) reject();
        _fsExtra2.default.stat(resolveFilePath, (err, stats) => {
            if (err || !stats) reject(err);
            resolve(stats && stats.size);
        });
    });
}

function generStoragePath(fileStorageType, filePath) {
    if (fileStorageType == "s3") {
        return _config2.default.s3PathPrefix + 'datahub_dev/dw_das/custom_upload/' + (0, _moment2.default)().format("YYYY/MM/DD/HH/mm/") + chance.guid() + '/' + _path2.default.basename(filePath);
    } else if (fileStorageType == "hdfs") {
        return _config2.default.hdfsPathPrefix + 'datahub_dev/dw_das/custom_upload/' + (0, _moment2.default)().format("YYYY/MM/DD/HH/mm/") + chance.guid() + '/' + _path2.default.basename(filePath);
    }
}
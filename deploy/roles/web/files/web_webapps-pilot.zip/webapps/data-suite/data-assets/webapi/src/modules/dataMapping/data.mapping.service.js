'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.close = exports.open = exports.remove = exports.update = exports.create = exports.syncAllDataToMappingServer = exports.syncDataToMappingServer = exports.query = exports.pages = exports.count = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let count = exports.count = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (keyword) {
		let condition = {
			status: {
				$ne: Status.Deleted
			}
		};
		let filterDataHubIds;
		if (keyword) {
			//搜索datahub
			let filterDataHubs = yield _models.DataHub.findAll({
				attributes: ['id'],
				where: {
					status: {
						$ne: Status.Deleted
					},
					$or: [{
						id: {
							$like: '%' + keyword + '%'
						}
					}, {
						name: {
							$like: '%' + keyword + '%'
						}
					}]
				}
			});
			if (filterDataHubs.length) {
				filterDataHubIds = (0, _lodash.map)(filterDataHubs, 'id');
				condition.dataHubId = {
					$in: filterDataHubIds
				};
			}
		}
		return _models.DataMapping.count({
			where: condition
		});
	});

	return function count(_x) {
		return _ref.apply(this, arguments);
	};
})();

let pages = exports.pages = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (pageSize, offset, keyword) {
		let data = [];
		let filterDataHubIds;
		if (keyword) {
			let filterDataHubs = yield _models.DataHub.findAll({
				attributes: ['id'],
				where: {
					status: {
						$ne: Status.Deleted
					},
					$or: [{
						id: {
							$like: '%' + keyword + '%'
						}
					}, {
						name: {
							$like: '%' + keyword + '%'
						}
					}]
				}
			});
			if (filterDataHubs.length) {
				filterDataHubIds = (0, _lodash.map)(filterDataHubs, 'id');
			}
		}
		let sql = 'select data_mapping.*, data_hub.name as dataHubName, data_hub.status as dataHubStatus from data_mapping left join data_hub on data_mapping.data_hub_id = data_hub.id where data_mapping.status!=:status limit :offset,:pageSize';
		if (filterDataHubIds && filterDataHubIds.length) {
			sql = 'select data_mapping.*, data_hub.name as dataHubName, data_hub.status as dataHubStatus from data_mapping left join data_hub on data_mapping.data_hub_id = data_hub.id where data_mapping.status!=:status and data_hub.id in (:dataHubIds) limit :offset,:pageSize';
		}
		let result = yield _models.sequelize.query(sql, {
			replacements: {
				status: Status.Deleted,
				offset: offset,
				pageSize: pageSize,
				dataHubIds: filterDataHubIds
			},
			type: _models.sequelize.QueryTypes.SELECT
		});
		if (result.length) {
			data = (0, _models.renameKeys)(result);
		}
		return data;
	});

	return function pages(_x2, _x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

let query = exports.query = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (dataHubId) {
		let data = null;
		let result = yield _models.sequelize.query('select data_mapping.*, data_hub.name as dataHubName from data_mapping left join data_hub on data_mapping.data_hub_id = data_hub.id where data_mapping.data_hub_id=:dataHubId', {
			replacements: {
				dataHubId: dataHubId
			},
			type: _models.sequelize.QueryTypes.SELECT
		});
		if (result.length) {
			data = (0, _models.renameKeys)(result[0]);
		}
		return data;
	});

	return function query(_x5) {
		return _ref3.apply(this, arguments);
	};
})();

let retryRequest = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (url, body, config) {
		let queue = {
			retry: 0,
			max: 3,
			job: (() => {
				var _ref5 = (0, _asyncToGenerator3.default)(function* () {
					try {
						yield (0, _helper.getData)(url, body, config);
					} catch (ex) {
						_log.log.error({
							type: "syncToMappingServer",
							err: ex
						});
						this.retry++;
						if (this.retry < this.max) {
							yield this.job();
						}
					}
				});

				return function job() {
					return _ref5.apply(this, arguments);
				};
			})()
		};
		yield queue.job();
	});

	return function retryRequest(_x6, _x7, _x8) {
		return _ref4.apply(this, arguments);
	};
})();

//同步一批数据


let syncDataToMappingServer = exports.syncDataToMappingServer = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (list) {
		let accountId = _config2.default.accountId;
		let body = [];
		let url = _config2.default.mappingServerBaseUrl + "set/config";
		list.forEach(function (n) {
			let item = {
				'is_open': n.status == DataMappingStatus.Open ? 1 : 0,
				'account_id': accountId,
				'partner_id': n.dataHubId.toString(),
				'is_our': n.sendingType == DataMappingSendingType.Own ? 1 : 0,
				'dual_way_mapping': n.isTwoWay.toString(),
				'start_to_end': [Math.floor(n.startTime.getTime() / 1000), Math.floor(n.endTime.getTime() / 1000)].join('-'),
				'sort': n.priority.toString()
			};
			if (n.sendingType == DataMappingSendingType.Own) {
				//我方发起
				item['mapping_redirect_url'] = n.partnerUrl != null ? n.partnerUrl : "";
			} else {
				//对方发起双向
				if (n.isTwoWay) {
					item['dual_way_mapping_url'] = n.partnerUrl != null ? n.partnerUrl : "";
				}
			}
			if (n.salt) {
				item.salt = n.salt;
			}
			if (n.encryptType && (0, _lodash.get)(EncryptTypeVMap, [n.encryptType, "type"].join("."))) {
				item.encrypt_type = EncryptTypeVMap[n.encryptType].type;
			}
			if (n.remappingPeriod) {
				item.mapping_cycle = n.remappingPeriod.toString();
			}
			//console.info(item);
			body.push(item);
		});
		yield retryRequest(url, body);
	});

	return function syncDataToMappingServer(_x9) {
		return _ref6.apply(this, arguments);
	};
})();

//同步所有数据


let syncAllDataToMappingServer = exports.syncAllDataToMappingServer = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* () {
		let list = yield _models.DataMapping.findAll({
			where: {
				status: {
					$ne: Status.Deleted
				}
			},
			raw: true
		});
		yield syncDataToMappingServer(list);
	});

	return function syncAllDataToMappingServer() {
		return _ref7.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref8 = (0, _asyncToGenerator3.default)(function* (info) {
		let dataMapping = yield _models.DataMapping.create(info);
		yield syncDataToMappingServer([dataMapping.get({
			plain: true
		})]);
	});

	return function create(_x10) {
		return _ref8.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref9 = (0, _asyncToGenerator3.default)(function* (dataHubId, info) {
		let exists = yield _models.DataMapping.count({
			where: {
				dataHubId: dataHubId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
		if (exists) {
			yield _models.DataMapping.update(info, {
				where: {
					dataHubId: dataHubId
				}
			});
		} else {
			yield _models.DataMapping.create(info);
		}
		let lastInfo = yield query(dataHubId);
		yield syncDataToMappingServer([lastInfo]);
	});

	return function update(_x11, _x12) {
		return _ref9.apply(this, arguments);
	};
})();

let remove = exports.remove = (() => {
	var _ref10 = (0, _asyncToGenerator3.default)(function* (dataHubId) {
		let exists = yield _models.DataMapping.count({
			where: {
				dataHubId: dataHubId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
		if (exists) {
			let info = yield query(dataHubId);
			yield _models.DataMapping.update({
				status: Status.Deleted
			}, {
				where: {
					dataHubId: dataHubId,
					status: {
						$ne: Status.Deleted
					}
				}
			});
			info.status = DataMappingStatus.Close;
			yield syncDataToMappingServer([info]);
		}
	});

	return function remove(_x13) {
		return _ref10.apply(this, arguments);
	};
})();

let open = exports.open = (() => {
	var _ref11 = (0, _asyncToGenerator3.default)(function* (dataHubId) {
		let exists = yield _models.DataMapping.count({
			where: {
				dataHubId: dataHubId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
		if (exists) {
			let info = yield query(dataHubId);
			yield _models.DataMapping.update({
				status: DataMappingStatus.Open
			}, {
				where: {
					dataHubId: dataHubId,
					status: {
						$ne: Status.Deleted
					}
				}
			});
			info.status = DataMappingStatus.Open;
			yield syncDataToMappingServer([info]);
		}
	});

	return function open(_x14) {
		return _ref11.apply(this, arguments);
	};
})();

let close = exports.close = (() => {
	var _ref12 = (0, _asyncToGenerator3.default)(function* (dataHubId) {
		let exists = yield _models.DataMapping.count({
			where: {
				dataHubId: dataHubId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
		if (exists) {
			let info = yield query(dataHubId);
			yield _models.DataMapping.update({
				status: DataMappingStatus.Close
			}, {
				where: {
					dataHubId: dataHubId,
					status: {
						$ne: Status.Deleted
					}
				}
			});
			info.status = DataMappingStatus.Close;
			yield syncDataToMappingServer([info]);
		}
	});

	return function close(_x15) {
		return _ref12.apply(this, arguments);
	};
})();

exports.formatStr = formatStr;

var _models = require('../common/models');

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _request = require('request');

var _request2 = _interopRequireDefault(_request);

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _helper = require('../common/util/helper');

var _log = require('../common/core/log');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Status,
	DataMappingStatus,
	DataMappingSendingType
} = _consts.Enums;
let {
	EncryptTypeVMap
} = _consts.ValMaps;
function formatStr(str, data) {
	return str.replace(/#([^#]+)#/g, function (m0, m1) {
		if (data[m1] != undefined) {
			return data[m1];
		} else {
			return m0;
		}
	});
}
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.getDailyPath = exports.getFilePath = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let getFilePath = exports.getFilePath = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (fileCategory, fileName) {
		fileName = chance.hash() + _path2.default.extname(fileName);
		let dailyPath = yield getDailyPath(fileCategory);
		let filePath = _path2.default.join(dailyPath, fileName);
		return filePath;
	});

	return function getFilePath(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let getDailyPath = exports.getDailyPath = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (fileCategory) {
		let currentDay = (0, _moment2.default)().format("YYYY-MM-DD");
		let dailyPath = _path2.default.join(fileDir, fileCategory, currentDay);
		yield fs.ensureDirAsync(dailyPath);
		return dailyPath;
	});

	return function getDailyPath(_x3) {
		return _ref2.apply(this, arguments);
	};
})();

exports.generTmpFilePath = generTmpFilePath;
exports.generTmpFileWriteStream = generTmpFileWriteStream;

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _bluebird = require('bluebird');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _chance = require('chance');

var _chance2 = _interopRequireDefault(_chance);

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const fs = (0, _bluebird.promisifyAll)(_fsExtra2.default);
const chance = new _chance2.default();
const {
	uploadDir: tempDir,
	fileDir
} = _config2.default;

function generTmpFilePath(ext) {
	let filePath = _path2.default.join(tempDir, chance.hash());
	if (ext) {
		filePath += ext;
	}
	return filePath;
}

function generTmpFileWriteStream(ext) {
	let filePath = _path2.default.join(tempDir, chance.hash());
	if (ext) {
		filePath += ext;
	}
	return fs.createWriteStream(filePath);
}
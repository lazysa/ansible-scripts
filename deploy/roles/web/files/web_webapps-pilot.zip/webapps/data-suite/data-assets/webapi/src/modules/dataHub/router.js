'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _dataHub = require('./dataHub.controller');

var controller = _interopRequireWildcard(_dataHub);

var _dataHub2 = require('./dataHub.filter');

var filter = _interopRequireWildcard(_dataHub2);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
	prefix: "/dataHub"
});

router.get('/:rollerType/list/', filter.list, controller.list);

router.get('/listFliterByMapped', controller.listFliterByMapped);

router.get('/list', controller.allList);

router.get('/:rollerType/pages', filter.pages, controller.pages);

router.get('/:rollerType/:dataHubId', controller.query);

router.get('/:rollerType/:dataHubId/close', controller.close);

router.get('/:rollerType/:dataHubId/open', controller.open);

router.post('/:rollerType/', filter.create, controller.create);

router.put('/:rollerType/:dataHubId', filter.update, controller.update);

exports.default = router;
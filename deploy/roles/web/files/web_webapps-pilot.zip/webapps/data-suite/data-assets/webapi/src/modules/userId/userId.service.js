'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.list = exports.count = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let count = exports.count = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (condition = {}) {
		condition.status = Status.Normal;
		return _models.UserIdType.count({
			where: condition
		});
	});

	return function count() {
		return _ref.apply(this, arguments);
	};
})();

let list = exports.list = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (condition = {}) {
		condition.status = Status.Normal;
		condition.user_id_type_name = {
			$notIn: ['segment_flag']
		};
		return _models.UserIdType.findAll({
			attributes: ['id', ['user_id_type_desc', 'name']],
			where: condition,
			raw: true
		});
	});

	return function list() {
		return _ref2.apply(this, arguments);
	};
})();

var _models = require('../common/models');

var _consts = require('../../config/consts');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Status
} = _consts.Enums;
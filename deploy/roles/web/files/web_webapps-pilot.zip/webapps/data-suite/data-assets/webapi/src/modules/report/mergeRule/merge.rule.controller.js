'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.download = exports.idCountDistribution = exports.associationRatio = exports.idDistribution = exports.trend = exports.overview = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let overview = exports.overview = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				mergeRuleId
			} = ctx.request.body;
			data = yield MergeRuleService.overview(mergeRuleId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function overview(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let trend = exports.trend = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				mergeRuleId,
				metric
			} = ctx.request.body;
			let {
				trendType
			} = ctx.params;
			data = yield MergeRuleService.trend(trendType, mergeRuleId, metric);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function trend(_x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

let idDistribution = exports.idDistribution = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				mergeRuleId,
				metric
			} = ctx.request.body;
			data = yield MergeRuleService.idDistribution(mergeRuleId, metric);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function idDistribution(_x5, _x6) {
		return _ref3.apply(this, arguments);
	};
})();

let associationRatio = exports.associationRatio = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				mergeRuleId,
				contrastUserIdType
			} = ctx.request.body;
			data = yield MergeRuleService.associationRatio(mergeRuleId, contrastUserIdType);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function associationRatio(_x7, _x8) {
		return _ref4.apply(this, arguments);
	};
})();

let idCountDistribution = exports.idCountDistribution = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				mergeRuleId
			} = ctx.request.body;
			data = yield MergeRuleService.idCountDistribution(mergeRuleId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function idCountDistribution(_x9, _x10) {
		return _ref5.apply(this, arguments);
	};
})();

let download = exports.download = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				mergeRuleId
			} = ctx.request.body;
			data = yield MergeRuleService.download(mergeRuleId);
		} catch (ex) {
			console.info(ex);
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function download(_x11, _x12) {
		return _ref6.apply(this, arguments);
	};
})();

var _helper = require('../../common/util/helper');

var _mergeRule = require('./merge.rule.service');

var MergeRuleService = _interopRequireWildcard(_mergeRule);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
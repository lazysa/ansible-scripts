'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _path = require('path');

var _filesizeParser = require('filesize-parser');

var _filesizeParser2 = _interopRequireDefault(_filesizeParser);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let config = {
	env: 'production',
	accountId: 'pilot',
	port: 9041,
	mysql: {
		host: 'reportprod.crolin6odw7u.rds.cn-north-1.amazonaws.com.cn',
		poolSize: 5,
		user: 'root',
		password: 'kztt9tMkljkx',
		database: 'data_assets',
		logging: false
	},
	sessionKey: "usid",
	logDir: '/mnt/logs/data-assets/webapi',
	logLevel: "error",
	uploadDir: '/mnt/tmp',
	fileDir: '/mnt/webapps/files/data-assets',
	maxUploadFileSize: (0, _filesizeParser2.default)("200M"),
	rollerTypeMap: {
		"provider": 1,
		"receiver": 2
	},
	dataAppBaseUrl: "http://datapi.chiefclouds.com/v1/private/",
	apiTimeout: 60000,
	poolSize: 5, //
	fileStorageType: "hdfs", //s3 hdfs
	s3PathPrefix: 's3://datahub-prod-etl-dataset-stg/data_asset/tmp/',
	hdfsPathPrefix: '/tmp/tgt_folder/',
	maxRetryCount: 3, //文件任务重试次数
	mappingUrl: {
		launchUrl: "http://cmapping.chiefclouds.cn:8081/cm.fcg?cc_acid=#accountId#&cc_pid=#dataHubId#",
		singleReceiverUrl: "http://cmapping.chiefclouds.cn:8081/cgi?cc_p_open_id={CC_P_OPEN_ID}&cc_pid=#dataHubId#&cc_acid=#accountId#&cc_domain={CC_DOMAIN}",
		mappingReceiverUrl: "http://cmapping.chiefclouds.cn:8081/rci?cc_pid=#dataHubId#&cc_open_id={CC_OPEN_ID}&cc_p_open_id={CC_P_OPEN_ID}&cc_acid=#accountId#"
	},
	mappingServerBaseUrl: "http://web-dev.chiefclouds.com:8083/",
	whitePaths: ["/consts/optionMaps", "/api/v1/business"],
	authAPiPath: "http://localhost:9031/",
	analyticsApiPath: "http://localhost:9101/",
	authAppId: "ac12227d53bcfcc8efb4ff33333e339e",
	apiSecret: "hx4zg1pli8b2aboqi79zfr",
	reportMetaBaseUrl: "http://10.46.21.67:8082/v1/dataservice/ba",
	reportAppBaseUrl: "http://web-test.chiefclouds.com:9010/api/report/v1"
};

exports.default = config;
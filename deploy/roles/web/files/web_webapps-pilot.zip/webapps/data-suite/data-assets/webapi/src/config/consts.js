'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.ValNameMaps = exports.ValKeyMaps = exports.ValMaps = exports.OptionMaps = exports.Options = exports.Enums = undefined;

var _consts = require('./consts.conf');

var _consts2 = _interopRequireDefault(_consts);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let Enums = {};
let Options = {};
let OptionMaps = {};
let ValMaps = {};
let ValKeyMaps = {};
let ValNameMaps = {};


function flat(data) {
	let key = 'id';
	let dist = {};
	for (let i = 0, item; i < data.length; i++) {
		item = data[i];
		dist[item[key]] = item.value;
	}
	return dist;
}

function flatKey(data) {
	let key = 'id';
	let dist = {};
	for (let i = 0, item; i < data.length; i++) {
		item = data[i];
		dist[item[key]] = item;
	}
	return dist;
}

function flatVKey(data) {
	let key = 'value';
	let dist = {};
	for (let i = 0, item; i < data.length; i++) {
		item = data[i];
		dist[item[key]] = item;
	}
	return dist;
}

function keyValMap(data) {
	let key = 'id';
	let map = {};
	for (let i = 0, item; i < data.length; i++) {
		item = data[i];
		map[item[key]] = item.value;
	}
	return map;
}

function valKeyMap(data) {
	let key = 'id';
	let map = {};
	for (let i = 0, item; i < data.length; i++) {
		item = data[i];
		map[item.value] = item[key];
	}
	return map;
}

function valNameMap(data) {
	let key = 'id';
	let map = {};
	for (let i = 0, item; i < data.length; i++) {
		item = data[i];
		map[item.value] = item.name;
	}
	return map;
}

function add(name, item) {
	let key = 'id';
	Enums[name] = flat(item);
	Options[name + "Option"] = item;
	OptionMaps[name + "Map"] = flatKey(item);
	ValMaps[name + "VMap"] = flatVKey(item);
	ValKeyMaps[name + "VKMap"] = valKeyMap(item, key);
	ValNameMaps[name + "VNMap"] = valNameMap(item, key);
}

for (let k in _consts2.default) {
	add(k, _consts2.default[k]);
}

exports.Enums = Enums;
exports.Options = Options;
exports.OptionMaps = OptionMaps;
exports.ValMaps = ValMaps;
exports.ValKeyMaps = ValKeyMaps;
exports.ValNameMaps = ValNameMaps;
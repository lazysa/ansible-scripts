'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.gennerFile = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let gennerFile = exports.gennerFile = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (list) {
		let borderStyle = {
			top: {
				style: 'thin'
			},
			left: {
				style: 'thin'
			},
			bottom: {
				style: 'thin'
			},
			right: {
				style: 'thin'
			}
		};
		let workbook = new _exceljs2.default.Workbook();
		(0, _lodash.each)(list, function (data, key) {
			let config = _book2.default[key];
			let sheetName = config.name;
			let fields = config.fields;
			let fieldsMap = (0, _helper.dataToMap)(fields, "id");
			data.forEach(function (row) {
				(0, _lodash.each)(row, function (value, field) {
					let valueType = (0, _lodash.get)(fieldsMap, field + ".valueType");
					if (valueType) {
						let vtype = valueTypeMap[valueType];
						if (vtype && (vtype == "number" || vtype == "decimal" || vtype == "percent")) {
							row[field] = value * 1;
						}
					}
				});
			});
			let worksheet = workbook.addWorksheet(sheetName);
			worksheet.columns = fields.map(function (field) {
				let columnWidth = field.name.length * 2.5 + 2;
				if (columnWidth < 15) {
					columnWidth = 15;
				}
				let item = {
					header: field.name,
					key: field.id,
					width: columnWidth
				};
				let numFmt = getNumFmt(field.valueType);
				if (numFmt) {
					item.style = {
						numFmt: numFmt
					};
				}
				return item;
			});
			worksheet.addRows(data);
			worksheet.getRow(1).eachCell(function (cell) {
				cell.font = {
					size: 12,
					bold: true,
					family: 2,
					name: 'Regular Bold'
				};
				cell.fill = {
					type: 'pattern',
					pattern: 'solid',
					fgColor: {
						argb: 'FFE7E6E6'
					}
				};
				cell.alignment = {
					vertical: 'middle',
					horizontal: 'center'
				};
				cell.border = borderStyle;
			});
			worksheet.columns.forEach(function (n, i) {
				worksheet.getColumn(i + 1).eachCell({
					includeEmpty: true
				}, function (cell, rowNumber) {
					if (rowNumber != 1) {
						cell.font = {
							size: 12
						};
						cell.border = borderStyle;
					}
				});
			});
		});
		let filePath = (0, _file.generTmpFilePath)(".xlsx");
		yield workbook.xlsx.writeFile(filePath);
		return filePath;
	});

	return function gennerFile(_x) {
		return _ref.apply(this, arguments);
	};
})();

var _file = require('../../common/util/file');

var _helper = require('../../common/util/helper');

var _book = require('./book.config');

var _book2 = _interopRequireDefault(_book);

var _exceljs = require('exceljs');

var _exceljs2 = _interopRequireDefault(_exceljs);

var _lodash = require('lodash');

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const valueTypeMap = {
	"1": "number",
	"2": "decimal",
	"3": "string",
	"4": "date",
	"5": "percent"
};

function getNumFmt(valueType) {
	let fmt = null;
	let vtype = valueTypeMap[valueType];
	if (vtype == "percent") {
		fmt = "0.00%";
	} else if (vtype == "number") {
		fmt = "#,##0";
	} else if (vtype == "decimal") {
		fmt = "#,##0.00";
	} else if (vtype == "date") {
		//workColumn.numFmt = "YYYY-MM-DD HH:mm:ss";
	} else if (vtype == "time") {
		fmt = "[hh]:mm:ss";
	}
	return fmt;
}
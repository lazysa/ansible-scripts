'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.list = exports.count = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let count = exports.count = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (condition) {
		condition.status = Status.Normal;
		return _models.DataCategory.count({
			where: condition
		});
	});

	return function count(_x) {
		return _ref.apply(this, arguments);
	};
})();

let list = exports.list = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (rollerType) {
		return _models.DataCategory.findAll({
			attributes: ['id', 'name'],
			where: {
				rollerType: rollerType,
				status: Status.Normal
			}
		});
	});

	return function list(_x2) {
		return _ref2.apply(this, arguments);
	};
})();

var _models = require('../common/models');

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Status
} = _consts.Enums;
"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.create = exports.pages = undefined;

var _joi = require("joi");

var _joi2 = _interopRequireDefault(_joi);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let pages = exports.pages = _joi2.default.object().keys({
	pageIndex: _joi2.default.number().integer().min(1).required(),
	pageSize: _joi2.default.number().integer().min(5).max(100).required(),
	keyword: _joi2.default.string().min(1).max(30).allow("", null)
});

let create = exports.create = _joi2.default.object().keys({
	"rollerType": _joi2.default.number().integer().required(),
	"name": _joi2.default.string().max(256).required(),
	"category": _joi2.default.number().integer().required(),
	"dataOwnerType": _joi2.default.number().integer().required()
});
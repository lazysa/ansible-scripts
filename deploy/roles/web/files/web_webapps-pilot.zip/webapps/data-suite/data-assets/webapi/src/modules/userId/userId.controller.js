'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.list = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let list = exports.list = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			data = yield UserIdService.list();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function list(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

var _helper = require('../common/util/helper');

var _userIdService = require('./userId.service.js');

var UserIdService = _interopRequireWildcard(_userIdService);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.open = exports.closeAll = exports.close = exports.query = exports.update = exports.create = exports.pages = exports.list = exports.count = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let count = exports.count = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (condition) {
		condition.status = {
			$ne: Status.Deleted
		};
		return _models.DataInterface.count({
			where: condition
		});
	});

	return function count(_x) {
		return _ref.apply(this, arguments);
	};
})();

let list = exports.list = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (dataHubId) {
		return _models.DataInterface.findAll({
			attributes: ['id', 'name'],
			where: {
				dataHubId: dataHubId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function list(_x2) {
		return _ref2.apply(this, arguments);
	};
})();

let pages = exports.pages = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (pageSize, offset, condition) {
		condition.status = {
			$ne: Status.Deleted
		};
		let data = yield _models.DataInterface.findAll({
			attributes: ['id', 'name', 'dataInterfaceProcesserId', "status"],
			where: condition,
			limit: pageSize,
			offset: offset,
			order: [['id', 'desc']],
			raw: true
		});
		let Ids = _lodash2.default.map(data, "dataInterfaceProcesserId");
		let procesers = yield _models.DataInterfaceProcesser.findAll({
			attributes: ['id', 'name'],
			where: {
				status: Status.Normal
			},
			raw: true
		});
		let map = (0, _helper.dataToMap)(procesers, "id");
		data.forEach(function (n) {
			if (map[n.dataInterfaceProcesserId]) {
				n.dataInterfaceProcesserName = map[n.dataInterfaceProcesserId].name;
			}
		});
		return data;
	});

	return function pages(_x3, _x4, _x5) {
		return _ref3.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (info) {
		return _models.DataInterface.create(info);
	});

	return function create(_x6) {
		return _ref4.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (dataInterfaceId, info) {
		return _models.DataInterface.update(info, {
			where: {
				id: dataInterfaceId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function update(_x7, _x8) {
		return _ref5.apply(this, arguments);
	};
})();

let query = exports.query = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (dataHubId, dataInterfaceId) {
		return _models.DataInterface.findOne({
			where: {
				id: dataInterfaceId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function query(_x9, _x10) {
		return _ref6.apply(this, arguments);
	};
})();

let close = exports.close = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* (dataInterfaceId) {
		return _models.DataInterface.update({
			status: DataInterfaceStatus.Close
		}, {
			where: {
				id: dataInterfaceId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function close(_x11) {
		return _ref7.apply(this, arguments);
	};
})();

let closeAll = exports.closeAll = (() => {
	var _ref8 = (0, _asyncToGenerator3.default)(function* (dataHubId) {
		return _models.DataInterface.update({
			status: DataInterfaceStatus.Close
		}, {
			where: {
				dataHubId: dataHubId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function closeAll(_x12) {
		return _ref8.apply(this, arguments);
	};
})();

let open = exports.open = (() => {
	var _ref9 = (0, _asyncToGenerator3.default)(function* (dataInterfaceId) {
		return _models.DataInterface.update({
			status: DataInterfaceStatus.Open
		}, {
			where: {
				id: dataInterfaceId,
				status: {
					$ne: Status.Deleted
				}
			}
		});
	});

	return function open(_x13) {
		return _ref9.apply(this, arguments);
	};
})();

var _models = require('../common/models');

var _helper = require('../common/util/helper');

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	DataInterfaceStatus,
	Status
} = _consts.Enums;
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.preview = exports.upload = exports.create = exports.pages = undefined;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _consts = require('../../config/consts');

var _lodash = require('lodash');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Encoding,
	DataUpdateType,
	PreviewDataType,
	UploadFileType
} = _consts.Enums;
let pages = exports.pages = _joi2.default.object().keys({
	pageIndex: _joi2.default.number().integer().min(1).required(),
	pageSize: _joi2.default.number().integer().min(5).max(100).required(),
	keyword: _joi2.default.string().min(1).max(30).allow("", null)
});

let create = exports.create = _joi2.default.object().keys({
	"type": _joi2.default.number().valid((0, _lodash.values)(UploadFileType)).required(),
	"dataHubId": _joi2.default.number().required(),
	"objectId": _joi2.default.string().required(),
	"updateType": _joi2.default.number().required().valid((0, _lodash.values)(DataUpdateType)),
	"encodeType": _joi2.default.number().required().valid((0, _lodash.values)(Encoding)),
	"fileName": _joi2.default.string().required(),
	"filePath": _joi2.default.string().required(),
	"attributesMapping": _joi2.default.object({
		"columnNum": _joi2.default.number().required(),
		"mapping": _joi2.default.object().min(1).required()
	}).required()
});

let upload = exports.upload = _joi2.default.object().keys({
	"encoding": _joi2.default.number().required().valid((0, _lodash.values)(Encoding)),
	"file": _joi2.default.any().required()
});

let preview = exports.preview = _joi2.default.object().keys({
	"encoding": _joi2.default.number().required().valid((0, _lodash.values)(Encoding)),
	"data": _joi2.default.any().required(),
	"type": _joi2.default.number().required().valid((0, _lodash.values)(PreviewDataType))
});
"use strict";

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Metrics', {
        id: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            defaultValue: null,
            field: "id"
        },
        metricsId: {
            type: DataTypes.STRING(64),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "metrics_id"
        },
        name: {
            type: DataTypes.STRING(64),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "name"
        },
        valueType: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "value_type"
        },
        status: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: "status"
        }
    }, {
        tableName: 'metrics',
        timestamps: false
    });
};
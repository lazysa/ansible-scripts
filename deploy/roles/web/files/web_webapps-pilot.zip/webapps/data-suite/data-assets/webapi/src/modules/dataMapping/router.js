'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _dataMapping = require('./data.mapping.controller');

var controller = _interopRequireWildcard(_dataMapping);

var _dataMapping2 = require('./data.mapping.filter');

var filter = _interopRequireWildcard(_dataMapping2);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
	prefix: "/dataMapping"
});

router.get('/pages', filter.pages, controller.pages);

router.get('/:dataHubId', controller.query);

router.get('/:dataHubId/mappingUrl', controller.generMappingUrl);

router.post('/', filter.checkDataHubStatus, filter.create, controller.create);

router.put('/:dataHubId', filter.checkDataHubStatus, filter.update, controller.update);

router.delete('/:dataHubId', controller.remove);

router.get('/:dataHubId/open', filter.checkDataHubStatus, controller.open);

router.get('/:dataHubId/close', controller.close);

exports.default = router;
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.getDownloadFileData = exports.download = exports.idCountDistribution = exports.associationRatioDown = exports.associationRatio = exports.idDistribution = exports.trend = exports.overview = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let overview = exports.overview = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (mergeRuleId) {
		let url = reportAppBaseUrl + "/merge/summary";
		return yield (0, _helper.getReportData)(url, {
			mergeRuleId: mergeRuleId
		});
	});

	return function overview(_x) {
		return _ref.apply(this, arguments);
	};
})();

let trend = exports.trend = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (trendType, mergeRuleId, metricIds, sort = "reportDate") {
		let url = reportAppBaseUrl + `/merge/trend/${trendType}`;
		return yield (0, _helper.getReportData)(url, {
			mergeRuleId: mergeRuleId,
			metric: metricIds,
			sort: sort
		});
	});

	return function trend(_x2, _x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

let idDistribution = exports.idDistribution = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (mergeRuleId, metricIds) {
		let url = reportAppBaseUrl + "/merge/distribute";
		let data = yield (0, _helper.getReportData)(url, {
			mergeRuleId: mergeRuleId,
			metric: metricIds
		});
		data = yield appendUserIdName(data);
		if (!data) {
			data = [];
		}
		return data;
	});

	return function idDistribution(_x5, _x6) {
		return _ref3.apply(this, arguments);
	};
})();

let associationRatio = exports.associationRatio = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (mergeRuleId, userIds, covertId2Name = true) {
		let url = reportAppBaseUrl + "/merge/mergeRate";
		let data = yield (0, _helper.getReportData)(url, {
			mergeRuleId: mergeRuleId,
			contrastUserIdType: userIds
		});
		if (data && data.length) {
			if (covertId2Name) {
				data = yield appendUserIdName(data);
			}
		} else {
			let metricses = yield (0, _metrics.getMetrics)();
			let allUserIds = yield (0, _userId.list)();
			data = [];
			let defaultData = {};
			metricses.forEach(function (metrics) {
				let value = 0;
				if (metrics.id == "overlapOrgIdRate") {
					value = "0:0";
				}
				defaultData[metrics.id] = value;
			});
			allUserIds.forEach(function (userId) {
				if (userIds.indexOf(userId.id) == -1) {
					data.push(Object.assign({
						userIdName: userId.name,
						userIdType: userId.id,
						contrastUserIdType: userIds[0],
						contrastCcidCount: 0
					}, defaultData));
				}
			});
		}
		return data;
	});

	return function associationRatio(_x7, _x8) {
		return _ref4.apply(this, arguments);
	};
})();

let associationRatioDown = exports.associationRatioDown = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (mergeRuleId, userIds, covertId2Name = true) {
		let url = reportAppBaseUrl + "/merge/mergeRate/Download";
		let data = yield (0, _helper.getReportData)(url, {
			mergeRuleId: mergeRuleId,
			contrastUserIdType: userIds
		});
		if (covertId2Name) {
			data = yield appendUserIdName(data);
		}
		if (!data) {
			data = [];
		}
		return data;
	});

	return function associationRatioDown(_x9, _x10) {
		return _ref5.apply(this, arguments);
	};
})();

let idCountDistribution = exports.idCountDistribution = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (mergeRuleId) {
		let url = reportAppBaseUrl + "/merge/typeDistribute";
		let data = yield (0, _helper.getReportData)(url, {
			mergeRuleId: mergeRuleId
		});
		if (!data) {
			data = [];
		}
		return data;
	});

	return function idCountDistribution(_x11) {
		return _ref6.apply(this, arguments);
	};
})();

let download = exports.download = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* (mergeRuleId) {
		let mergeRule = yield (0, _mergeRule.query)(mergeRuleId);
		let list = yield getDownloadFileData(mergeRuleId);
		let filePath = yield (0, _download.gennerFile)(list);
		let fileToken = yield (0, _download2.getToken)(filePath, `DataAssets_${mergeRule.name}_归并效果分析报告_${(0, _moment2.default)().format("YYYY-MM-DD_HH-mm")}.xlsx`);
		return fileToken;
	});

	return function download(_x12) {
		return _ref7.apply(this, arguments);
	};
})();

let getDownloadFileData = exports.getDownloadFileData = (() => {
	var _ref8 = (0, _asyncToGenerator3.default)(function* (mergeRuleId) {
		let userIdTypes = yield (0, _userId.list)();
		let userIds = (0, _lodash.map)(userIdTypes, "id");
		let trendMetrics = (0, _lodash.map)(_book2.default.trend.fields.filter(function (field) {
			if (!field.nonMetrics) {
				return true;
			}
			return false;
		}), "id");

		let idDistributionMetrics = (0, _lodash.map)(_book2.default.idDistribution.fields.filter(function (field) {
			if (!field.nonMetrics) {
				return true;
			}
			return false;
		}), "id");

		let trendData = yield trend("daily", mergeRuleId, trendMetrics, '-reportDate');
		let idDistributionData = yield idDistribution(mergeRuleId, idDistributionMetrics);
		let associationRatioData = yield associationRatioDown(mergeRuleId, userIds, false);
		associationRatioData = yield appendUserIdName(associationRatioData, ['userIdType', 'contrastUserIdType']);
		let idCountDistributionData = yield idCountDistribution(mergeRuleId);
		let idCountDistributionTotal = 0;
		idCountDistributionTotal = (0, _lodash.sum)((0, _lodash.map)(idCountDistributionData, 'ccidCount'));
		idCountDistributionData.forEach(function (row) {
			row.ccidCountRate = (row.ccidCount / idCountDistributionTotal).toFixed(2);
			row.userIdTypeCnt = `${row.userIdTypeCnt}种`;
		});
		let list = {
			trend: trendData,
			idDistribution: idDistributionData,
			associationRatio: associationRatioData,
			idCountDistribution: idCountDistributionData
		};
		return list;
	});

	return function getDownloadFileData(_x13) {
		return _ref8.apply(this, arguments);
	};
})();

let appendUserIdName = (() => {
	var _ref9 = (0, _asyncToGenerator3.default)(function* (data, fields) {
		if (!data) {
			return data;
		}
		if (!fields) {
			fields = ["userIdType"];
		}
		if (!Array.isArray(fields)) {
			fields = [fields];
		}
		let userIds = yield (0, _userId.list)();
		let userIdsMap = (0, _helper.dataToMap)(userIds, "id");
		data.forEach(function (item) {
			fields.forEach(function (field) {
				let userId = item[field];
				if (userId) {
					let nameField = field.replace("Type", "Name");
					item[nameField] = userId;
					if (userIdsMap[userId]) {
						item[nameField] = userIdsMap[userId].name;
					}
				}
			});
		});
		return data;
	});

	return function appendUserIdName(_x14, _x15) {
		return _ref9.apply(this, arguments);
	};
})();

var _models = require('../../common/models');

var _helper = require('../../common/util/helper');

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _consts = require('../../../config/consts');

var _lodash = require('lodash');

var _errors = require('../../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _metrics = require('../../base/metrics.service');

var _userId = require('../../userId/userId.service');

var _download = require('./download.service');

var _download2 = require('../../download/download.service');

var _mergeRule = require('../../mergeRule/merge.rule.service');

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _book = require('./book.config');

var _book2 = _interopRequireDefault(_book);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Status
} = _consts.Enums;


let {
	reportAppBaseUrl
} = _config2.default;
/**
 * Created by anne on 2017/5/17.
 */
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.query = exports.getOpenId = exports.userInfo = exports.code = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

// 生成access_token
let _wechatOauth = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* () {
        let result = null;
        try {
            let accessTokenFilePath = (0, _path.join)(_config2.default.configDir, "./access_token.json");
            let refresh = true;
            if (_fs2.default.existsSync(accessTokenFilePath)) {
                let content = yield _fs2.default.readFileSync(accessTokenFilePath, 'utf8');
                if (content) {
                    let json = JSON.parse(content);
                    json['corpId_' + _config2.default.wechatOAuth.corpId] = _config2.default.wechatOAuth.corpId;
                    if (json['corpId_' + _config2.default.wechatOAuth.corpId] && parseInt((0, _moment2.default)().format('X')) < json['access_token_expire']) {
                        refresh = false;
                        result = json['access_token'];
                    }
                }
            }
            if (refresh) {
                let perfix = `https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=${_config2.default.wechatOAuth.corpId}&corpsecret=${_config2.default.wechatOAuth.corpSecret}`;
                let data = yield (0, _helper.getWechat)(perfix);
                result = data.access_token;
                let json = {};
                json['corpId_' + _config2.default.wechatOAuth.corpId] = _config2.default.wechatOAuth.corpId;
                json.access_token = result;
                let expires = data.expires_in; // 超时秒数
                json.access_token_expire = parseInt(expires) + parseInt((0, _moment2.default)().format('X'));
                yield _fs2.default.writeFileSync(accessTokenFilePath, JSON.stringify(json, null, 4));
            }
        } catch (e) {
            throw new _errors2.default.WechatTokenError();
        }
        return result;
    });

    return function _wechatOauth() {
        return _ref.apply(this, arguments);
    };
})();

let code = exports.code = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (agentId, redirectUri) {
        let result = null;
        let asToken = yield _wechatOauth();
        if (!asToken) {
            return result;
        }
        let url = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${_config2.default.wechatOAuth.corpId}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=snsapi_userinfo&agentid=${agentId}&state=STATE#wechat_redirect`;
        return url;
    });

    return function code(_x, _x2) {
        return _ref2.apply(this, arguments);
    };
})();

let userInfo = exports.userInfo = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (code) {
        let result;
        let asToken = yield _wechatOauth();
        if (!asToken) {
            return result;
        }
        let url = `https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo?access_token=${asToken}&code=${code}`;
        result = yield (0, _helper.getWechat)(url);
        return result;
    });

    return function userInfo(_x3) {
        return _ref3.apply(this, arguments);
    };
})();

let getOpenId = exports.getOpenId = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (UserId, agentId) {
        let result;
        let asToken = yield _wechatOauth();
        if (!asToken) {
            return result;
        }
        let perfix = `https://qyapi.weixin.qq.com/cgi-bin/user/convert_to_openid?access_token=${asToken}`;
        let params = {
            "userid": UserId,
            "agentid": agentId
        };
        let options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            agent: false,
            rejectUnauthorized: false,
            content: JSON.stringify(params)
        };
        let data = yield (0, _helper.getWechat)(url);
        return data;
    });

    return function getOpenId(_x4, _x5) {
        return _ref4.apply(this, arguments);
    };
})();

let query = exports.query = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (userId) {
        let user = null;
        let sql = `select u.id, u.login_id
from wechat_mapping up
left join user u
on u.id = up.user_id
where up.wechat_login_id=:userId and u.status=:status and up.status=:status`;
        let result = yield _models.sequelize.query(sql, {
            replacements: {
                status: Status.Normal,
                userId: userId
            },
            type: _models.sequelize.QueryTypes.SELECT
        });
        if (result.length == 1) {
            user = (0, _helper.renameKeys)(result)[0];
        }
        return user;
    });

    return function query(_x6) {
        return _ref5.apply(this, arguments);
    };
})();

var _models = require('../common/models');

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _consts = require('../../config/consts');

var _helper = require('../common/util/helper');

var _path = require('path');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
    Status
} = _consts.Enums;

let corpId = _config2.default.wechatOAuth.corpId;
let corpSecret = _config2.default.wechatOAuth.corpSecret;
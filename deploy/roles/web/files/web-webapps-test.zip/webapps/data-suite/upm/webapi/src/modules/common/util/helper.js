'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.dataToMap = dataToMap;
exports.getData = getData;
exports.getWechat = getWechat;
exports.wrapBody = wrapBody;
exports.getJoiErrorMessage = getJoiErrorMessage;
exports.renameKeys = renameKeys;
exports.assignValue = assignValue;

var _errors = require('../core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _consts = require('../../../config/consts');

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _request = require('request');

var _request2 = _interopRequireDefault(_request);

var _lodash = require('lodash');

var _log = require('../core/log');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	ResponseStatusMap
} = _consts.OptionMaps;

function dataToMap(data, field) {
	let result = {};
	data.forEach(function (n) {
		result[n[field]] = n;
	});
	return result;
}

function getData(url, body, options) {
	//console.info(url, body);
	return new Promise(function (resolve, reject) {
		let defaults = {
			url: url,
			method: "post",
			json: true,
			body: body,
			timeout: _config2.default.apiTimeout,
			forever: true,
			pool: {
				maxSockets: _config2.default.poolSize
			},
			time: true
		};
		if (options) {
			Object.assign(defaults, options);
		}
		(0, _request2.default)(defaults, function (err, res, body) {
			_log.log.info({
				type: "DataAppApi",
				err: err,
				code: res ? res.statusCode : 0,
				url: url,
				elapsedTime: res ? res.elapsedTime : 0
			});
			if (err) {
				reject(new _errors2.default.DataAppServerNetError(err.message));
			} else {
				if (res.statusCode == 200) {
					if (body && body.code == 0) {
						resolve(body.data);
					} else {
						reject(new _errors2.default.DataAppQueryError([body.code, body.msg, "api query error"].join(" ")));
					}
				} else {
					reject(new _errors2.default.DataAppServerError(res.statusCode));
				}
			}
		});
	});
}

function getWechat(url, body, options) {
	return new Promise(function (resolve, reject) {
		let defaults = {
			url: url,
			method: "post",
			json: true,
			body: body,
			timeout: _config2.default.apiTimeout,
			forever: true,
			pool: {
				maxSockets: _config2.default.poolSize
			},
			time: true
		};

		if (body == null) {
			defaults.method = "get";
		}
		if (options) {
			Object.assign(defaults, options);
		}
		(0, _request2.default)(defaults, function (err, res, body) {
			_log.log.info({
				type: "DataAppApi",
				err: err,
				code: res ? res.statusCode : 0,
				url: url,
				elapsedTime: res ? res.elapsedTime : 0
			});
			if (err) {
				reject(new _errors2.default.WechatCodeError(err.message));
			} else {
				if (res.statusCode == 200) {
					if (body && body.errcode) {
						reject(new _errors2.default.WechatCodeError([body.errcode, body.errmsg, "api query error"].join(" ")));
					} else {
						resolve(body);
					}
				} else {
					reject(new _errors2.default.WechatCodeError(res.statusCode));
				}
			}
		});
	});
}

function wrapBody(error, data) {
	let status = (0, _lodash.pick)(ResponseStatusMap['Normal'], ['code', 'message']);
	if (error) {
		_log.log.error({
			type: "WebApi",
			err: error
		});
		status = {
			code: error.code ? error.code : 'E300',
			message: error.message
		};
		return {
			status: status
		};
	}
	return {
		data: data,
		status: status
	};
}

function getJoiErrorMessage(error) {
	return error.details.map(function (n) {
		return n.message;
	});
}

function renameKeys(data) {
	if (data.length) {
		data = (0, _lodash.map)(data, function (item) {
			item = (0, _lodash.mapKeys)(item, function (value, key) {
				return (0, _lodash.camelCase)(key);
			});
			return item;
		});
	} else {
		data = (0, _lodash.mapKeys)(data, function (value, key) {
			return (0, _lodash.camelCase)(key);
		});
	}
	return data;
}

function assignValue(source, sourceKey, dest, destKey) {
	let value = source[sourceKey];
	if (typeof value != 'undefined' && value != null) {
		dest[destKey] = value;
	}
	return dest;
}
"use strict";

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Session', {
        id: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            defaultValue: null,
            field: "id"
        },
        sid: {
            type: DataTypes.STRING(64),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "sid"
        },
        data: {
            type: DataTypes.STRING(512),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "data"
        },
        userId: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "user_id"
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "created_at"
        }
    }, {
        tableName: 'session',
        timestamps: false
    });
};
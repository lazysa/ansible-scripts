'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
let consts = {};

//返回结果
consts.ResponseStatus = [{
	id: "Normal",
	code: "E0",
	message: "ok"
}];

//状态
consts.Status = [{
	id: "Deleted",
	value: 0,
	name: "删除"
}, {
	id: "Normal",
	value: 1,
	name: "正常"
}];

consts.ActionType = [{
	id: "UI",
	value: 1,
	name: "ui"
}, {
	id: "API",
	value: 2,
	name: "api"
}];

consts.IsPrivateTeam = [{
	id: "No",
	value: 0,
	name: "否"
}, {
	id: "Yes",
	value: 1,
	name: "是"
}];

consts.IsPrivateTeam = [{
	id: "No",
	value: 0,
	name: "否"
}, {
	id: "Yes",
	value: 1,
	name: "是"
}];

exports.default = consts;
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.queryForUser = exports.getApplicationActionNames = exports.listForUser = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let listForUser = exports.listForUser = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (body) {
		let {
			applicationId,
			token,
			type
		} = body;
		let data = [];
		let isRoot = yield (0, _user.checkUserIsRoot)(token);
		let allNames = yield getApplicationActionNames(applicationId, type);
		if (isRoot) {
			//超级用户有所有的权限
			allNames.forEach(function (name) {
				data.push({
					name: name,
					permission: 1
				});
			});
		} else {
			let sql = `select a.name, rp.permission
from role_privilege rp
left join action a
on rp.privilege_id = a.privilege_id
left join privilege p
on rp.privilege_id = p.id
left join application app
on p.application_id = app.id
left join user_role ur
on ur.role_id = rp.role_id
left join user_token ut
on ut.user_id = ur.user_id
where ut.token=:token and a.type=:type and ut.status=:status and rp.status=:status and a.status=:status and ur.status=:status and app.name=:applicationId and app.status=:status`;
			let result = yield _models.sequelize.query(sql, {
				replacements: {
					applicationId: applicationId,
					status: Status.Normal,
					token: token,
					type: type
				},
				type: _models.sequelize.QueryTypes.SELECT
			});
			let nameGroups = (0, _lodash.groupBy)(result, "name");
			allNames.forEach(function (name) {
				let item = nameGroups[name];
				if (!item) {
					nameGroups[name] = {
						name: name,
						permission: 0
					};
				} else {
					if (item.length == 1) {
						nameGroups[name] = item[0];
					} else {
						nameGroups[name] = {
							name: name,
							permission: (0, _lodash.min)((0, _lodash.map)(item, "permission"))
						};
					}
				}
			});
			data = (0, _lodash.values)(nameGroups);
		}
		return data;
	});

	return function listForUser(_x) {
		return _ref.apply(this, arguments);
	};
})();

let getApplicationActionNames = exports.getApplicationActionNames = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (applicationId, type) {
		let data = [];
		let sql = `select a.name 
from privilege p
left join action a
on p.id = a.privilege_id
left join application app
on app.id = p.application_id
where app.name=:applicationId and a.type=:type and p.status=:status and a.status=:status and app.status=:status`;
		let result = yield _models.sequelize.query(sql, {
			replacements: {
				applicationId: applicationId,
				status: Status.Normal,
				type: type
			},
			type: _models.sequelize.QueryTypes.SELECT
		});
		if (result.length) {
			data = (0, _lodash.map)(result, "name");
		}
		return data;
	});

	return function getApplicationActionNames(_x2, _x3) {
		return _ref2.apply(this, arguments);
	};
})();

let queryForUser = exports.queryForUser = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (body) {
		let {
			applicationId,
			token,
			actionName
		} = body;
		let data = null;
		let sql = `select a.name, rp.permission
from role_privilege rp
left join action a
on rp.privilege_id = a.privilege_id
left join privilege p
on rp.privilege_id = p.id
left join application app
on p.application_id = app.id
left join user_role ur
on ur.role_id = rp.role_id
left join user_token ut
on ut.user_id = ur.user_id
where a.name=:actionName and ut.token=:token and a.type=:type and ut.status=:status and rp.status=:status and a.status=:status and ur.status=:status and app.name=:applicationId  and app.status=:status`;
		let result = yield _models.sequelize.query(sql, {
			replacements: {
				applicationId: applicationId,
				status: Status.Normal,
				token: token,
				type: ActionType.API,
				actionName: actionName
			},
			type: _models.sequelize.QueryTypes.SELECT
		});
		if (result.length) {
			data = result[0];
		}
		return data;
	});

	return function queryForUser(_x4) {
		return _ref3.apply(this, arguments);
	};
})();

var _models = require('../common/models');

var _helper = require('../common/util/helper');

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _user = require('../user/user.service');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Status,
	ActionType
} = _consts.Enums;
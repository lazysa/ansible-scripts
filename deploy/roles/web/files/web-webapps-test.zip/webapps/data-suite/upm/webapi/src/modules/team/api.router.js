'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _team = require('./team.controller');

var controller = _interopRequireWildcard(_team);

var _team2 = require('./team.filter');

var filter = _interopRequireWildcard(_team2);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
	prefix: '/team'
});

router.post('/list', filter.listForUser, controller.listForUser);
router.post('/private', filter.privateTeam, controller.privateTeam);

exports.default = router;
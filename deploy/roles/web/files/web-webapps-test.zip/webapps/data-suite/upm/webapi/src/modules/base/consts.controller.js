'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.getEnums = getEnums;
exports.getOptions = getOptions;
exports.getOptionsMap = getOptionsMap;
exports.getValMaps = getValMaps;
exports.getValKeyMaps = getValKeyMaps;
exports.getValNameMaps = getValNameMaps;

var _consts = require('../../config/consts');

var _helper = require('../common/util/helper');

function getEnums(ctx, next) {
	let data = null;
	let error = null;
	try {
		data = _consts.Enums;
	} catch (ex) {
		return ctx.body = (0, _helper.wrapBody)(ex);
	}
	ctx.body = (0, _helper.wrapBody)(error, data);
}

function getOptions(ctx, next) {
	let data = null;
	let error = null;
	try {
		data = _consts.Options;
	} catch (ex) {
		return ctx.body = (0, _helper.wrapBody)(ex);
	}
	ctx.body = (0, _helper.wrapBody)(error, data);
}

function getOptionsMap(ctx, next) {
	let data = null;
	let error = null;
	try {
		data = _consts.OptionMaps;
	} catch (ex) {
		return ctx.body = (0, _helper.wrapBody)(ex);
	}
	ctx.body = (0, _helper.wrapBody)(error, data);
}

function getValMaps(ctx, next) {
	let data = null;
	let error = null;
	try {
		data = _consts.ValMaps;
	} catch (ex) {
		return ctx.body = (0, _helper.wrapBody)(ex);
	}
	ctx.body = (0, _helper.wrapBody)(error, data);
}

function getValKeyMaps(ctx, next) {
	let data = null;
	let error = null;
	try {
		data = _consts.ValKeyMaps;
	} catch (ex) {
		return ctx.body = (0, _helper.wrapBody)(ex);
	}
	ctx.body = (0, _helper.wrapBody)(error, data);
}

function getValNameMaps(ctx, next) {
	let data = null;
	let error = null;
	try {
		data = _consts.ValNameMaps;
	} catch (ex) {
		return ctx.body = (0, _helper.wrapBody)(ex);
	}
	ctx.body = (0, _helper.wrapBody)(error, data);
}
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.privateTeam = exports.listForUser = undefined;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _consts = require('../../config/consts');

var _lodash = require('lodash');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let listForUser = exports.listForUser = _joi2.default.object().keys({
	token: _joi2.default.string().required()
});

let privateTeam = exports.privateTeam = _joi2.default.object().keys({
	token: _joi2.default.string().required()
});
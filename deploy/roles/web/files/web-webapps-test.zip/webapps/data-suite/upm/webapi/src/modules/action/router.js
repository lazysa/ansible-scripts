'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _action = require('./action.controller');

var controller = _interopRequireWildcard(_action);

var _action2 = require('./action.filter');

var filter = _interopRequireWildcard(_action2);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
	prefix: '/action'
});

exports.default = router;
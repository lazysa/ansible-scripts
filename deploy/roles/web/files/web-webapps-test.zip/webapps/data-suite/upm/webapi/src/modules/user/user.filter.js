'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.syncLogin = exports.auth = exports.create = exports.update = exports.pages = exports.verify = exports.modifyPassword = exports.login = exports.loginIdRepeatCheck = exports.userInfoForApplication = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let userInfoForApplication = exports.userInfoForApplication = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.userInfoForApplication;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function userInfoForApplication(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let loginIdRepeatCheck = exports.loginIdRepeatCheck = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.loginIdRepeatCheck;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function loginIdRepeatCheck(_x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

let login = exports.login = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.login;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function login(_x5, _x6) {
		return _ref3.apply(this, arguments);
	};
})();

let modifyPassword = exports.modifyPassword = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.modifyPassword;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			//检查密码强度
			let passwordStrengthInfo = checkPasswordStrength(ctx.request.body.password);
			if (!passwordStrengthInfo.strong) {
				throw new _errors2.default.UserPasswordWeak();
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function modifyPassword(_x7, _x8) {
		return _ref4.apply(this, arguments);
	};
})();

let verify = exports.verify = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.verify;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function verify(_x9, _x10) {
		return _ref5.apply(this, arguments);
	};
})();

let pages = exports.pages = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.pages;
		try {
			const result = _joi2.default.validate(ctx.request.query, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function pages(_x11, _x12) {
		return _ref6.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.update;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function update(_x13, _x14) {
		return _ref7.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref8 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.create;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			let passwordStrengthInfo = checkPasswordStrength(ctx.request.body.password);
			if (!passwordStrengthInfo.strong) {
				throw new _errors2.default.UserPasswordWeak();
			}
			//检查loginId和email是否已经注册过
			yield UserService.userFieldCheck(ctx.request.body);
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function create(_x15, _x16) {
		return _ref8.apply(this, arguments);
	};
})();

let auth = exports.auth = (() => {
	var _ref9 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		try {
			if (_config2.default.env != 'development') {
				let session = ctx.session;
				if (!session.loginId) {
					throw new _errors2.default.UserNotLogin();
				}
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function auth(_x17, _x18) {
		return _ref9.apply(this, arguments);
	};
})();

let syncLogin = exports.syncLogin = (() => {
	var _ref10 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.syncLogin;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function syncLogin(_x19, _x20) {
		return _ref10.apply(this, arguments);
	};
})();

exports.checkPasswordStrength = checkPasswordStrength;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _validation = require('./validation.schemas');

var schemas = _interopRequireWildcard(_validation);

var _helper = require('../common/util/helper');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _owaspPasswordStrengthTest = require('owasp-password-strength-test');

var _owaspPasswordStrengthTest2 = _interopRequireDefault(_owaspPasswordStrengthTest);

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _userService = require('./user.service.js');

var UserService = _interopRequireWildcard(_userService);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function checkPasswordStrength(password) {
	_owaspPasswordStrengthTest2.default.config({
		allowPassphrases: false,
		maxLength: 16,
		minLength: 6,
		minOptionalTestsToPass: 3
	});
	return _owaspPasswordStrengthTest2.default.test(password);
}
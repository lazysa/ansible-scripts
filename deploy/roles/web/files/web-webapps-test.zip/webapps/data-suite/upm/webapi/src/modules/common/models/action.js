"use strict";

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Action', {
        id: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            defaultValue: null,
            field: "id"
        },
        privilegeId: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "privilege_id"
        },
        name: {
            type: DataTypes.STRING(128),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "name"
        },
        type: {
            type: DataTypes.INTEGER(4).UNSIGNED,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "type"
        },
        status: {
            type: DataTypes.INTEGER(4).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: "status"
        }
    }, {
        tableName: 'action',
        timestamps: false
    });
};
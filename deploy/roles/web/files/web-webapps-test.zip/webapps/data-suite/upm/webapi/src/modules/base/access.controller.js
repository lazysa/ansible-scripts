'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.getApplicationList = exports.userAppList = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let userAppList = exports.userAppList = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let schema = _joi2.default.object().keys({
				token: _joi2.default.string().required()
			});
			let body = ctx.request.body;
			let {
				token
			} = body;
			let result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			let isRoot = yield (0, _user.checkUserIsRoot)(token);
			if (isRoot) {
				let applications = yield getApplicationList();
				data = (0, _lodash.map)(applications, "name");
			} else {
				let sql = `select distinct(app.name)
from role_privilege rp
left join privilege p
on rp.privilege_id  = p.id
left join application app
on p.application_id = app.id
left join role r
on rp.role_id=r.id
left join user_role ur
on ur.role_id = r.id
left join user u
on ur.user_id = u.id
left join user_token ut
on ut.user_id = u.id
where ut.token=:token and rp.status=:status and p.status=:status and app.status=:status and r.status=:status and ur.status=:status and u.status=:status and ut.status=:status`;
				result = yield _models.sequelize.query(sql, {
					replacements: {
						status: Status.Normal,
						token: token
					},
					type: _models.sequelize.QueryTypes.SELECT
				});
				data = (0, _lodash.map)(result, "name");
			}
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function userAppList(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let getApplicationList = exports.getApplicationList = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* () {
		return yield _models.Application.findAll({
			attributes: ['id', 'name'],
			where: {
				status: Status.Normal
			},
			raw: true
		});
	});

	return function getApplicationList() {
		return _ref2.apply(this, arguments);
	};
})();

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _models = require('../common/models');

var _helper = require('../common/util/helper');

var _lodash = require('lodash');

var _consts = require('../../config/consts');

var _user = require('../user/user.service');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Status
} = _consts.Enums;
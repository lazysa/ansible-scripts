'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.apiLog = exports.log = undefined;

var _path = require("path");

var _path2 = _interopRequireDefault(_path);

var _bunyan = require("bunyan");

var _bunyan2 = _interopRequireDefault(_bunyan);

var _config = require("../../../config/config");

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let env = _config2.default.env;

let {
	logRotatePeriod,
	maxLogFileCount
} = Object.assign({
	logRotatePeriod: '1d',
	maxLogFileCount: 30
}, _config2.default);

let log = _bunyan2.default.createLogger({
	name: "webapi",
	streams: [{
		level: 'info',
		path: _path2.default.join(_config2.default.logDir, "/logs.txt"),
		period: logRotatePeriod,
		count: maxLogFileCount
	}],
	serializers: {
		err: _bunyan2.default.stdSerializers.err,
		req: _bunyan2.default.stdSerializers.req,
		res: _bunyan2.default.stdSerializers.res
	}
});
log.level(_config2.default.logLevel);

//定日任务日志
let apiLog = _bunyan2.default.createLogger({
	name: "api",
	streams: [{
		level: 'info',
		path: _path2.default.join(_config2.default.logDir, "/apilogs.txt"),
		period: logRotatePeriod,
		count: maxLogFileCount
	}],
	serializers: {
		err: _bunyan2.default.stdSerializers.err,
		req: _bunyan2.default.stdSerializers.req,
		res: _bunyan2.default.stdSerializers.res
	}
});
apiLog.level('info');

function saveLogAndReload() {
	log.reopenFileStreams();
	apiLog.reopenFileStreams();
}

if (env != "development") {
	//pm2使用SIGINT
	process.on('SIGINT', function () {
		saveLogAndReload();
		setTimeout(function () {
			process.exit(0);
		}, 1000);
	});
} else {
	//nodemon使用SIGUSR2
	process.once('SIGUSR2', function () {
		saveLogAndReload();
		setTimeout(function () {
			process.kill(process.pid, 'SIGUSR2');
		}, 100);
	});
}

exports.log = log;
exports.apiLog = apiLog;
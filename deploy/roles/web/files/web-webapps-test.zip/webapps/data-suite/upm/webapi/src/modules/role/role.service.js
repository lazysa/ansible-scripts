'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.count = exports.list = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let list = exports.list = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (orderType) {
		let condition = {
			attributes: ['id', 'loginId', 'fullName'],
			where: {
				status: Status.Normal
			},
			raw: true
		};
		if (orderType) {
			Object.assign(condition, {
				order: [["id", orderType]]
			});
		}
		return _models.User.findAll(condition);
	});

	return function list(_x) {
		return _ref.apply(this, arguments);
	};
})();

let count = exports.count = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (condition) {
		Object.assign(condition, {
			status: Status.Normal
		});
		return _models.User.count({
			where: condition
		});
	});

	return function count(_x2) {
		return _ref2.apply(this, arguments);
	};
})();

var _models = require('../common/models');

var _helper = require('../common/util/helper');

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Status
} = _consts.Enums;
/**
 * Created by anne on 2017/5/17.
 */
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.redirectUrl = exports.auth = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let auth = exports.auth = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            ctx.session.callbackUrl = ctx.query.callbackUrl || '/!/';
            let url = yield WechatService.code(wechatOAuth.agentId, wechatOAuth.redirect_uri);
            ctx.redirect(url);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function auth(_x, _x2) {
        return _ref.apply(this, arguments);
    };
})();

let redirectUrl = exports.redirectUrl = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        let data = null;
        let error = null;
        try {
            let arg = _url2.default.parse(ctx.request.url, true).query;
            let userInfo = yield WechatService.userInfo(arg.code);
            let user = yield WechatService.query(userInfo.UserId);
            if (user == null) {
                ctx.redirect(ctx.session.callbackUrl);
            }
            yield userLogin(ctx, user.id, user.loginId);
            ctx.redirect(ctx.session.callbackUrl);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function redirectUrl(_x3, _x4) {
        return _ref2.apply(this, arguments);
    };
})();

let userLogin = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, userId, loginId) {
        let session = ctx.session;
        let userAppToken;
        //生成application token
        userAppToken = yield UserService.createUserToken(userId);
        //纪录session
        session.userId = userId;
        session.loginId = loginId;
        session.logined = true;
        ctx.cookies.set('X-Token', userAppToken.token, {
            path: "/",
            httpOnly: false
        });
        yield UserService.updateUserActivity(userAppToken.token, userId);
        let data = {
            token: userAppToken.token
        };
        return data;
    });

    return function userLogin(_x5, _x6, _x7) {
        return _ref3.apply(this, arguments);
    };
})();

var _helper = require('../common/util/helper');

var _wechat = require('./wechat.service');

var WechatService = _interopRequireWildcard(_wechat);

var _user = require('../user/user.service');

var UserService = _interopRequireWildcard(_user);

var _url = require('url');

var _url2 = _interopRequireDefault(_url);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let wechatOAuth = _config2.default.wechatOAuth;
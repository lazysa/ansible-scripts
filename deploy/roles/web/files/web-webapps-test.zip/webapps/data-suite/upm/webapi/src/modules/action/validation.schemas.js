'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.queryForUser = exports.listForUser = undefined;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _consts = require('../../config/consts');

var _lodash = require('lodash');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let listForUser = exports.listForUser = _joi2.default.object().keys({
	applicationId: _joi2.default.string().required(),
	type: _joi2.default.number().integer().required(),
	token: _joi2.default.string().required()
});

let queryForUser = exports.queryForUser = _joi2.default.object().keys({
	applicationId: _joi2.default.string().required(),
	token: _joi2.default.string().required(),
	actionName: _joi2.default.string().required()
});
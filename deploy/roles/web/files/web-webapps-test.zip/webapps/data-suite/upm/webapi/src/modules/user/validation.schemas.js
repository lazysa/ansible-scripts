'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.syncLogin = exports.create = exports.update = exports.pages = exports.verify = exports.login = exports.modifyPassword = exports.loginIdRepeatCheck = exports.userInfoForApplication = undefined;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _consts = require('../../config/consts');

var _lodash = require('lodash');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let userInfoForApplication = exports.userInfoForApplication = _joi2.default.object().keys({
	token: _joi2.default.string().required()
});

let loginIdRepeatCheck = exports.loginIdRepeatCheck = _joi2.default.object().keys({
	loginId: _joi2.default.string().min(3).max(20).required()
});

let modifyPassword = exports.modifyPassword = _joi2.default.object().keys({
	password: _joi2.default.string().min(6).max(16).required(),
	oldPassword: _joi2.default.string().required()
});

let login = exports.login = _joi2.default.object().keys({
	loginId: _joi2.default.string().min(3).max(20).required(),
	password: _joi2.default.string().min(6).max(16).required()
});

let verify = exports.verify = _joi2.default.object().keys({
	token: _joi2.default.string().min(64).required()
});

let pages = exports.pages = _joi2.default.object().keys({
	pageIndex: _joi2.default.number().integer().min(1).required(),
	pageSize: _joi2.default.number().integer().min(5).max(100).required(),
	keyword: _joi2.default.string().min(1).max(30).allow("", null)
});

let update = exports.update = _joi2.default.object().keys({
	"password": _joi2.default.string().max(60),
	"fullname": _joi2.default.string().max(64),
	"email": _joi2.default.string().max(64)
}).min(2);

let create = exports.create = _joi2.default.object().keys({
	loginId: _joi2.default.string().min(3).max(20).required(),
	password: _joi2.default.string().min(6).max(16).required(),
	fullname: _joi2.default.string().min(2).max(16),
	email: _joi2.default.string().min(6).max(30).required()
}).min(1);

let syncLogin = exports.syncLogin = _joi2.default.object().keys({
	loginId: _joi2.default.string().min(3).max(128).required()
}).min(1);
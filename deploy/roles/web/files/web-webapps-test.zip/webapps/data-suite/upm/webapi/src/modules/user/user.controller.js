'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.update = exports.create = exports.pages = exports.list = exports.remove = exports.query = exports.userInfo = exports.verify = exports.logout = exports.autoLogin = exports.modifyPassword = exports.syncLogin = exports.login = exports.loginIdRepeatCheck = exports.userInfoForApplication = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let userInfoForApplication = exports.userInfoForApplication = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let body = ctx.request.body;
			data = yield UserService.userInfoForApplication(body);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function userInfoForApplication(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let loginIdRepeatCheck = exports.loginIdRepeatCheck = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				loginId
			} = ctx.params;
			let count = yield UserService.loginIdRepeatCheck(loginId);
			let createable = true;
			if (count != 0) {
				createable = false;
			}
			data = createable;
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function loginIdRepeatCheck(_x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

let login = exports.login = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let body = ctx.request.body;
			let {
				loginId,
				password
			} = body;
			let session = ctx.session;
			let userAppToken;
			let user = yield UserService.query(loginId);
			if (user == null) {
				throw new _errors2.default.UserLoginIdOrPasswordError();
			}
			let userId = user.id;
			let hashPassword = user.passwordHash;
			let verifyPassed = yield UserService.verifyPassword(password, hashPassword);
			if (!verifyPassed) {
				throw new _errors2.default.UserLoginIdOrPasswordError();
			}
			//生成application token
			//await UserService.disableUserToken(userId);
			userAppToken = yield UserService.createUserToken(userId);
			//纪录session
			session.userId = userId;
			session.loginId = loginId;
			session.logined = true;
			ctx.cookies.set('X-Token', userAppToken.token, {
				path: "/",
				httpOnly: false
			});
			yield UserService.updateUserActivity(userAppToken.token, userId);
			data = {
				token: userAppToken.token
			};
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function login(_x5, _x6) {
		return _ref3.apply(this, arguments);
	};
})();

/*
用户同步登陆
*/


let syncLogin = exports.syncLogin = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				loginId
			} = ctx.request.body;
			let user = yield UserService.queryByMappingLoginId(loginId);
			if (!user) {
				throw new _errors2.default.UserLoginIdNotExists();
			}
			let session = {
				userId: user.id,
				loginId: user.loginId,
				logined: true
			};
			let userId = user.id;

			//await UserService.disabeSession(userId);
			let usid = yield UserService.saveSession(session);

			//await UserService.disableUserToken(userId);
			//await UserService.disableActivityByUserId(userId);

			let userAppToken = yield UserService.createUserToken(userId);
			let token = userAppToken.token;
			yield UserService.updateUserActivity(token, userId);
			data = {
				"usid": usid,
				"X-Token": token
			};
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function syncLogin(_x7, _x8) {
		return _ref4.apply(this, arguments);
	};
})();

let modifyPassword = exports.modifyPassword = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let body = ctx.request.body;
			let {
				password,
				oldPassword
			} = body;
			let session = ctx.session;
			let loginId = session.loginId;
			let user = yield UserService.query(loginId);
			let userId = user.id;
			let hashPassword = user.passwordHash;
			let verifyPassed = yield UserService.verifyPassword(oldPassword, hashPassword);
			if (!verifyPassed) {
				throw new _errors2.default.UserLoginIdOrPasswordError();
			}
			hashPassword = yield UserService.hashPassword(password);
			yield UserService.modifyPassword(userId, hashPassword);
		} catch (ex) {
			//console.info(ex.stack);
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function modifyPassword(_x9, _x10) {
		return _ref5.apply(this, arguments);
	};
})();

let autoLogin = exports.autoLogin = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let body = ctx.request.body;
			let session = ctx.session;
			let userId = session.userId;
			let userAppToken = yield UserService.getUserToken(userId);
			if (!userAppToken) {
				throw new _errors2.default.UserNotLogin();
			}
			data = {
				token: userAppToken.token
			};
		} catch (ex) {
			//console.info(ex.stack);
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function autoLogin(_x11, _x12) {
		return _ref6.apply(this, arguments);
	};
})();

let logout = exports.logout = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let session = ctx.session;
			if (session.userId) {
				yield UserService.disableUserToken(session.userId);
				yield UserService.disableActivityByUserId(session.userId);
			}
			ctx.session = {};
			//https://github.com/JiangJie/koa-clear-cookie/blob/master/index.js
			ctx.cookies.set('X-Token', '', {
				path: "/",
				httpOnly: false,
				expires: new Date(1)
			});
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function logout(_x13, _x14) {
		return _ref7.apply(this, arguments);
	};
})();

let verify = exports.verify = (() => {
	var _ref8 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let body = ctx.request.body;
			let {
				token
			} = body;
			let exists = yield UserService.verifyToken(token);
			let code = -1;
			if (exists) {
				let activity = yield UserService.queryUserActivity(token);
				if (activity) {
					if (_config2.default.maxidleTime && Date.now() - activity.lastActivity.getTime() < _config2.default.maxidleTime) {
						code = 0;
					}
				}
			}
			if (code == 0) {
				yield UserService.updateUserActivity(token);
			} else {
				//删除用户token
				yield UserService.disableToken(token);
				yield UserService.disableActivity(token);
				throw new _errors2.default.UserNotLogin();
			}
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function verify(_x15, _x16) {
		return _ref8.apply(this, arguments);
	};
})();

let userInfo = exports.userInfo = (() => {
	var _ref9 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let session = ctx.session;
			let loginId = session.loginId;
			let user = yield UserService.query(loginId);
			data = (0, _lodash.pick)(user, ['loginId', 'fullname', 'email']);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function userInfo(_x17, _x18) {
		return _ref9.apply(this, arguments);
	};
})();

let query = exports.query = (() => {
	var _ref10 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let loginId = ctx.params.loginId;
			let user = yield UserService.query(loginId);
			data = (0, _lodash.pick)(user, ['loginId', 'fullname', 'email']);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function query(_x19, _x20) {
		return _ref10.apply(this, arguments);
	};
})();

let remove = exports.remove = (() => {
	var _ref11 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let loginId = ctx.params.loginId;
			yield UserService.remove(loginId);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function remove(_x21, _x22) {
		return _ref11.apply(this, arguments);
	};
})();

let list = exports.list = (() => {
	var _ref12 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			data = yield UserService.list();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function list(_x23, _x24) {
		return _ref12.apply(this, arguments);
	};
})();

let pages = exports.pages = (() => {
	var _ref13 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let {
				pageSize,
				pageIndex,
				keyword
			} = ctx.query;
			let condition = {};
			if (keyword) {
				condition["$or"] = {
					loginId: {
						$like: '%' + keyword + '%'
					},
					fullname: {
						$like: '%' + keyword + '%'
					}
				};
			}
			pageSize = pageSize * 1;
			pageIndex = pageIndex * 1;
			let offset = (pageIndex - 1) * pageSize;
			let count = yield UserService.count(condition);
			let list = yield UserService.pages(pageSize, offset, condition);
			data = {
				list: list,
				pageIndex: pageIndex,
				pageSize: pageSize,
				total: count
			};
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function pages(_x25, _x26) {
		return _ref13.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref14 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let body = ctx.request.body;
			let {
				password
			} = body;
			let passwordHash = yield UserService.hashPassword(password);
			let info = (0, _lodash.pick)(body, ['loginId', 'fullname', 'email']);
			info.passwordHash = passwordHash;
			let user = yield UserService.create(info);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function create(_x27, _x28) {
		return _ref14.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref15 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let data = null;
		let error = null;
		try {
			let loginId = ctx.params.loginId;
			let body = ctx.request.body;
			let {
				password
			} = body;
			if (password) {
				let passwordStrengthInfo = (0, _user2.checkPasswordStrength)(password);
				if (!passwordStrengthInfo.strong) {
					throw new _errors2.default.UserPasswordWeak();
				}
			}

			let user = (0, _lodash.pick)(body, ['fullname', 'email']);
			if (password) {
				let passwordHash = yield UserService.hashPassword(password);
				user.passwordHash = passwordHash;
			}
			yield UserService.update(loginId, user);
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
		ctx.body = (0, _helper.wrapBody)(error, data);
	});

	return function update(_x29, _x30) {
		return _ref15.apply(this, arguments);
	};
})();

var _helper = require('../common/util/helper');

var _user = require('./user.service');

var UserService = _interopRequireWildcard(_user);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _lodash = require('lodash');

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _consts = require('../../config/consts');

var _user2 = require('./user.filter');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _router = require('./modules/base/router');

var _router2 = _interopRequireDefault(_router);

var _router3 = require('./modules/user/router');

var _router4 = _interopRequireDefault(_router3);

var _router5 = require('./modules/wechat/router');

var _router6 = _interopRequireDefault(_router5);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function register(app) {
	app.use(_router2.default.routes());
	app.use(_router4.default.routes());
	app.use(_router6.default.routes());
}

exports.default = register;
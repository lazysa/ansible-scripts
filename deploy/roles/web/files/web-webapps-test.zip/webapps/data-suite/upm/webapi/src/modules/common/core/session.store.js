'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _session = require('../middleware/session');

var _models = require('../models');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class SessionStore extends _session.Store {
    constructor() {
        super();
    }

    get(sid) {
        var _this = this;

        return (0, _asyncToGenerator3.default)(function* () {
            let session = yield _models.Session.findOne({
                where: {
                    sid: sid
                },
                attributes: ['id', 'data'],
                raw: true
            });
            let data = null;
            if (session && session.data != null) {
                data = _this.decode(session.data);
            }
            return data;
        })();
    }

    set(session, opts) {
        var _this2 = this;

        return (0, _asyncToGenerator3.default)(function* () {
            if (!opts.sid) {
                opts.sid = _this2.getID(24);
            }
            yield _models.Session.upsert({
                sid: opts.sid,
                userId: session.userId,
                data: _this2.encode(JSON.stringify(session)),
                createdAt: new Date()
            });
            return opts.sid;
        })();
    }

    destroy(sid) {
        return (0, _asyncToGenerator3.default)(function* () {
            return yield _models.Session.destroy({
                where: {
                    sid: sid
                }
            });
        })();
    }
}
exports.default = SessionStore;
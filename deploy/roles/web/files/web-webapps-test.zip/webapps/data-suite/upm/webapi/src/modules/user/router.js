'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _user = require('./user.controller');

var controller = _interopRequireWildcard(_user);

var _user2 = require('./user.filter');

var filter = _interopRequireWildcard(_user2);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

var _permission = require('../common/util/permission.helper');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)();

router.get('/user/loginIdRepeatCheck/:loginId', controller.loginIdRepeatCheck);

router.post('/login', filter.login, controller.login);

router.post('/modifyPassword', filter.auth, filter.modifyPassword, controller.modifyPassword);

router.post('/autoLogin', filter.auth, controller.autoLogin);

router.get("/logout", controller.logout);

router.get("/user/info", filter.auth, controller.userInfo);

router.get("/user/list", filter.auth, controller.list);

router.get("/user/pages", (0, _permission.checkPermission)("app.user.pages"), filter.auth, filter.pages, controller.pages);

router.get("/user/:loginId", (0, _permission.checkPermission)("app.user.query"), filter.auth, controller.query);

router.post("/user", (0, _permission.checkPermission)("app.user.create1"), filter.auth, filter.create, controller.create);

router.put("/user/:loginId", (0, _permission.checkPermission)("app.user.update"), filter.auth, filter.update, controller.update);

router.delete("/user/:loginId", (0, _permission.checkPermission)("app.user.delete"), filter.auth, controller.remove);

exports.default = router;
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.WechatMapping = exports.UserToken = exports.UserTeam = exports.UserRole = exports.UserMapping = exports.UserActivity = exports.User = exports.Team = exports.Session = exports.RolePrivilege = exports.Role = exports.Privilege = exports.Application = exports.Action = exports.sequelize = undefined;

var _sequelize = require('sequelize');

var _sequelize2 = _interopRequireDefault(_sequelize);

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _path = require('path');

var _log = require('../core/log');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

/*
timestamps: false的表
*/

let dbConfig = _config2.default.mysql;

let sequelize = exports.sequelize = new _sequelize2.default(dbConfig.database, dbConfig.user, dbConfig.password, {
	timezone: '+08:00',
	host: dbConfig.host,
	port: dbConfig.port ? dbConfig.port : 3306,
	dialect: 'mysql',
	pool: {
		max: dbConfig.poolSize,
		min: 0,
		idle: 10000
	},
	logging: dbConfig.logging,
	define: {
		underscored: true,
		hooks: { //http://docs.sequelizejs.com/en/latest/docs/hooks/
			beforeBulkCreate: function (rows) {
				rows.forEach(function (row) {
					if (typeof row.status == 'undefined' || row.status == null) {
						row.status = 1;
					}
				});
			},
			beforeValidate: function (row) {
				if (typeof row.status == 'undefined' || row.status == null) {
					row.status = 1;
				}
			}
		}
	}
});

sequelize.authenticate().catch(function (errors) {
	_log.log.info({
		type: "Mysql",
		err: errors
	});
});

let Action = exports.Action = sequelize.import((0, _path.join)(__dirname, './action'));
let Application = exports.Application = sequelize.import((0, _path.join)(__dirname, './application'));
let Privilege = exports.Privilege = sequelize.import((0, _path.join)(__dirname, './privilege'));
let Role = exports.Role = sequelize.import((0, _path.join)(__dirname, './role'));
let RolePrivilege = exports.RolePrivilege = sequelize.import((0, _path.join)(__dirname, './role.privilege'));
let Session = exports.Session = sequelize.import((0, _path.join)(__dirname, './session'));
let Team = exports.Team = sequelize.import((0, _path.join)(__dirname, './team'));
let User = exports.User = sequelize.import((0, _path.join)(__dirname, './user'));
let UserActivity = exports.UserActivity = sequelize.import((0, _path.join)(__dirname, './user.activity'));
let UserMapping = exports.UserMapping = sequelize.import((0, _path.join)(__dirname, './user.mapping'));
let UserRole = exports.UserRole = sequelize.import((0, _path.join)(__dirname, './user.role'));
let UserTeam = exports.UserTeam = sequelize.import((0, _path.join)(__dirname, './user.team'));
let UserToken = exports.UserToken = sequelize.import((0, _path.join)(__dirname, './user.token'));
let WechatMapping = exports.WechatMapping = sequelize.import((0, _path.join)(__dirname, './wechat.mapping'));
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _api = require('./modules/user/api.router');

var _api2 = _interopRequireDefault(_api);

var _api3 = require('./modules/action/api.router');

var _api4 = _interopRequireDefault(_api3);

var _api5 = require('./modules/team/api.router');

var _api6 = _interopRequireDefault(_api5);

var _api7 = require('./modules/base/api.router');

var _api8 = _interopRequireDefault(_api7);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function register(app) {
	app.use(_api2.default.routes());
	app.use(_api4.default.routes());
	app.use(_api6.default.routes());
	app.use(_api8.default.routes());
}

exports.default = register;
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.checkUserIsRoot = exports.saveSession = exports.disabeSession = exports.verifyPassword = exports.hashPassword = exports.disableActivityByUserId = exports.disableActivity = exports.updateUserActivity = exports.queryUserActivity = exports.verifyToken = exports.disableToken = exports.disableUserToken = exports.getUserToken = exports.createUserToken = exports.modifyPassword = exports.list = exports.pages = exports.count = exports.queryByMappingLoginId = exports.query = exports.remove = exports.update = exports.create = exports.userFieldCheck = exports.loginIdRepeatCheck = exports.userInfoForApplication = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let userInfoForApplication = exports.userInfoForApplication = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (body) {
		let {
			token
		} = body;
		let data = null;
		let sql = `select u.id, u.login_id, u.fullname, u.email
from user_token ut
left join user u
on ut.user_id = u.id
where ut.token=:token and ut.status=:status and u.status=:status`;
		let result = yield _models.sequelize.query(sql, {
			replacements: {
				status: Status.Normal,
				token: token
			},
			type: _models.sequelize.QueryTypes.SELECT
		});
		if (result.length) {
			let user = (0, _helper.renameKeys)(result)[0];
			let userId = user.id;
			sql = `select t.id, t.name, t.owner_user_id, t.original_owner_user_id 
from user_team ut
left join team t
on ut.team_id=t.id
where ut.status=:status and t.status=:status and ut.user_id=:userId and t.type=1`;
			let teams = yield _models.sequelize.query(sql, {
				replacements: {
					status: Status.Normal,
					token: token,
					userId: userId
				},
				type: _models.sequelize.QueryTypes.SELECT
			});
			let privateTeam = null;
			teams = (0, _helper.renameKeys)(teams);
			for (let i = 0; i < teams.length; i++) {
				let team = teams[i];
				if (team.originalOwnerUserId && team.ownerUserId == team.originalOwnerUserId) {
					privateTeam = team;
					break;
				}
			}
			data = user;
			data.privateTeam = privateTeam;
		}
		return data;
	});

	return function userInfoForApplication(_x) {
		return _ref.apply(this, arguments);
	};
})();

let loginIdRepeatCheck = exports.loginIdRepeatCheck = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (loginId) {
		loginId = loginId.toLowerCase();
		let where = {
			status: Status.Normal,
			loginId: loginId
		};
		let count = yield _models.User.count({
			where: where
		});
		return count;
	});

	return function loginIdRepeatCheck(_x2) {
		return _ref2.apply(this, arguments);
	};
})();

let userFieldCheck = exports.userFieldCheck = (() => {
	var _ref3 = (0, _asyncToGenerator3.default)(function* (data) {
		let pass = false;
		let {
			loginId,
			email
		} = data;
		email = email.toLowerCase();
		loginId = loginId.toLowerCase();
		let existsLoginId = yield _models.User.count({
			where: {
				status: Status.Normal,
				loginId: loginId
			}
		});
		if (existsLoginId) {
			throw new _errors2.default.UserLoginIdExists();
		}
		let existsEmail = yield _models.User.count({
			where: {
				status: Status.Normal,
				email: email
			}
		});
		if (existsEmail) {
			throw new _errors2.default.UserEmailExists();
		}
		pass = true;
		return pass;
	});

	return function userFieldCheck(_x3) {
		return _ref3.apply(this, arguments);
	};
})();

let create = exports.create = (() => {
	var _ref4 = (0, _asyncToGenerator3.default)(function* (data) {
		let t = yield _models.sequelize.transaction();
		try {
			let user = yield _models.User.create(data, {
				transaction: t
			});
			let team = yield _models.Team.create({
				ownerUserId: user.id,
				originalOwnerUserId: user.id,
				type: IsPrivateTeam.Yes
			}, {
				transaction: t
			});
			yield _models.UserTeam.create({
				userId: user.id,
				teamId: team.id
			}, {
				transaction: t
			});
			t.commit();
			return user;
		} catch (ex) {
			t.rollback();
			throw ex;
		}
	});

	return function create(_x4) {
		return _ref4.apply(this, arguments);
	};
})();

let update = exports.update = (() => {
	var _ref5 = (0, _asyncToGenerator3.default)(function* (loginId, info) {
		return yield _models.User.update(info, {
			where: {
				status: Status.Normal,
				loginId: loginId
			}
		});
	});

	return function update(_x5, _x6) {
		return _ref5.apply(this, arguments);
	};
})();

let remove = exports.remove = (() => {
	var _ref6 = (0, _asyncToGenerator3.default)(function* (loginId) {
		return yield _models.User.update({
			status: Status.Deleted
		}, {
			where: {
				status: Status.Normal,
				loginId: loginId
			}
		});
	});

	return function remove(_x7) {
		return _ref6.apply(this, arguments);
	};
})();

let query = exports.query = (() => {
	var _ref7 = (0, _asyncToGenerator3.default)(function* (loginId) {
		let user = yield _models.User.findOne({
			where: {
				status: Status.Normal,
				loginId: loginId
			},
			raw: true
		});
		return user;
	});

	return function query(_x8) {
		return _ref7.apply(this, arguments);
	};
})();

let queryByMappingLoginId = exports.queryByMappingLoginId = (() => {
	var _ref8 = (0, _asyncToGenerator3.default)(function* (loginId) {
		let user = null;
		let sql = `select u.id, u.login_id
from user_mapping up
left join user u
on u.id = up.user_id
where up.third_login_id=:loginId and u.status=:status and up.status=:status`;
		let result = yield _models.sequelize.query(sql, {
			replacements: {
				status: Status.Normal,
				loginId: loginId
			},
			type: _models.sequelize.QueryTypes.SELECT
		});
		if (result.length == 1) {
			user = (0, _helper.renameKeys)(result)[0];
		}
		return user;
	});

	return function queryByMappingLoginId(_x9) {
		return _ref8.apply(this, arguments);
	};
})();

let count = exports.count = (() => {
	var _ref9 = (0, _asyncToGenerator3.default)(function* (condition) {
		condition.status = Status.Normal;
		return _models.User.count({
			where: condition
		});
	});

	return function count(_x10) {
		return _ref9.apply(this, arguments);
	};
})();

let pages = exports.pages = (() => {
	var _ref10 = (0, _asyncToGenerator3.default)(function* (pageSize, offset, condition) {
		condition.status = Status.Normal;
		return yield _models.User.findAll({
			attributes: ['loginId', 'fullname', 'email', 'createdAt', 'status'],
			where: condition,
			limit: pageSize,
			offset: offset,
			order: [['id', 'desc']],
			raw: true
		});
	});

	return function pages(_x11, _x12, _x13) {
		return _ref10.apply(this, arguments);
	};
})();

let list = exports.list = (() => {
	var _ref11 = (0, _asyncToGenerator3.default)(function* () {
		return yield _models.User.findAll({
			attributes: ['loginId', 'fullname'],
			where: {
				status: Status.Normal
			},
			raw: true
		});
	});

	return function list() {
		return _ref11.apply(this, arguments);
	};
})();

let modifyPassword = exports.modifyPassword = (() => {
	var _ref12 = (0, _asyncToGenerator3.default)(function* (userId, passwordHash) {
		return yield _models.User.update({
			passwordHash: passwordHash
		}, {
			where: {
				status: Status.Normal,
				id: userId
			},
			raw: true
		});
	});

	return function modifyPassword(_x14, _x15) {
		return _ref12.apply(this, arguments);
	};
})();

//生成用户app token


let createUserToken = exports.createUserToken = (() => {
	var _ref13 = (0, _asyncToGenerator3.default)(function* (userId) {
		//禁用之前的token
		// await UserToken.update({
		// 	status: Status.Deleted
		// }, {
		// 	where: {
		// 		status: Status.Normal,
		// 		userId: userId
		// 	},
		// 	raw: true
		// });
		let token = _uidSafe2.default.sync(48); //0.75*64
		return yield _models.UserToken.create({
			userId: userId,
			token: token
		});
	});

	return function createUserToken(_x16) {
		return _ref13.apply(this, arguments);
	};
})();
//获取用户app token


let getUserToken = exports.getUserToken = (() => {
	var _ref14 = (0, _asyncToGenerator3.default)(function* (userId) {
		return yield _models.UserToken.findOne({
			attributes: ['token', 'createdAt'],
			where: {
				status: Status.Normal,
				userId: userId
			}
		});
	});

	return function getUserToken(_x17) {
		return _ref14.apply(this, arguments);
	};
})();

let disableUserToken = exports.disableUserToken = (() => {
	var _ref15 = (0, _asyncToGenerator3.default)(function* (userId) {
		// return await UserToken.update({
		// 	status: Status.Deleted
		// }, {
		// 	where: {
		// 		status: Status.Normal,
		// 		userId: userId
		// 	},
		// 	raw: true
		// });
		return yield _models.UserToken.destroy({
			where: {
				status: Status.Normal,
				userId: userId
			},
			raw: true
		});
	});

	return function disableUserToken(_x18) {
		return _ref15.apply(this, arguments);
	};
})();

let disableToken = exports.disableToken = (() => {
	var _ref16 = (0, _asyncToGenerator3.default)(function* (token) {
		// return await UserToken.update({
		// 	status: Status.Deleted
		// }, {
		// 	where: {
		// 		status: Status.Normal,
		// 		userId: userId
		// 	},
		// 	raw: true
		// });
		return yield _models.UserToken.destroy({
			where: {
				status: Status.Normal,
				token: token
			},
			raw: true
		});
	});

	return function disableToken(_x19) {
		return _ref16.apply(this, arguments);
	};
})();

let verifyToken = exports.verifyToken = (() => {
	var _ref17 = (0, _asyncToGenerator3.default)(function* (token) {
		let exists = false;
		let count = yield _models.UserToken.count({
			where: {
				status: Status.Normal,
				token: token
			}
		});
		if (count) {
			exists = true;
		}
		return exists;
	});

	return function verifyToken(_x20) {
		return _ref17.apply(this, arguments);
	};
})();

let queryUserActivity = exports.queryUserActivity = (() => {
	var _ref18 = (0, _asyncToGenerator3.default)(function* (token) {
		return yield _models.UserActivity.findOne({
			attributes: ['token', 'lastActivity'],
			where: {
				token: token
			},
			raw: true
		});
	});

	return function queryUserActivity(_x21) {
		return _ref18.apply(this, arguments);
	};
})();

let updateUserActivity = exports.updateUserActivity = (() => {
	var _ref19 = (0, _asyncToGenerator3.default)(function* (token, userId) {
		let info = {
			token: token,
			lastActivity: new Date()
		};
		if (userId) {
			info.userId = userId;
		}
		return yield _models.UserActivity.upsert(info, {
			where: {
				token: token
			}
		});
	});

	return function updateUserActivity(_x22, _x23) {
		return _ref19.apply(this, arguments);
	};
})();

let disableActivity = exports.disableActivity = (() => {
	var _ref20 = (0, _asyncToGenerator3.default)(function* (token) {
		return yield _models.UserActivity.destroy({
			where: {
				token: token
			}
		});
	});

	return function disableActivity(_x24) {
		return _ref20.apply(this, arguments);
	};
})();

let disableActivityByUserId = exports.disableActivityByUserId = (() => {
	var _ref21 = (0, _asyncToGenerator3.default)(function* (userId) {
		return yield _models.UserActivity.destroy({
			where: {
				userId: userId
			}
		});
	});

	return function disableActivityByUserId(_x25) {
		return _ref21.apply(this, arguments);
	};
})();

let hashPassword = exports.hashPassword = (() => {
	var _ref22 = (0, _asyncToGenerator3.default)(function* (password) {
		let saltRounds = 10;
		return yield bcryptHash(password, saltRounds);
	});

	return function hashPassword(_x26) {
		return _ref22.apply(this, arguments);
	};
})();

let verifyPassword = exports.verifyPassword = (() => {
	var _ref23 = (0, _asyncToGenerator3.default)(function* (password, hash) {
		return yield bcryptCompare(password, hash);
	});

	return function verifyPassword(_x27, _x28) {
		return _ref23.apply(this, arguments);
	};
})();

let disabeSession = exports.disabeSession = (() => {
	var _ref24 = (0, _asyncToGenerator3.default)(function* (userId) {
		yield _models.Session.destroy({
			where: {
				userId: userId
			}
		});
	});

	return function disabeSession(_x29) {
		return _ref24.apply(this, arguments);
	};
})();

let saveSession = exports.saveSession = (() => {
	var _ref25 = (0, _asyncToGenerator3.default)(function* (data) {
		let sid = yield sessionStore.set(data, {});
		return sid;
	});

	return function saveSession(_x30) {
		return _ref25.apply(this, arguments);
	};
})();

let checkUserIsRoot = exports.checkUserIsRoot = (() => {
	var _ref26 = (0, _asyncToGenerator3.default)(function* (token) {
		let isRoot = false;
		let sql = `select u.is_root 
from user_token ut
left join user u
on ut.user_id = u.id
where ut.token=:token and ut.status=:status and u.status=:status`;
		let result = yield _models.sequelize.query(sql, {
			replacements: {
				status: Status.Normal,
				token: token
			},
			type: _models.sequelize.QueryTypes.SELECT
		});
		if (result.length == 1) {
			result = (0, _helper.renameKeys)(result)[0];
			if (result.isRoot == 1) {
				isRoot = true;
			}
		}
		return isRoot;
	});

	return function checkUserIsRoot(_x31) {
		return _ref26.apply(this, arguments);
	};
})();

var _models = require('../common/models');

var _helper = require('../common/util/helper');

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

var _bcryptjs = require('bcryptjs');

var _bcryptjs2 = _interopRequireDefault(_bcryptjs);

var _uidSafe = require('uid-safe');

var _uidSafe2 = _interopRequireDefault(_uidSafe);

var _session = require('../common/core/session.store');

var _session2 = _interopRequireDefault(_session);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let {
	Status,
	IsPrivateTeam
} = _consts.Enums;

const sessionStore = new _session2.default();

let bcryptHash = _bluebird2.default.promisify(_bcryptjs2.default.hash);
let bcryptCompare = _bluebird2.default.promisify(_bcryptjs2.default.compare);
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.queryForUser = exports.listForUser = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let listForUser = exports.listForUser = (() => {
	var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.listForUser;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function listForUser(_x, _x2) {
		return _ref.apply(this, arguments);
	};
})();

let queryForUser = exports.queryForUser = (() => {
	var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
		let schema = schemas.queryForUser;
		try {
			const result = _joi2.default.validate(ctx.request.body, schema, {
				allowUnknown: true
			});
			if (result.error) {
				throw new _errors2.default.ParamsInvalid((0, _helper.getJoiErrorMessage)(result.error));
			}
			yield next();
		} catch (ex) {
			return ctx.body = (0, _helper.wrapBody)(ex);
		}
	});

	return function queryForUser(_x3, _x4) {
		return _ref2.apply(this, arguments);
	};
})();

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _validation = require('./validation.schemas');

var schemas = _interopRequireWildcard(_validation);

var _helper = require('../common/util/helper');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
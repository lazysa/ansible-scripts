"use strict";

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('User', {
        id: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            defaultValue: null,
            field: "id"
        },
        loginId: {
            type: DataTypes.STRING(64),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "login_id"
        },
        passwordHash: {
            type: DataTypes.STRING(64),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "password_hash"
        },
        fullname: {
            type: DataTypes.STRING(64),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "fullname"
        },
        email: {
            type: DataTypes.STRING(64),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "email"
        },
        parentId: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "parent_id"
        },
        isAdmin: {
            type: DataTypes.INTEGER(4).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 0,
            field: "is_admin"
        },
        status: {
            type: DataTypes.INTEGER(4).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: "status"
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "created_at"
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "updated_at"
        },
        createdUserId: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "created_user_id"
        },
        updatedUserId: {
            type: DataTypes.INTEGER(11).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: "updated_user_id"
        }
    }, {
        tableName: 'user',
        timestamps: true
    });
};
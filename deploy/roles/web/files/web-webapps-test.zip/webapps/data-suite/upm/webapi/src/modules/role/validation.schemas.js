'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
exports.pages = undefined;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _consts = require('../../config/consts');

var _lodash = require('lodash');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let pages = exports.pages = _joi2.default.object().keys({
	pageIndex: _joi2.default.number().integer().min(1).default(1),
	pageSize: _joi2.default.number().integer().min(5).max(100).default(10),
	keyword: _joi2.default.string().allow('').max(30),
	status: _joi2.default.number().integer().min(1).max(5),
	advertiserId: _joi2.default.number().integer(),
	planType: _joi2.default.number().integer(),
	startDate: _joi2.default.date().format("YYYY-MM-DD"),
	endDate: _joi2.default.date().format("YYYY-MM-DD")
});
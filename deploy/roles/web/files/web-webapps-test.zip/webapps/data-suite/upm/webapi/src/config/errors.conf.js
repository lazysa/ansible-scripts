'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
let consts = {};

//系统级别
consts.ProgramerException = {
	code: "E300",
	message: "系统程序执行错误"
};

consts.ParamsInvalid = {
	code: "E302",
	message: "数据验证失败"
};

consts.DataIsNull = {
	code: "E303",
	message: "数据为空"
};

consts.DataException = {
	code: "E304",
	message: "数据异常"
};

consts.UrlInvalid = {
	code: "E305",
	message: "非法url"
};

consts.User = [{
	name: "LoginIdExists",
	code: "E4201",
	message: "登陆id重复"
}, {
	name: "EmailExists",
	code: "E4202",
	message: "email重复"
}, {
	name: "PasswordWeak",
	code: "E4203",
	message: "密码强度不够"
}, {
	name: "LoginIdOrPasswordError",
	code: "E4204",
	message: "用户名或密码错误"
}, {
	name: "NotHasAppRight",
	code: "E4205",
	message: "用户无app登陆权限"
}, {
	name: "NotLogin",
	code: "E4206",
	message: "用户未登录"
}, {
	name: "LoginIdNotExists",
	code: "E4207",
	message: "登陆id不存在"
}];

consts.Wechat = [{
	name: "CodeError",
	code: "E5201",
	message: "微信数据应用查询错误"
}, {
	name: "TokenError",
	code: "E5202",
	message: "微信token异常"
}];

exports.default = consts;
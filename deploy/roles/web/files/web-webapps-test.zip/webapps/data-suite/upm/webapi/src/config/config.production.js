'use strict';

Object.defineProperty(exports, "__esModule", {
		value: true
});

var _path = require('path');

let config = {
		env: 'production',
		appPort: 9103,
		apiPort: 9105,
		mysql: {
					host: '127.0.0.1',
					poolSize: 5,
					user: 'root',
					password: 'Datahub0201#',
					database: 'upm'
				},
		logDir: "/mnt/logs/upm/webapi",
		apiTimeout: 5000,
		poolSize: 5,
		sessionKey: "usid",
		maxidleTime: 2 * 60 * 60 * 1000,
		whitePaths: ["/login", "/autoLogin", "/consts", "/wechat"],
		authAPiPath: "http://localhost:9105/",
    		authAppId: "upm",
		wechatOAuth: {
			corpId: 'wx46619bf3f91606eb',
			corpSecret: 'IXm8DN96FMgPMUeX8B-9mlyIb4eh1bQt6WbZIHlQed8T8QvX_oMvYTt4m-D7j21e',
			agentId: 28,
			redirect_uri:'https://edu.chiefclouds.com/!/upm/api/wechat/redirectUrl'
			//redirect_uri:'https://54.223.85.72/!/upm/api/wechat/redirectUrl'
		},
		configDir:__dirname
};
exports.default = config;

'use strict';

var _koa = require('koa');

var _koa2 = _interopRequireDefault(_koa);

var _koaConvert = require('koa-convert');

var _koaConvert2 = _interopRequireDefault(_koaConvert);

var _koaError = require('koa-error');

var _koaError2 = _interopRequireDefault(_koaError);

var _config = require('./config/config');

var _config2 = _interopRequireDefault(_config);

var _api = require('./api.router');

var _api2 = _interopRequireDefault(_api);

var _koaBody = require('koa-body');

var _koaBody2 = _interopRequireDefault(_koaBody);

var _log = require('./modules/common/core/log');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

global.log = _log.apiLog;

const app = new _koa2.default();

//body解析
app.use((0, _koaConvert2.default)((0, _koaBody2.default)({
	multipart: false
})));

//禁止缓存
app.use(function (ctx, next) {
	ctx.set('Cache-Control', 'no-cache, no-store, must-revalidate'); // HTTP 1.1.
	ctx.set('Pragma', 'no-cache'); // HTTP 1.0.
	ctx.set('Expires', '0'); // Proxies.
	return next();
});

//输出错误日志 开发环境使用
if (_config2.default.env == 'development') {
	app.use((0, _koaConvert2.default)((0, _koaError2.default)()));
} else {
	app.on('error', function (err, ctx) {
		if (ctx.status != 404) {
			log.error({
				type: "System",
				err: _koaError2.default
			});
		}
		ctx.status = err.status || 500;
		ctx.body = err.message;
	});
}
//路由
(0, _api2.default)(app);

app.listen(_config2.default.apiPort, function () {});
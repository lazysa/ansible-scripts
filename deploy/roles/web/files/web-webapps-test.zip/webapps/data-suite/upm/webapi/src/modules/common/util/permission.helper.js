"use strict";

var _asyncToGenerator2 = require("babel-runtime/helpers/asyncToGenerator");

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const {
	services: upmServices,
	errors: upmErrors
} = require("upm-auth");
const {
	wrapBody: wrap
} = require("./helper");

exports.checkPermission = function (actionId) {
	return (() => {
		var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
			try {
				let actionInfo = yield upmServices.getActionInfo(actionId);

				let {
					permission
				} = actionInfo;
				if (permission == null) {
					throw new upmErrors.PermissionDeny();
				}
				ctx.state.actionInfo = actionInfo;
				yield next();
			} catch (ex) {
				return ctx.body = wrap(ex);
			}
		});

		return function (_x, _x2) {
			return _ref.apply(this, arguments);
		};
	})();
};
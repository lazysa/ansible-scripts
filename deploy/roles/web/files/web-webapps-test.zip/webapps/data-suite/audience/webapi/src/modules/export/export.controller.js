'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.update = exports.getExportPages = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _consts = require('../../config/consts');

var _lodash = require('lodash');

var _helper = require('../common/util/helper');

var _export = require('./export.service');

var exportService = _interopRequireWildcard(_export);

var _segment = require('../segment/segment.service');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let SegmentType = _consts.Enums.SegmentType;

let getExportPages = exports.getExportPages = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let list = null;
        let data = null;
        let error = null;
        try {
            let segmentId = ctx.params.segmentId;
            let segmentInfo = yield (0, _segment.query)(segmentId);
            let query = ctx.request.query;
            let offset = query.pageSize * (query.pageIndex - 1);
            let limit = +query.pageSize;
            let keywords = query.keywords;
            if (segmentInfo && (segmentInfo.type === SegmentType.First || segmentInfo.type === SegmentType.Upload || segmentInfo.type === SegmentType.Default || segmentInfo.type === SegmentType.Lookalike)) {
                list = yield exportService.getFirstExportList();
            } else {
                let segmentRules = JSON.parse(segmentInfo.segmentRules);
                list = yield exportService.getThirdExportList(segmentRules.thirdPartyRules.dataSourceId);
            }
            /**
             * 手动过滤
             */
            if (keywords) {
                list = list.filter(function (item) {
                    let reg = new RegExp(keywords);
                    return reg.test(item.name) || reg.test(item.id);
                });
            }
            let total = list.length;

            if (offset > -1 && limit) {
                list = list.splice(offset, limit);
            }

            list = yield exportService.appendExportList(list, segmentId);

            data = {
                total,
                list,
                pageSize: query.pageSize,
                pageIndex: query.pageIndex
            };
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function getExportPages(_x) {
        return _ref.apply(this, arguments);
    };
})();
let update = exports.update = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let segmentId = ctx.params.segmentId;
            let dataDestinationId = ctx.params.dataDestinationId;
            let body = ctx.request.body;

            data = yield exportService.updateAndCreate(segmentId, dataDestinationId, (0, _lodash.pick)(body, ['isForever', 'expires', 'status']));
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function update(_x2) {
        return _ref2.apply(this, arguments);
    };
})();
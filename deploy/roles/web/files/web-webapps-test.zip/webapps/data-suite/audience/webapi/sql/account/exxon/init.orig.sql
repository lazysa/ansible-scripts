

CREATE TABLE tmp_histo_input_tmall_special (product_name TEXT, pay_date TEXT, buyer_id TEXT, buyer_mobile TEXT, province TEXT, city TEXT, district TEXT, liter TEXT) DEFAULT CHARSET=utf8;
LOAD DATA LOCAL INFILE '/Users/nikizhang/Documents/achive/special.csv' IGNORE INTO TABLE tmp_histo_input_tmall_special;

CREATE TABLE tmp_histo_input_tmall_super (product_name TEXT, pay_date TEXT, buyer_id TEXT, buyer_mobile TEXT, province TEXT, city TEXT, district TEXT, liter TEXT) DEFAULT CHARSET=utf8;
LOAD DATA LOCAL INFILE '/Users/nikizhang/Documents/achive/super.csv' IGNORE INTO TABLE tmp_histo_input_tmall_super;

CREATE TABLE tmp_histo_input_tmall_motor (product_name TEXT, pay_date TEXT, buyer_id TEXT, buyer_mobile TEXT, province TEXT, city TEXT, district TEXT, liter TEXT) DEFAULT CHARSET=utf8;
LOAD DATA LOCAL INFILE '/Users/nikizhang/Documents/achive/motor.csv' IGNORE INTO TABLE tmp_histo_input_tmall_motor;

CREATE TABLE tmp_histo_input_tmall_mobile_1 (product_name TEXT, pay_date TEXT, buyer_id TEXT, buyer_mobile TEXT, province TEXT, city TEXT, district TEXT, liter TEXT) DEFAULT CHARSET=utf8;
LOAD DATA LOCAL INFILE '/Users/nikizhang/Documents/achive/mobile1.csv' IGNORE INTO TABLE tmp_histo_input_tmall_mobile_1;

CREATE TABLE tmp_histo_input_tmall_grease (product_name TEXT, pay_date TEXT, buyer_id TEXT, buyer_mobile TEXT, province TEXT, city TEXT, district TEXT, liter TEXT) DEFAULT CHARSET=utf8;
LOAD DATA LOCAL INFILE '/Users/nikizhang/Documents/achive/grease.csv' IGNORE INTO TABLE tmp_histo_input_tmall_grease;

CREATE TABLE tmp_histo_input_tmall_delvac (product_name TEXT, pay_date TEXT, buyer_id TEXT, buyer_mobile TEXT, province TEXT, city TEXT, district TEXT, liter TEXT) DEFAULT CHARSET=utf8;
LOAD DATA LOCAL INFILE '/Users/nikizhang/Documents/achive/delvac.csv' IGNORE INTO TABLE tmp_histo_input_tmall_delvac;

CREATE TABLE temp_ods_sells_transaction (
 product_name TEXT COMMENT 'The Actual Chinese Name',
 pay_date TEXT COMMENT 'in format of DD/MM/YYYY',
 buyer_id TEXT COMMENT 'the tmall Account id Buyer',
 buyer_mobile TEXT COMMENT 'The 11 digits mobile number',
 buyer_province TEXT COMMENT 'the province name with SHENG char',
 buyer_city TEXT COMMENT 'the city name within province, with SHI char',
 buyer_district TEXT,
 buy_liter TEXT);

INSERT temp_ods_sells_transaction SELECT * from tmp_histo_input_tmall_special;
INSERT temp_ods_sells_transaction SELECT * from tmp_histo_input_tmall_motor;
INSERT temp_ods_sells_transaction SELECT * from tmp_histo_input_tmall_super;
INSERT temp_ods_sells_transaction SELECT * from tmp_histo_input_tmall_mobile_1;
INSERT temp_ods_sells_transaction SELECT * from tmp_histo_input_tmall_grease;
INSERT temp_ods_sells_transaction SELECT * from tmp_histo_input_tmall_delvac;

DROP TABLE tmp_histo_input_tmall_super;
DROP TABLE tmp_histo_input_tmall_special;
DROP TABLE tmp_histo_input_tmall_motor;
DROP TABLE tmp_histo_input_tmall_mobile_1;
DROP TABLE tmp_histo_input_tmall_grease;
DROP TABLE tmp_histo_input_tmall_delvac;

CREATE TABLE product_names ( name TEXT );
INSERT product_names SELECT DISTINCT product_name from temp_ods_sells_transaction;

CREATE TABLE pay_dates ( pay_date TEXT );
INSERT pay_dates SELECT DISTINCT pay_date from temp_ods_sells_transaction;

CREATE TABLE ods_sells_count_total_liter (
  product_name TEXT, pay_date TEXT, count INT, liter INT
);
INSERT ods_sells_count_total_liter SELECT product_name, pay_date, count(2), SUM(buy_liter) AS liter from temp_ods_sells_transaction GROUP BY product_name, pay_date;

CREATE TABLE temp_ods_sells_buyer_id (
  product_name TEXT, pay_date TEXT, buyer_id TEXT, count INT
);
INSERT temp_ods_sells_buyer_id SELECT product_name, pay_date, buyer_id, count(3) from temp_ods_sells_transaction GROUP BY product_name, pay_date, buyer_id;
CREATE TABLE ods_sells_buyer_count (
  product_name TEXT, pay_date TEXT, buyer_counts INT
);
INSERT ods_sells_buyer_count SELECT product_name, pay_date, count(2) from temp_ods_sells_buyer_id GROUP BY product_name, pay_date;

CREATE TABLE ods_sells (
  product_name TEXT, pay_date TEXT, count INT, liter INT, buyer_counts INT
);
INSERT ods_sells SELECT a.product_name, a.pay_date, a.count, a.liter, b.buyer_counts FROM ods_sells_count_total_liter a INNER JOIN ods_sells_buyer_count b ON a.pay_date = b.pay_date && a.product_name = b.product_name;

CREATE TABLE ods_sells_2016 (
  product_name TEXT, pay_date TEXT, count INT, liter INT, buyer_counts INT
);
INSERT ods_sells_2016 SELECT product_name, pay_date, count, liter, buyer_counts from ods_sells WHERE LOCATE('2016', pay_date) > 0;
CREATE TABLE ods_sells_2017 (
  product_name TEXT, pay_date TEXT, count INT, liter INT, buyer_counts INT
);
INSERT ods_sells_2017 SELECT product_name, pay_date, count, liter, buyer_counts from ods_sells WHERE LOCATE('2017', pay_date) > 0;
CREATE TABLE ods_sells_2015 (
  product_name TEXT, pay_date TEXT, count INT, liter INT, buyer_counts INT
);
INSERT ods_sells_2015 SELECT product_name, pay_date, count, liter, buyer_counts from ods_sells WHERE LOCATE('2015', pay_date) > 0;





# select count(distinct buyer_id) as cnt from mds_balabala where category="美孚力霸"&&RIGHT(pay_date, 4)="2017";
# create table mds_balabala as select * from temp_ods_sells_transaction left join product_infos on product_infos.name=temp_ods_sells_transaction.product_name;

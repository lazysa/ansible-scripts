"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
let consts = {};

consts.responseStatus = [{
    id: "normal",
    code: "E0",
    message: "ok"
}];

//状态
consts.Status = [{
    id: "Deleted",
    value: 0,
    name: "删除"
}, {
    id: "Normal",
    value: 1,
    name: "正常"
}];

//HasTagStatus状态
consts.HasTagStatus = [{
    id: "Deleted",
    value: 0,
    name: "删除"
}, {
    id: "Normal",
    value: 1,
    name: "正常"
}];

//标签的级别
consts.TagLevel = [{
    id: "default",
    value: 1,
    name: "自定义标签"
}, {
    id: "system",
    value: 2,
    name: "系统内置"
}, {
    id: "customization",
    value: 3,
    name: "定置标签"
}, {
    id: "uploadHidden",
    value: 4,
    name: "上传人群内置隐藏标签"
}, {
    id: "campaignAndSiteHidden",
    value: 5,
    name: "活动站点内置隐藏标签"
}, {
    id: "behaviorRuleHidden",
    value: 6,
    name: "标签构造器行为规则新建的挂载标签"
}, {
    id: "batchDefault",
    value: 8,
    name: "通过选择对象批量新建的标签"
}];

//标签是否可以编辑
consts.RecordEditable = [{
    id: "able",
    value: 1,
    name: "标签可以编辑"
}, {
    id: "unable",
    value: 0,
    name: "标签不可以编辑"
}];

//标签是否可以洞察
consts.IsUsedForInsight = [{
    id: "able",
    value: 1,
    name: "标签可以洞察"
}, {
    id: "unable",
    value: 0,
    name: "标签不可以洞察"
}];

//标签是否可以洞察
consts.TaskStatus = [{
    id: "run",
    value: 1,
    name: "启动洞察更新任务"
}, {
    id: "no",
    value: 0,
    name: "不更新"
}];

consts.Permission = [{
    id: "All",
    value: 1,
    name: "全部数据"
}, {
    id: "AllGroup",
    value: 2,
    name: "所属组"
}, {
    id: "PrivateTeam",
    value: 3,
    name: "私有"
}, {
    id: "SelfPrivateTeam",
    value: 4,
    name: "自己私有"
}];

//rollerTypeStatus状态
consts.rollerType = [{
    id: "provider",
    value: 1,
    name: "数据源"
}, {
    id: "receiver",
    value: 2,
    name: "接收方"
}];

consts.DefaultCampaignSegmentType = [{
    id: "viewCampaign",
    value: '看过'
}, {
    id: "clickCampaign",
    value: "点过"
}, {
    id: "viewSite",
    value: "到站"
}];

consts.DefaultSiteSegmentType = [{
    id: "viewSite",
    value: "访问"
}];

//标签更新周期
consts.TagUpdatePeriod = [{
    id: "day",
    value: 1,
    name: "一天一次"
}, {
    id: "week",
    value: 2,
    name: "一周一次"
}, {
    id: "month",
    value: 3,
    name: "一月一次"
}, {
    id: "motionless",
    value: 4,
    name: "不更新"
    // , {
    //     id: "auto",
    //     value: 5,
    //     name: "自动更新"
    // }
}];

//第一方人群更新周期
consts.SegmentUpdatePeriod = [{
    id: "day",
    value: 1,
    name: "一天一次"
}, {
    id: "week",
    value: 2,
    name: "一周一次"
}, {
    id: "month",
    value: 3,
    name: "一月一次"
}, {
    id: "motionless",
    value: 4,
    name: "不更新"
    // , {
    //     id: "auto",
    //     value: 5,
    //     name: "自动更新"
    // }
}];

//报告更新周期
consts.ReportUpdatePeriod = [{
    id: "day",
    value: 1,
    name: "一天一次"
}, {
    id: "week",
    value: 2,
    name: "一周一次"
}, {
    id: "month",
    value: 3,
    name: "一月一次"
}, {
    id: "motionless",
    value: 4,
    name: "不更新"
    // , {
    //     id: "auto",
    //     value: 5,
    //     name: "自动更新"
    // }
}];

//洞察报告更新周期
consts.IngsightUpdatePeriod = [{
    id: "day",
    value: 1,
    name: "一天一次"
}, {
    id: "week",
    value: 2,
    name: "一周一次"
}, {
    id: "month",
    value: 3,
    name: "一月一次"
}, {
    id: "motionless",
    value: 4,
    name: "不更新"
    // , {
    //     id: "auto",
    //     value: 5,
    //     name: "自动更新"
    // }
}];

//归并报告更新周期
consts.MergeReportUpdatePeriod = [{
    id: "day",
    value: 1,
    name: "一天一次"
}, {
    id: "week",
    value: 2,
    name: "一周一次"
}, {
    id: "month",
    value: 3,
    name: "一月一次"
}, {
    id: "motionless",
    value: 4,
    name: "不更新"
    // , {
    //     id: "auto",
    //     value: 5,
    //     name: "自动更新"
    // }
}];

//DataSourceCategory状态
consts.DataSourceCategory = [{
    id: "FirstParty",
    value: 1,
    name: "第一方"
}, {
    id: "ThirdParty",
    value: 2,
    name: "第三方"
}];
//OtherStatus
consts.OtherStatus = [{
    id: "tag",
    value: 'TTG0',
    name: "其它"
}, {
    id: "segment",
    value: '1',
    name: "其它"
}];

//标签的状态
consts.TagType = [{
    id: "Single",
    value: 1,
    name: "单值"
}, {
    id: "Multiple",
    value: 2,
    name: "多值"
}];

//标签组的状态
consts.TagGroupStatus = [{
    id: "Deleted",
    value: 0,
    name: "删除"
}, {
    id: "Normal",
    value: 1,
    name: "正常"
}];
//用户id加密类型
consts.UserIdEncryptType = [{
    id: "NULL",
    value: 0,
    name: "明文无加密"
}, {
    id: "MD5",
    value: 1,
    name: "MD5加密"
}, {
    id: "SHA1",
    value: 2,
    name: "SHA1加密"
}];
//标签的状态
consts.TagStatus = [{
    id: "Deleted",
    value: 0,
    name: "删除"
}, {
    id: "Open",
    value: 1,
    name: "开启"
}, {
    id: "Close",
    value: 2,
    name: "关闭"
}];

//分发的状态
consts.ExportStatus = [{
    id: "Deleted",
    value: 0,
    name: "删除"
}, {
    id: "Open",
    value: 1,
    name: "开启"
}, {
    id: "Close",
    value: 2,
    name: "关闭"
}];

//标签值的状态
consts.TagValueStatus = [{
    id: "Deleted",
    value: 0,
    name: "删除"
}, {
    id: "Normal",
    value: 2,
    name: "正常"
}, {
    id: "Generating",
    value: 1,
    name: "生成中"
}, {
    id: "Exception",
    value: 3,
    name: "异常"
}];

//人群的状态
consts.SegmentStatus = [{
    id: "Deleted",
    value: 0,
    name: "删除"
}, {
    id: "Normal",
    value: 2,
    name: "正常"
}, {
    id: "Generating",
    value: 1,
    name: "生成中"
}, {
    id: "Exception",
    value: 3,
    name: "异常"
}];
//洞察任务insight的状态
consts.InsightDataStatus = [{
    id: "Deleted",
    value: 0,
    name: "删除"
}, {
    id: "Normal",
    value: 2,
    name: "正常"
}, {
    id: "Generating",
    value: 1,
    name: "生成中"
}, {
    id: "Exception",
    value: 3,
    name: "异常"
}];
//任务的状态
consts.InsightStatus = [{
    id: "Deleted",
    value: 0,
    name: "删除"
}, {
    id: "Normal",
    value: 1,
    name: "正常"
}];

//idMerge的状态
consts.IdMergeStatus = [{
    id: "Deleted",
    value: 0,
    name: "删除"
}, {
    id: "Normal",
    value: 1,
    name: "正常"
}];
//idMerge的dataStatus状态
consts.IdMergeDataStatus = [{
    id: "Deleted",
    value: 0,
    name: "删除"
}, {
    id: "Normal",
    value: 2,
    name: "正常"
}, {
    id: "Generating",
    value: 1,
    name: "生成中"
}, {
    id: "Exception",
    value: 3,
    name: "异常"
}];

//人群组成type
consts.SegmentType = [{
    id: "First",
    value: 1,
    name: "第一方",
    alias: '自定义人群'
}, {
    id: "Third",
    value: 2,
    name: "第三方",
    alias: '自定义人群'
}, {
    id: "Mixture",
    value: 3,
    name: "混合",
    alias: '自定义人群'
}, {
    id: "Upload",
    value: 4,
    name: "第一方",
    alias: '上传人群'
}, {
    id: "Default",
    value: 5,
    name: "第一方",
    alias: '自定义人群'
}, {
    id: "Lookalike",
    value: 7,
    name: "第一方",
    alias: '放大人群'
}];
//全景资料id类型
consts.ExploreIdType = [{
    id: "Official",
    value: 1,
    name: "官网会员"
}, {
    id: "Social",
    value: 2,
    name: "社交会员"
}, {
    id: "CRM",
    value: 3,
    name: "CRM客户"
}, {
    id: "PC",
    value: 4,
    name: "PC设备"
}, {
    id: "Mobile",
    value: 5,
    name: "移动设备"
}];

//标签值类型
consts.TagValueType = [{
    id: "code",
    value: 1,
    name: "代码标签值"
}, {
    id: "constructor",
    value: 2,
    name: "构造器标签值"
}, {
    id: "behavior",
    value: 3,
    name: "构造器标签值"
}, {
    id: "upload",
    value: 4,
    name: "批量文件上传标签标签值"
}, {
    id: "batchDefault",
    value: 8,
    name: "通过选择对象批量新建的标签值"
}];
//全景资料baisc字段
consts.BasicField = [{
    id: "headimg",
    name: "头像图片"
}, {
    id: "userName",
    name: "姓名"
}, {
    id: "gender",
    name: "性别"
}, {
    id: "age",
    name: "年龄"
}];

//全景资料baisc字段
consts.ColType = [{
    id: "percent",
    value: "percent",
    name: "百分比"
}, {
    id: "number",
    value: "number",
    name: "姓名"
}];

consts.ParameterDataType = [{
    id: "Number",
    value: 1,
    name: "数字"
}, {
    id: "Percent",
    value: 11,
    name: "百分比"
}, {
    id: "Text",
    value: 2,
    name: "文本"
}, {
    id: "EncryptedText",
    value: 3,
    name: "加密文本"
}, {
    id: "Date",
    value: 4,
    name: "日期"
}, {
    id: "DateTime",
    value: 5,
    name: "日期时间"
}, {
    id: "Geo",
    value: 6,
    name: "地理定位"
}, {
    id: "Tel",
    value: 7,
    name: "电话"
}, {
    id: "Url",
    value: 8,
    name: "URL"
}, {
    id: "Email",
    value: 9,
    name: "电子邮箱"
}, {
    id: "Option",
    value: 10,
    name: "选项"
}];

consts.DataType = [{
    id: "Number",
    value: 1,
    name: "整数"
}, {
    id: "Percent",
    value: 11,
    name: "百分比"
}, {
    id: "Text",
    value: 2,
    name: "文本"
}, {
    id: "Date",
    value: 4,
    name: "日期"
}, {
    id: "DateTime",
    value: 5,
    name: "日期时间"
}, {
    id: "Geo",
    value: 6,
    name: "地理位置"
}, {
    id: "URL",
    value: 8,
    name: "URL"
}, {
    id: "Email",
    value: 9,
    name: "电子邮件"
}, {
    id: "Option",
    value: 10,
    name: "选项－单选"
}, {
    id: "MultiOption",
    value: 12,
    name: "选项-多选"
}, {
    id: "LongText",
    value: 13,
    name: "长文本"
}, {
    id: "Currency",
    value: 14,
    name: "货币"
}, {
    id: "Decimal",
    value: 15,
    name: "小数"
}];

consts.ValueType = [{
    id: "String",
    value: 1,
    name: "字符"
}, {
    id: "Number",
    value: 2,
    name: "数字"
}, {
    id: "Percent",
    value: 3,
    name: "百分比"
}, {
    id: "Decimal",
    value: 4,
    name: "小数"
}, {
    id: "Date",
    value: 5,
    name: "日期"
}, {
    id: "DataTime",
    value: 6,
    name: "日期时间"
}];

consts.DateTimeUnit = [{
    id: "Day",
    value: "d",
    name: "天"
}, {
    id: "Month",
    value: "M",
    name: "月"
}, {
    id: "Quarter",
    value: "Q",
    name: "季度"
}, {
    id: "Year",
    value: "Y",
    name: "年"
}];

exports.default = consts;
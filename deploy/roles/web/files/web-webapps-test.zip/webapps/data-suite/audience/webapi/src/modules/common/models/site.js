"use strict";

Object.defineProperty(exports, "__esModule", {
	value: true
});
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var siteSechma = new Schema({
	"id": String,
	"name": String, //名称
	"deviceType": String, //站点类型 deviceType
	"type": Number, //网站类型 官方网站等
	//"domains": [String], //网站域名
	"remark": {
		"type": String,
		"maxlength": 250
	}, //备注
	"settleTime": {
		"type": Date,
		"default": Date.now
	},
	"lastChanged": {
		"type": Date,
		"default": Date.now
	},
	"status": {
		"type": Number,
		"default": 1
	}
});

siteSechma.index({
	"id": 1
});
siteSechma.index({
	"name": 1
});

exports.default = mongoose.model("Site", siteSechma);
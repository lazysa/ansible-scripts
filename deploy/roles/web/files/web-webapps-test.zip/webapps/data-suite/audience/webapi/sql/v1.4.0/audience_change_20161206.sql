UPDATE `audience`.`first_party_tag` SET `belonged_table_name`='none' WHERE `id`='FT69';
UPDATE `audience`.`first_party_tag` SET `belonged_table_name`='Baidu' WHERE `id`='FT72';


ALTER TABLE `audience`.`segment_group` 
ADD COLUMN `is_default` TINYINT(4) NOT NULL DEFAULT 0 AFTER `parent_id`;


USE `audience`;

DELIMITER $$

DROP TRIGGER IF EXISTS audience.segment_insert$$
USE `audience`$$
CREATE  TRIGGER segment_insert
BEFORE INSERT ON segment
FOR EACH ROW
BEGIN
 if NEW.id is NULL THEN
  update seq set seq=seq+1  where id="segmentId";
  SELECT seq INTO @seq FROM seq WHERE id="segmentId";
  SET NEW.id = CONCAT('SG',  @seq);
    END IF;
END$$
DELIMITER ;



USE `audience`;

DELIMITER $$

DROP TRIGGER IF EXISTS audience.first_party_tag_insert$$
USE `audience`$$
CREATE  TRIGGER first_party_tag_insert
BEFORE INSERT ON first_party_tag
FOR EACH ROW
BEGIN
 if NEW.id is NULL THEN
  update seq set seq=seq+1  where id="tagId";
  SELECT seq INTO @seq FROM seq WHERE id="tagId";
  SET NEW.id = CONCAT('FT',  @seq);
   END IF;
END$$
DELIMITER ;


USE `audience`;

DELIMITER $$

DROP TRIGGER IF EXISTS audience.first_party_tag_value_insert$$
USE `audience`$$
CREATE  TRIGGER first_party_tag_value_insert
BEFORE INSERT ON first_party_tag_value
FOR EACH ROW
BEGIN
 if NEW.id is NULL THEN
  update seq set seq=seq+1  where id="tagValueId";
  SELECT seq INTO @seq FROM seq WHERE id="tagValueId";
  SET NEW.id = CONCAT('FV',  @seq);
    END IF;
END$$
DELIMITER ;



USE `audience`;

DELIMITER $$

DROP TRIGGER IF EXISTS audience.tag_group_insert$$
USE `audience`$$
CREATE  TRIGGER tag_group_insert
BEFORE INSERT ON tag_group
FOR EACH ROW
BEGIN
 if NEW.id is NULL THEN
  update seq set seq=seq+1  where id="tagGroupId";
  SELECT seq INTO @seq FROM seq WHERE id="tagGroupId";
  SET NEW.id = CONCAT('FTG',  @seq);
  END IF;
END$$
DELIMITER ;



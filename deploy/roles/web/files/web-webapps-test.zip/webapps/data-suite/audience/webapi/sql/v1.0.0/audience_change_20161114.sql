

ALTER TABLE `audience`.`segment_group`
CHANGE COLUMN `id` `id` INT(10) UNSIGNED NOT NULL AUTO_INCREMENT ;

x

'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.updateAndCreate = exports.appendExportList = exports.getThirdExportList = exports.getFirstExportList = undefined;

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _lodash = require('lodash');

var _dataSource = require('../dataSource/dataSource.service');

var _consts = require('../../config/consts');

var _models = require('../common/models');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let Status = _consts.Enums.Status;
let ExportStatus = _consts.Enums.ExportStatus;
let rollerType = _consts.Enums.rollerType;

/**
 * 第一方分发列表
 * @return {*}
 */
let getFirstExportList = exports.getFirstExportList = () => {

    return _models.DataSource.findAll({
        attributes: ['id', 'name'],
        where: {
            rollerType: rollerType.receiver,
            status: Status.Normal
        },
        raw: true
    });
};

/**
 * 第三方分发
 * @param dataSourceId
 * @return {Promise.<void>}
 */
let getThirdExportList = exports.getThirdExportList = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (dataSourceId) {
        let receiveId = yield _models.DataLink.findAll({
            attributes: ['receiverDataHubId'],
            where: {
                providerDataHubId: dataSourceId,
                status: Status.Normal
            },
            raw: true
        });
        return (0, _dataSource.getDataSourceListByIds)(receiveId.map(function (item) {
            return item.receiverDataHubId;
        }));
    });

    return function getThirdExportList(_x) {
        return _ref.apply(this, arguments);
    };
})();

/**
 * 组装export 列表
 * @param data
 * @param segmentId
 * @returns {*}
 */
let appendExportList = exports.appendExportList = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (data, segmentId) {
        let segmentExportList = yield _models.SegmentExport.findAll({
            where: {
                segmentId,
                dataDestinationId: {
                    $in: data.map(function (item) {
                        return item.id;
                    })
                },
                status: {
                    $ne: ExportStatus.Deleted
                }
            },
            raw: true
        });
        data.forEach(function (item) {
            let segmentExportRecord = (0, _lodash.find)(segmentExportList, { dataDestinationId: item.id });
            item = (0, _assign2.default)(item, {
                status: segmentExportRecord && segmentExportRecord.status || ExportStatus.Close,
                expires: segmentExportRecord && JSON.parse(segmentExportRecord.expires) || null,
                isForever: segmentExportRecord && segmentExportRecord.isForever || null
            });
        });
        return data;
    });

    return function appendExportList(_x2, _x3) {
        return _ref2.apply(this, arguments);
    };
})();

let updateAndCreate = exports.updateAndCreate = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (segmentId, dataDestinationId, model) {
        let segmentExportRecord = yield _models.SegmentExport.findOne({
            where: {
                segmentId,
                dataDestinationId
            }
        });
        if (segmentExportRecord && segmentExportRecord.segmentId) {
            return _models.SegmentExport.update(model, {
                where: {
                    segmentId,
                    dataDestinationId
                }
            });
        }
        return _models.SegmentExport.create((0, _assign2.default)({
            segmentId,
            dataDestinationId
        }, model));
    });

    return function updateAndCreate(_x4, _x5, _x6) {
        return _ref3.apply(this, arguments);
    };
})();
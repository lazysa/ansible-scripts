'use strict';

var _sequelize = require('sequelize');

var _sequelize2 = _interopRequireDefault(_sequelize);

var _helper = require('../util/helper');

var _consts = require('../../../config/consts');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Id_merge_report', {
        id: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            defaultValue: null
        },
        segmentId: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'segment_id'
        },
        status: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        },
        dataStatus: {
            type: DataTypes.INTEGER(4),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: 'data_status'
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'created_at'
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'updated_at'
        },
        refreshTime: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'refresh_time'
        },
        errorCode: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'error_code'
        },
        updatePeriod: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _consts.Enums.ReportUpdatePeriod.auto,
            field: 'update_period'
        },
        expires: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _helper.FOREVER_TIME,
            field: 'expires'
        }
    }, {
        tableName: 'id_merge_report',
        timestamps: false

    });
};
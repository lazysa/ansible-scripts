'use strict';

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Seq', {
        id: {
            type: DataTypes.STRING(255),
            allowNull: false,
            autoIncrement: false,
            primaryKey: true,
            defaultValue: null
        },
        seq: {
            type: DataTypes.INTEGER,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 10000
        }

    }, {
        tableName: 'seq',
        timestamps: false
    });
};
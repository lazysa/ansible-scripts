'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
let consts = {};

//系统级别
consts.ProgramerException = {
    code: "E300",
    message: "系统程序执行错误"
};

consts.ParamsInvalid = {
    code: "E302",
    message: "数据验证失败"
};

consts.DataIsNull = {
    code: "E303",
    message: "数据为空"
};

consts.DataException = {
    code: "E304",
    message: "数据异常"
};

//report系列
consts.Report = [{
    name: "ApiQueryError",
    code: "E4101",
    message: "api查询返回错误"
}, {
    name: "ApiServerError",
    code: "E4102",
    message: "api服务器发生错误"
}, {
    name: "ServerNetError",
    code: "E4103",
    message: "和api服务器通信出了问题"
}, {
    name: "NotExistFile",
    code: "E4104",
    message: "服务器端不存在人群文件"
}];

consts.Auth = [{
    name: "RequireLogin",
    code: "E34001",
    message: "需要登陆"
}, {
    name: "RequireToken",
    code: "E34002",
    message: "需要token"
}, {
    name: "Failed",
    code: "E34003",
    message: "文件不是execel格式"
}];

consts.Api = [{
    name: "NoRight",
    code: "E35001",
    message: "无权限"
}, {
    name: "NoInvokeRight",
    code: "E35002",
    message: "api接口无调用权限"
}];

consts.Tag = [{
    name: "SegmentUsed",
    code: "E34113",
    message: "该标签被人群占用,不能删除"
}, {
    name: "CampaignUsed",
    code: "E34119",
    message: "该标签被analytics活动占用,不能删除"
}, {
    name: "SiteUsed",
    code: "E34115",
    message: "该标签被analytics站点占用,不能删除"
}];

consts.TagValue = [{
    name: "SegmentUsed",
    code: "E34118",
    message: "该标签值被人群占用,不能删除"
}, {
    name: "CampaignUsed",
    code: "E34116",
    message: "该标签值被analytics活动占用,不能删除"
}, {
    name: "SiteUsed",
    code: "E34117",
    message: "该标签值被analytics站点占用,不能删除"
}, {
    name: "AtGenerating",
    code: "E34101",
    message: "TagValue生成中"
}, {
    name: "RuleInvlide",
    code: "E34102",
    message: "rule验证失败"
}];

consts.Segment = [{
    name: "Used",
    code: "E34127",
    message: "此人群被占用，不可删除"
}, {
    name: "CampaignOrSiteUsed",
    code: "E34112",
    message: "此人群被Analytics活动或站点占用，不可删除"
}, {
    name: "ExportExist",
    code: "E34109",
    message: "此人群正在分发，不可删除"
}, {
    name: 'FileNotExist',
    code: "E34110",
    message: "人群文件不存在"
}, {
    name: 'IdNotExist',
    code: "E34111",
    message: "人群ID不存在"
}, {
    name: 'UploadError',
    code: "E34111",
    message: "人群上传失败"
}];

consts.Upload = [{
    name: "AcceptCSV",
    code: "E3601",
    message: "仅支持上传csv"
}, {
    name: "FileTooLarge",
    code: "E3602",
    message: "上传文件过大"
}];

consts.TagGroup = [{
    name: "NoOtherGroup",
    code: "E34103",
    message: "无其它标签组，需要初始化"
}, {
    name: "CannotDelete",
    code: "E34104",
    message: "不能删除其它组"
}, {
    name: "HaveChildren",
    code: "E34108",
    message: "该标签组下有子组，不能删除"
}];

consts.SegmentGroup = [{
    name: "NoOtherGroup",
    code: "E34105",
    message: "无其它人群组，需要初始化"
}, {
    name: "CannotDelete",
    code: "E34106",
    message: "不能编辑或删除默认人群分组"
}, {
    name: "NULL",
    code: "E34157",
    message: "报告为空"
}, {
    name: "HaveChildren",
    code: "E34109",
    message: "该人群组下有子组，不能删除"
}];

exports.default = consts;
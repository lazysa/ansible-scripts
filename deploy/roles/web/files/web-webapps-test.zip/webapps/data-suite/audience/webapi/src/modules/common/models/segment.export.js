'use strict';

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

var _sequelize = require('sequelize');

var _sequelize2 = _interopRequireDefault(_sequelize);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Segment_export', {
        id: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            defaultValue: null
        },
        segmentId: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'segment_id'
        },
        dataDestinationId: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'data_destination_id'
        },
        isForever: {
            type: DataTypes.INTEGER(1),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            field: 'is_forever'
        },
        expires: {
            type: DataTypes.JSON,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            set: function (val) {
                try {
                    this.setDataValue('expires', JSON.parse((0, _stringify2.default)(val)));
                } catch (err) {
                    return null;
                }
            },
            get: function (val) {
                try {
                    return this.getDataValue(val);
                } catch (err) {
                    return null;
                }
            }

        },
        status: {
            type: DataTypes.INTEGER(1),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'created_at'
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'updated_at'
        }
    }, {
        tableName: 'segment_export'
    });
};
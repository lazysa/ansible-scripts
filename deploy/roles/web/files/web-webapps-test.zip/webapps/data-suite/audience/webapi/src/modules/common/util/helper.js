'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.convertFileEncoding = exports.isProd = exports.FOREVER_DATE = exports.FOREVER_TIME = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

// /**
//  * 添加任务
//  * @param keyId
//  * @param keyType
//  * @return {*}
//  */
// export function addReportTask({keyId,keyType}) {
//     const url = `${config.reportBusinessApiPath}/addtask`;
//     return getReportBusinessApi(url,{
//         keyId,
//         keyType,
//         uuid: uuid.v1()
//     });
// }

let convertFileEncoding = exports.convertFileEncoding = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (fileName, sourceEncodng, targetEncoding) {
        const ENCODINGS = ['utf8', 'gb2312'];
        if (!ENCODINGS.includes(sourceEncodng) || !ENCODINGS.includes(targetEncoding)) return;
        let resFilePath = _path2.default.join(_config2.default.fileDir, `${_uuid2.default.v1()}${_path2.default.basename(fileName)}`);
        _fs2.default.createReadStream(fileName).pipe(_iconvLite2.default.decodeStream(sourceEncodng)).pipe(_iconvLite2.default.encodeStream(targetEncoding)).pipe(_fs2.default.createWriteStream(resFilePath));
        return resFilePath;
    });

    return function convertFileEncoding(_x, _x2, _x3) {
        return _ref.apply(this, arguments);
    };
})();

exports.dateIsForever = dateIsForever;
exports.getRequestOptions = getRequestOptions;
exports.wrapBody = wrapBody;
exports.getJoiErrorMessage = getJoiErrorMessage;
exports.getAnalyticsApi = getAnalyticsApi;
exports.getDataAssetsApi = getDataAssetsApi;
exports.getReportBusinessApi = getReportBusinessApi;
exports.getReportApi = getReportApi;
exports.getData = getData;
exports.getDownloadStream = getDownloadStream;
exports.download = download;
exports.formatData = formatData;

var _errors = require('../core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _consts = require('../../../config/consts');

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _request = require('request');

var _request2 = _interopRequireDefault(_request);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _jssha = require('jssha');

var _jssha2 = _interopRequireDefault(_jssha);

var _uuid = require('uuid');

var _uuid2 = _interopRequireDefault(_uuid);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _lodash = require('lodash');

var _log = require('../core/log');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let { responseStatusMap } = _consts.OptionMaps;

const FOREVER_TIME = exports.FOREVER_TIME = '2199-01-01 00:00:00';
const FOREVER_DATE = exports.FOREVER_DATE = '2199-01-01';
const isProd = exports.isProd = _config2.default.env === 'production';

function dateIsForever(currentDate) {
    return Number((0, _moment2.default)(currentDate).format('YYYY-MM-DD').search(new RegExp(FOREVER_DATE)) > -1);
}

function getRequestOptions(options) {
    const baseOptions = {
        method: "post",
        json: true,
        // proxy: isProd ? null : config.fiddlerProxy,
        timeout: _config2.default.apiTimeout,
        forever: true,
        time: true
    };
    return (0, _assign2.default)(baseOptions, options);
}

function wrapBody(error, data) {
    let status = (0, _lodash.pick)(responseStatusMap.normal, ['code', 'message']);
    if (error) {
        _log.log.error({
            type: "Audience-WebApi",
            err: error
        });
        status = {
            code: error.code ? error.code : 'E300',
            message: error.message
        };
        return {
            status: status
        };
    }
    return {
        data: data,
        status: status
    };
}

function getJoiErrorMessage(error) {
    return error.details.map(function (n) {
        return n.message;
    });
}

let baseRequest = _request2.default.defaults({
    pool: {
        maxSockets: _config2.default.poolSize
    }
});

function getHash(timestamp, randomStr, apiSecret) {
    let shaObj = new _jssha2.default("SHA-512", "TEXT");
    shaObj.update('apiSecret=' + apiSecret + '&randomStr=' + randomStr + '&timestamp=' + timestamp);
    return shaObj.getHash("HEX");
}

function getHeaders(apiSecret) {
    let timestamp = Date.now();
    let randomStr = Math.random().toString(36).substr(2, 15);
    let token = getHash(timestamp, randomStr, apiSecret);
    return {
        timestamp: timestamp,
        randomStr: randomStr,
        token: token
    };
}

/**
 * analytics接口
 * @param url
 * @param body
 * @param options
 * @return {*}
 */
function getAnalyticsApi(url, body, options = {}) {
    return getData(url, body, (0, _assign2.default)(options, {
        headers: getHeaders(_config2.default.analyticsApiSecret)
    }));
}

/**
 * data-assets接口
 * @param url
 * @param body
 * @param options
 * @return {*}
 */
function getDataAssetsApi(url, body, options = {}) {
    return getData(url, body, (0, _assign2.default)(options, {
        headers: getHeaders(_config2.default.dataAssetsApiSecret)
    }));
}

/**
 * reportBusiness接口
 * @param url
 * @param body
 * @param options
 * @return {*}
 */
function getReportBusinessApi(url, body, options = {}) {
    return getData(url, body, (0, _assign2.default)(options, {
        headers: getHeaders(_config2.default.reportBusinessApiSecret)
    }));
}

/**
 * report接口
 * @param url
 * @param body
 * @param options
 * @return {*}
 */
function getReportApi(url, body, options = {}) {
    console.log(url);
    return getData(url, body, (0, _assign2.default)(options, {}));
}

function getData(url, reqBody, options = {}) {
    return new _promise2.default(function (resolve, reject) {
        _log.requestLog.info({
            url,
            reqBody
        });
        baseRequest((0, _assign2.default)({
            url: url,
            body: reqBody
        }, getRequestOptions(options)), function (err, res, body) {
            _log.log.info({
                type: "ServerApi",
                err: err,
                code: res ? res.statusCode : 0,
                url: url,
                elapsedTime: res ? res.elapsedTime : 0
            });
            if (err) {
                reject(new _errors2.default.ReportServerNetError(err.message));
            } else {
                if (res.statusCode === 200) {
                    if (body.status && body.status.code === "E0") {
                        resolve(body.data);
                    } else {
                        reject(new _errors2.default.ReportApiQueryError(body.status && body.status.message || "api query error"));
                    }
                } else {
                    reject(new _errors2.default.ReportApiServerError(res.statusCode));
                }
            }
        });
    });
}

/**
 * 获取流结果
 * @param url
 * @param reqBody
 * @param options
 * @return {*}
 */
function getDownloadStream(url, reqBody, options) {
    return (0, _request2.default)((0, _assign2.default)({
        url: url,
        body: reqBody
    }, getRequestOptions(options)));
}

function download(url, reqBody, options, { filePath, onDataCallback }) {
    let writestream = _fs2.default.createWriteStream(filePath);
    return new _promise2.default(function (resolve, reject) {
        (0, _request2.default)((0, _assign2.default)({
            url: url,
            body: reqBody
        }, getRequestOptions(options)), function (err, res, body) {
            _log.log.info({
                type: "ServerApi",
                err: err,
                code: res ? res.statusCode : 0,
                url: url,
                elapsedTime: res ? res.elapsedTime : 0
            });
            writestream.end();
            if (err) {
                reject(new _errors2.default.ReportServerNetError(err.message));
            } else {
                if (body) {
                    resolve(true);
                } else {
                    reject(new _errors2.default.ReportApiQueryError("file not exist"));
                }
            }
        }).on('data', chunk => {
            try {
                console.log(chunk);
                if (!chunk) return;
                let tempStr = chunk;
                if (onDataCallback && typeof onDataCallback === 'function') {
                    tempStr = onDataCallback(chunk);
                }
                writestream.write(tempStr);
            } catch (err) {
                console.log(err);
            }
        });
    });
}

function formatData(data, format, precision) {
    let result = null;
    if (data !== 0 && !data) {
        result = '';
    } else {
        switch (format) {
            case 'string':
                result = String(data);
                break;

            case 'number':
                result = Number(data);
                break;

            case 'percent':
                result = (data * 100).toFixed(2) + '%';
                break;

            case 'decimal':
                result = parseFloat(data.toFixed(precision || 2));
                break;
        }
    }

    return result;
}
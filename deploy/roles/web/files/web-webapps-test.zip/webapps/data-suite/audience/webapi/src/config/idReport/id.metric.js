"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
let idMetrics = [{
    "id": "useridCount",
    "name": "原始ID数",
    "vtype": "number",
    "isDefault": 1
}, {
    "id": "ccidCount",
    "name": "归并用户数",
    "vtype": "number",
    "isDefault": 0
}, {
    "id": "ccidPercentage",
    "name": "归并比例",
    "vtype": "percent",
    "isDefault": 0
}, {
    "id": "pairedCcid",
    "name": "打通用户数",
    "vtype": "number",
    "isDefault": 0
}, {
    "id": "useridAvg",
    "name": "人均原始ID数",
    "vtype": "decimal",
    "isDefault": 0
}, {
    "id": "throughPercentage",
    "name": "打通率",
    "vtype": "percent",
    "isDefault": 0
}];

exports.default = idMetrics;
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _uuid = require('uuid');

var _uuid2 = _interopRequireDefault(_uuid);

var _helper = require('../util/helper');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class ReportBusinessApi {
    constructor() {
        this.baseUrl = _config2.default.reportBusinessApiPath;
    }

    addReportTask({ keyId, keyType }) {
        let url = `${this.baseUrl}/addtask`;
        return (0, _helper.getReportBusinessApi)(url, {
            keyId,
            keyType,
            uuid: _uuid2.default.v1()
        });
    }
}

exports.default = new ReportBusinessApi();
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.dimensionMetaList = exports.actionMetricList = exports.actionDimensionAttrList = exports.businessActionList = exports.businessDateDimensionList = exports.businessList = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _consts = require('../../config/consts');

var _helper = require('../common/util/helper');

var _api = require('../common/api');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

//业务中心API
let businessList = exports.businessList = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = yield _api.DataServiceApi.getBusinessList();
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function businessList(_x) {
        return _ref.apply(this, arguments);
    };
})();

//时间维度API
let businessDateDimensionList = exports.businessDateDimensionList = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        let { businessId } = ctx.request.query;
        try {
            data = yield _api.DataServiceApi.getBusinessDataDimensionList(businessId);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function businessDateDimensionList(_x2) {
        return _ref2.apply(this, arguments);
    };
})();
//行为维度API
let businessActionList = exports.businessActionList = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        let { businessId } = ctx.request.query;
        try {
            data = yield _api.DataServiceApi.getBusinessActionList(businessId);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function businessActionList(_x3) {
        return _ref3.apply(this, arguments);
    };
})();

//条件维度API
let actionDimensionAttrList = exports.actionDimensionAttrList = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        let { subjectId, actionId, businessId } = ctx.request.query;

        try {
            data = yield _api.DataServiceApi.getActionDimensionAttrList({
                subjectId,
                actionId,
                businessId
            });
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function actionDimensionAttrList(_x4) {
        return _ref4.apply(this, arguments);
    };
})();
//指标API
let actionMetricList = exports.actionMetricList = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        let { subjectId, actionId, businessId } = ctx.request.query;

        try {
            data = yield _api.DataServiceApi.getActionMetricList({
                subjectId,
                actionId,
                businessId
            });
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function actionMetricList(_x5) {
        return _ref5.apply(this, arguments);
    };
})();
//条件维度值API
let dimensionMetaList = exports.dimensionMetaList = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        let { dimensionAttribute } = ctx.request.query;

        try {
            data = yield _api.DataServiceApi.getDimensionMetaList(dimensionAttribute);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function dimensionMetaList(_x6) {
        return _ref6.apply(this, arguments);
    };
})();
/*
Navicat MySQL Data Transfer

Source Server         : 192.168.10.40_3306
Source Server Version : 50711
Source Host           : 192.168.10.40:3306
Source Database       : audience

Target Server Type    : MYSQL
Target Server Version : 50711
File Encoding         : 65001

Date: 2017-07-19 17:15:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for chart_type
-- ----------------------------
DROP TABLE IF EXISTS `chart_type`;
CREATE TABLE `chart_type` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `used_for_multiple_tag` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of chart_type
-- ----------------------------
INSERT INTO `chart_type` VALUES ('bar', '条形图', '1');
INSERT INTO `chart_type` VALUES ('column', '柱图', '1');
INSERT INTO `chart_type` VALUES ('doughnut', '环形图', '0');
INSERT INTO `chart_type` VALUES ('line', '折线图', '0');
INSERT INTO `chart_type` VALUES ('map', '地图(城市)', '1');
INSERT INTO `chart_type` VALUES ('pie', '饼图', '0');
INSERT INTO `chart_type` VALUES ('provMap', '地图(省份)', '1');
INSERT INTO `chart_type` VALUES ('radar', '雷达图', '1');
INSERT INTO `chart_type` VALUES ('tagCloud', '标签云', '1');
SET FOREIGN_KEY_CHECKS=1;

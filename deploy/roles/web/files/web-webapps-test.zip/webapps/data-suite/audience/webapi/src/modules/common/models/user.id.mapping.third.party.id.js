'use strict';

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('User_id_mapping_third_party_id', {
        id: {
            type: DataTypes.INTEGER,
            allowNull: false,
            autoIncrement: true,
            primaryKey: true,
            defaultValue: null
        },
        firstUserIdTypeName: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            field: 'first_user_id_type_name',
            defaultValue: null
        },
        thirdUserIdTypeName: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            field: 'third_user_id_type_name',
            defaultValue: null
        },
        dataSourceId: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'data_source_id'
        },
        status: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        }
    }, {
        tableName: 'user_id_mapping_third_party_id',
        timestamps: false
    });
};
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _dimension = require('./dimension.controller');

var ctrl = _interopRequireWildcard(_dimension);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
    prefix: '/ba'
});

//常量
router.get('/business/list', ctrl.businessList);
router.get('/business_date_dimension/list', ctrl.businessDateDimensionList);
router.get('/business_action_list', ctrl.businessActionList);
router.get('/action_dimension_attr/list', ctrl.actionDimensionAttrList);
router.get('/action_metric/list', ctrl.actionMetricList);
router.get('/dimension_meta/list', ctrl.dimensionMetaList);

exports.default = router;
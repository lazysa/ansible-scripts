ALTER TABLE `audience`.`third_party_tag_value`
ADD COLUMN `remark` VARCHAR(255) NULL AFTER `display_sequence`;

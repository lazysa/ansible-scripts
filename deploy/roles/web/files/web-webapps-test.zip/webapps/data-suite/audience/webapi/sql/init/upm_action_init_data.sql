
insert into privilege (name,parent_id,application_id) values ('标签管理',0,3);
set @last_privilege_id = LAST_INSERT_ID();
insert into action (privilege_id,name,type) VALUES (@last_privilege_id,'app.tag',1);


insert into privilege (name,parent_id,application_id) values ('标签管理-第一方标签',@last_privilege_id,3);
set @last_privilege_id = LAST_INSERT_ID();
insert into action (privilege_id,name,type) VALUES (@last_privilege_id,'app.tag.first',1);


insert into privilege (name,parent_id,application_id) values ('人群管理',0,3);
set @last_privilege_id = LAST_INSERT_ID();
insert into action (privilege_id,name,type) VALUES (@last_privilege_id,'app.segment',1);
insert into action (privilege_id,name,type) VALUES (@last_privilege_id,'audience.segment.page',2);
insert into action (privilege_id,name,type) VALUES (@last_privilege_id,'audience.segment.create',2);
insert into action (privilege_id,name,type) VALUES (@last_privilege_id,'audience.segment.delete',2);
insert into action (privilege_id,name,type) VALUES (@last_privilege_id,'audience.segment.access',2);

insert into privilege (name,parent_id,application_id) values ('人群洞察',0,3);
set @last_privilege_id = LAST_INSERT_ID();
insert into action (privilege_id,name,type) VALUES (@last_privilege_id,'app.insight.tag',1);

insert into privilege (name,parent_id,application_id) values ('全景资料',0,3);
set @last_privilege_id = LAST_INSERT_ID();
insert into action (privilege_id,name,type) VALUES (@last_privilege_id,'app.explore.identification',1);

DROP TABLE IF EXISTS `tag_value_original`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tag_value_original` (
  `tag_value_id` varchar(255) NOT NULL,
  `original_id` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

Insert into tag_value_original select id,value_original_id,status,created_at,updated_at from first_party_tag_value where value_original_id != ""







DROP TABLE IF EXISTS `insight_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insight_field` (
  `id` varchar(255) NOT NULL DEFAULT '0',
  `name` varchar(255) DEFAULT NULL,
  `category` int(11) NOT NULL,
  `data_source_id` int(11) DEFAULT NULL,
  `col_num` int(11) NOT NULL,
  `col_type` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`col_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insight_field`
--

/*!40000 ALTER TABLE `insight_field` DISABLE KEYS */;
--INSERT INTO `insight_field` VALUES ('uv','识别人数',1,NULL,1,0),('percentage','人群占比',1,NULL,2,1),('featurePercentage','人群特征占比',1,NULL,3,1),('featurePercentage','人群特征占比',2,1,4,1);






'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _exploreController = require('./explore.controller.js');

var ctrl = _interopRequireWildcard(_exploreController);

var _exploreFilter = require('./explore.filter.js');

var filter = _interopRequireWildcard(_exploreFilter);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
  prefix: '/explore'
});
/**
 * segmentId 人群id
 * type 什么类型的用户id
 * 1 会员id
 * 2 社交id
 * 3 crmid
 * 4 pc id
 * 5 mobile id
 */

router.get('/:segmentId/:type/pages', filter.pages, ctrl.exploreList);

router.get('/basic/:exploreId', ctrl.getBasic);

router.post('/details/:exploreId', filter.details, ctrl.getDetails);

router.get('/behaviourType/:exploreId/list', ctrl.behaviourTypeList);

exports.default = router;
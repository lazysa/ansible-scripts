'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.remove = exports.update = exports.create = exports.list = undefined;

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _lodash = require('lodash');

var _helper = require('../common/util/helper');

var _segmentGroupService = require('./segmentGroup.service.js');

var segmentGroupService = _interopRequireWildcard(_segmentGroupService);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let list = exports.list = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let { where } = ctx.state;
            data = yield segmentGroupService.list();

            let groupCountList = yield segmentGroupService.getSegmentCountByGroupList(where);
            if (groupCountList) {
                for (let item of data) {
                    let segmentCountItem = (0, _lodash.find)(groupCountList, function (z) {
                        return z.segmentGroupId == item.id;
                    });
                    item.segmentCount = segmentCountItem ? segmentCountItem.segmentCount : 0;
                }
            }

            let { isTreeConstructor } = ctx.request.query;

            if (isTreeConstructor) {
                let parentIdGroup = (0, _lodash.groupBy)(data, 'parentId');
                data = segmentGroupService.constructorData(parentIdGroup['null'] || [], parentIdGroup);
            }
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function list(_x) {
        return _ref.apply(this, arguments);
    };
})();

let create = exports.create = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let { parentId } = body;
            let sequence = yield segmentGroupService.updateSequence(null, parentId);
            data = yield segmentGroupService.create((0, _assign2.default)(body, { sequence }));
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function create(_x2) {
        return _ref2.apply(this, arguments);
    };
})();

let update = exports.update = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let id = ctx.params.segmentGroupId;
            let { parentId, afterId } = body;

            let isDefaultGroup = yield segmentGroupService.isDefaultGroup(id);
            if (isDefaultGroup) {
                throw new _errors2.default.SegmentGroupCannotDelete();
            }

            let sequence = yield segmentGroupService.updateSequence(id, parentId, afterId);

            data = yield segmentGroupService.update(id, (0, _assign2.default)(body, { sequence }));
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function update(_x3) {
        return _ref3.apply(this, arguments);
    };
})();

let remove = exports.remove = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let id = ctx.params.segmentGroupId;
            let isDefaultGroup = yield segmentGroupService.isDefaultGroup(id);
            if (isDefaultGroup) {
                throw new _errors2.default.SegmentGroupCannotDelete();
            }
            let isHaveChildren = yield segmentGroupService.isHaveChildren(id);
            if (isHaveChildren) {
                throw new _errors2.default.SegmentGroupHaveChildren();
            }
            let result = yield segmentGroupService.removeSegmentToOther(id);
            if (result) {
                data = yield segmentGroupService.remove(id);
            } else {
                throw new _errors2.default.SegmentGroupNoOtherGroup();
            }
            // data = await segmentGroupService.remove(id);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function remove(_x4) {
        return _ref4.apply(this, arguments);
    };
})();
'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});

var _mongoose = require('mongoose');

var _mongoose2 = _interopRequireDefault(_mongoose);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let Schema = _mongoose2.default.Schema;

let schema = new Schema({
	'id': String,
	'name': String,
	// 'editable': { //是否可编辑
	// 	'type': Number,
	// 	'default': 1
	// },
	supportBusinessData: {
		'type': Number,
		'default': 1
	},
	reportMapId: String, //映射的reportid 这个之后report应该读取业务表的字段保存数据
	'settleTime': {
		'type': Date,
		'default': Date.now
	},
	'lastChanged': {
		'type': Date,
		'default': Date.now
	},
	'status': {
		'type': Number,
		'default': 1
	}
});

schema.index({
	'id': 1
});

schema.index({
	"name": 1
});

exports.default = _mongoose2.default.model('MetaObject', schema);
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _config = require('../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _helper = require('../util/helper');

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

class AnalyticsWebApi {
    constructor() {
        this.baseUrl = _config2.default.analyticsApiPath;
    }

    /**
     * 判断标签是否被analytics活动或站点占用
     * @param tagId
     */
    isTagUsedByCampaignOrSite(tagId) {
        var _this = this;

        return (0, _asyncToGenerator3.default)(function* () {
            if (!_this.baseUrl) return false;
            let url = `${_this.baseUrl}/api/v1/business/tag/occupied`;
            let srcData = yield (0, _helper.getAnalyticsApi)(url, [tagId]);
            if (srcData && srcData[tagId] && srcData[tagId]['occupied']) {
                return srcData[tagId];
            }
            return false;
        })();
    }

    /**
     * 判断人群是否被analytics用去关联活动
     */
    isSegmentUsedByAnalytics(segmentId) {
        var _this2 = this;

        return (0, _asyncToGenerator3.default)(function* () {
            let defaultReturn = {
                campaign: [],
                site: []
            };
            if (!_this2.baseUrl) return defaultReturn;
            let url = `${_this2.baseUrl}/api/v1/business/segment/occupied`;
            let srcData = yield (0, _helper.getAnalyticsApi)(url, [segmentId]);
            if (srcData && srcData[segmentId] && srcData[segmentId]['occupied']) {
                return (0, _assign2.default)(defaultReturn, srcData[segmentId]);
            }
            return defaultReturn;
        })();
    }

    /**
     * 活动效果报告
     * @param body
     * @return {*}
     */
    getCampaignSegmentReport(body) {
        let url = `${this.baseUrl}/campaign/report/audience/segment`;
        return (0, _helper.getAnalyticsApi)(url, body);
    }

    /**
     * 活动效果分析分页
     * @param body
     * @return {*}
     */
    getCampaignSegmentReportPages(body) {
        let url = `${this.baseUrl}/campaign/report/audience/segment/pages`;
        return (0, _helper.getAnalyticsApi)(url, body);
    }

    /**
     * 活动效果分析时间
     * @param body
     * @return {*}
     */
    getCampaignSegmentReportTime(body) {
        let url = `${this.baseUrl}/campaign/report/audience/segment/time`;
        return (0, _helper.getAnalyticsApi)(url, body);
    }

    /**
     * 活动效果下载
     * @param body
     * @return {*}
     */
    getCampaignSegmentReportDownload(body) {
        var _this3 = this;

        return (0, _asyncToGenerator3.default)(function* () {
            let url = `${_this3.baseUrl}/campaign/report/audience/segment/download`;
            let token = yield (0, _helper.getAnalyticsApi)(url, body);
            let downloadUrl = `${_this3.baseUrl}/fileToken/${token}/downloadFile`;
            let filePath = _path2.default.join(_config2.default.fileDir, './segmentCampaignReport.xlsx');
            yield (0, _helper.download)(downloadUrl, {}, { method: 'get' }, { filePath });
            return filePath;
        })();
    }

    /**
     * 活动指标
     * @return {*}
     */
    campaignMetrics() {
        let url = `${this.baseUrl}/metrics/campaign`;
        return (0, _helper.getAnalyticsApi)(url, {}, { method: 'get' });
    }
}
exports.default = new AnalyticsWebApi();
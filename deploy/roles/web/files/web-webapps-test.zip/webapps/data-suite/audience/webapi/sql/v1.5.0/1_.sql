ALTER TABLE `audience`.`first_party_tag`
ADD COLUMN `coverage` INT(10) NULL COMMENT '标签的覆盖人数' AFTER `remark`;

ALTER TABLE `audience`.`first_party_tag`
ADD COLUMN `refresh_time` DATETIME NULL AFTER `expires`;



ALTER TABLE `audience`.`third_party_tag`
CHANGE COLUMN `data_source_id` `data_source_id` INT(10) NULL DEFAULT NULL ;

ALTER TABLE `audience`.`third_party_tag_value`
CHANGE COLUMN `data_source_id` `data_source_id` INT(10) NULL DEFAULT NULL ;



CREATE TABLE `chart_type` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `used_for_multiple_tag` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `chart_type` VALUES ('bar','条形图',1),('column','柱图',1),('doughnut','环形图',0),('map','地图(城市)',1),('pie','饼图',0),('provMap','地图(省份)',1),('radar','雷达图',1),('tagCloud','标签云',1);



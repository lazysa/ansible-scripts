'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.download = exports.getSegmentListByIds = exports.removeCampaignReportBySegmentId = exports.removeIdMergeBySegmentId = exports.removeInsightBySegmentId = exports.remove = exports.isUploadSegmentUsedBySegment = exports.shouldRemoveSegment = exports.updateInsightList = exports.updateInsight = exports.updateIdMergeReport = exports.updateCampaignReport = exports.convertIdToName = exports.appendSegmentRulesMap = exports.dealWithObj = exports.appendIdAndStatus = exports.updateTagUpdatePeriodBySegmentId = exports.update = exports.shouldUpdateDateStatus = exports.getDataSourceDetails = exports.getDataSourceListByIds = exports.queryCampaignReport = exports.queryIdMergeReport = exports.queryInsight = exports.query = exports.createCampaignReport = exports.createIdMergeReport = exports.createInsight = exports.create = exports.getRulesOfUploadSegment = exports.uploadFileToS3 = exports.uploadFileToHDFS = exports.uploadSegment = exports.getWhere = exports.count = exports.pages = exports.getAnalyticsReportDefaultSegmentList = exports.getSegmentBaseList = exports.allList = exports.normalList = exports.firstList = exports.firstAndUploadList = exports.getMappingUserIdList = exports.createDefaultSegmentByDimension = exports.createUploadSegmentTagAndTagValue = exports.firstAllList = undefined;

var _extends2 = require('babel-runtime/helpers/extends');

var _extends3 = _interopRequireDefault(_extends2);

var _is = require('babel-runtime/core-js/object/is');

var _is2 = _interopRequireDefault(_is);

var _promise = require('babel-runtime/core-js/promise');

var _promise2 = _interopRequireDefault(_promise);

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let firstAndUploadList = exports.firstAndUploadList = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (segmentGroupId, where = {}, keywords) {

        where = (0, _assign2.default)(where, {
            type: {
                $in: [SegmentType.First, SegmentType.Upload, SegmentType.Default]
            },
            status: {
                $ne: Status.Deleted
            }
        });
        where = getWhere(where, keywords);

        return getSegmentBaseList(segmentGroupId, where);
    });

    return function firstAndUploadList(_x8) {
        return _ref5.apply(this, arguments);
    };
})();

/**
 * 仅仅第一方和上传人群list接口
 * @param segmentGroupId
 * @param where
 * @param keywords
 * @return {Promise.<*>}
 */


let firstList = exports.firstList = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (segmentGroupId, where = {}, keywords) {
        /*    if (keywords) {
         Object.assign(where,{
         $or: [{
         id: {
         $like: `%${keywords}%`
         }
         },{
         name: {
         $like: `%${keywords}%`
         }
         }]
          })
         }*/
        where = getWhere(where, keywords);
        where = (0, _assign2.default)(where, {
            type: {
                $in: [SegmentType.First, SegmentType.Upload]
            }
        });
        return getSegmentBaseList(segmentGroupId, where);
    });

    return function firstList(_x9) {
        return _ref6.apply(this, arguments);
    };
})();

/**
 * 查询人群列表的基础接口
 * @param segmentGroupId
 * @param where
 * @return {Promise.<*>}
 */
let getSegmentBaseList = exports.getSegmentBaseList = (() => {
    var _ref9 = (0, _asyncToGenerator3.default)(function* (segmentGroupId, where) {
        if (segmentGroupId !== 'all') {
            (0, _assign2.default)(where, {
                segmentGroupId
            });
        } else {
            let allSegmentGroupList = yield (0, _segmentGroup.list)();
            (0, _assign2.default)(where, {
                segmentGroupId: {
                    $in: allSegmentGroupList.map(function (z) {
                        return z.id;
                    })
                }
            });
        }
        return _models.Segment.findAll({
            attributes: ['id', 'name', 'dataStatus', 'segmentGroupId'],
            order: [['createdAt', 'DESC']],
            where,
            raw: true
        });
    });

    return function getSegmentBaseList(_x14, _x15) {
        return _ref9.apply(this, arguments);
    };
})();

/**
 * 获取analytics默认配置的流量切片报告的人群
 * @return {Promise.<*>}
 */


let getAnalyticsReportDefaultSegmentList = exports.getAnalyticsReportDefaultSegmentList = (() => {
    var _ref10 = (0, _asyncToGenerator3.default)(function* () {
        return _models.AnalyticsReportDefaultSegment.findAll({
            where: {
                status: Status.Normal
            },
            raw: true
        });
    });

    return function getAnalyticsReportDefaultSegmentList() {
        return _ref10.apply(this, arguments);
    };
})();

/**
 * 上传人群文件到HDFS上
 */

let uploadFileToHDFS = exports.uploadFileToHDFS = (() => {
    var _ref13 = (0, _asyncToGenerator3.default)(function* (filePath) {
        try {
            let HDFSDir = `${HDFSconfig.path}/${(0, _moment2.default)().format("YYYY/MM/DD/HH/mm")}`;
            let HDFSPath = `${HDFSDir}/${filePath}`;
            yield forkChildProcess(`hdfs dfs -mkdir -p ${HDFSDir} && hdfs dfs -put ${_path2.default.join(_config2.default.fileDir, `./${filePath}`)} ${HDFSPath}`);
            return {
                flag: _uuid2.default.v1(),
                HDFSPath
            };
        } catch (err) {
            throw new _errors2.default.SegmentUploadError();
        }
    });

    return function uploadFileToHDFS(_x17) {
        return _ref13.apply(this, arguments);
    };
})();

/**
 * 上传人群文件到s3
 * @param filePath
 */

let appendSegmentRulesMap = exports.appendSegmentRulesMap = (() => {
    var _ref23 = (0, _asyncToGenerator3.default)(function* () {
        let segmentList = yield getAllNormalSegmentList();
        let dataSourceList = yield (0, _dataSource.list)();
        return {
            segmentMap: ListToMap(segmentList),
            dataSourceMap: ListToMap(dataSourceList)
        };
    });

    return function appendSegmentRulesMap() {
        return _ref23.apply(this, arguments);
    };
})();

/**
 * 吧人群规则中id转换成name，同时添加status,dataStatus,tagIsNormal,valueIsNormal
 * @param rules
 */


/**
 * 更新活动报告
 * @param segmentId
 * @param isOpenCampaignReport
 * @return {Promise.<void>}
 */
let updateCampaignReport = exports.updateCampaignReport = (() => {
    var _ref25 = (0, _asyncToGenerator3.default)(function* (segmentId, isOpenCampaignReport) {
        let model = {
            status: isOpenCampaignReport ? Status.Normal : Status.Deleted
        };

        let oldCampaignReport = yield _models.CampaignReport.findOne({
            where: {
                segmentId
            }
        });
        if (oldCampaignReport) {
            _models.CampaignReport.update(model, {
                where: {
                    segmentId
                }
            });
        } else if (isOpenCampaignReport) {
            yield _models.CampaignReport.create({
                segmentId
            });
        }
    });

    return function updateCampaignReport(_x29, _x30) {
        return _ref25.apply(this, arguments);
    };
})();

/**
 * 更新idMergr报告
 * @param segmentId
 * @param isOpenIdMerge
 * @param shouldUpdateToGenerating
 * @param updatePeriod
 * @param expires
 */


let updateIdMergeReport = exports.updateIdMergeReport = (() => {
    var _ref26 = (0, _asyncToGenerator3.default)(function* (segmentId, isOpenIdMerge, shouldUpdateToGenerating, updatePeriod, expires) {
        let model = {
            status: isOpenIdMerge ? IdMergeStatus.Normal : IdMergeStatus.Deleted,
            updatedAt: _models.sequelize.fn('NOW')
        };
        if (isOpenIdMerge) {
            (0, _assign2.default)(model, {
                updatePeriod,
                expires
            });
        }
        if (shouldUpdateToGenerating) {
            (0, _assign2.default)(model, {
                dataStatus: IdMergeDataStatus.Generating
            });
        }
        let oldIdMerge = yield _models.IdMergeReport.findOne({
            where: {
                segmentId
            }
        });
        if (oldIdMerge) {
            _models.IdMergeReport.update(model, {
                where: {
                    segmentId
                }
            });
        } else if (isOpenIdMerge) {
            yield _models.IdMergeReport.create({
                updatePeriod,
                expires,
                segmentId
            });
        }
    });

    return function updateIdMergeReport(_x31, _x32, _x33, _x34, _x35) {
        return _ref26.apply(this, arguments);
    };
})();

/**
 * 手动更新人群洞察人群的状态
 * @param segmentId
 * @param category
 * @param dataSourceId
 */


let updateInsight = exports.updateInsight = (() => {
    var _ref27 = (0, _asyncToGenerator3.default)(function* (segmentId, category, dataSourceId) {
        let where = {
            category,
            segmentId
        };
        if (dataSourceId) {
            (0, _assign2.default)(where, { dataSourceId });
        }
        let currentInsightRecord = yield _models.InsightInfo.findOne({
            where
        });
        if (currentInsightRecord) {
            yield addReportInsightTask(currentInsightRecord.id);
        }
        return _models.InsightInfo.update({
            startTask: TaskStatus.run,
            updatedAt: _models.sequelize.fn('NOW')
        }, {
            where
        });
    });

    return function updateInsight(_x36, _x37, _x38) {
        return _ref27.apply(this, arguments);
    };
})();

/**
 * 更新人群同时更新洞察报告
 * @param segmentId
 * @param insight
 * @param shouldUpdateToGenerating
 * @param updatePeriod
 * @param expires
 */


exports.uploadFile = uploadFile;
exports.getFileMD5 = getFileMD5;
exports.createInsightModel = createInsightModel;
exports.getSegmentRulesIncludeAndExclude = getSegmentRulesIncludeAndExclude;
exports.getAllNormalSegmentList = getAllNormalSegmentList;
exports.onDataCallback = onDataCallback;
exports.addReportSegmentTask = addReportSegmentTask;
exports.addReportInsightTask = addReportInsightTask;
exports.addTagValueUploadTask = addTagValueUploadTask;

var _lodash = require('lodash');

var _segment = require('./segment.filter');

var _consts = require('../../config/consts');

var _models = require('../common/models');

var _tag = require('../tag/tag.service');

var _tagValue = require('../tagValue/tagValue.service');

var _dataSource = require('../dataSource/dataSource.service');

var _insight = require('../insight/insight.service');

var _segmentGroup = require('../segmentGroup/segmentGroup.service');

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _api = require('../common/api');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _crypto = require('crypto');

var _crypto2 = _interopRequireDefault(_crypto);

var _uuid = require('uuid');

var _uuid2 = _interopRequireDefault(_uuid);

var _os = require('os');

var _os2 = _interopRequireDefault(_os);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var _immutable = require('immutable');

var _immutable2 = _interopRequireDefault(_immutable);

var _child_process = require('child_process');

var _child_process2 = _interopRequireDefault(_child_process);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _awsSdk = require('aws-sdk');

var _segmentTagValue = require('../../config/segmentRule/segment.tagValue.rules');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const {
    Status, SegmentType, InsightStatus,
    InsightDataStatus, SegmentStatus,
    TagValueStatus, TagType, TagStatus,
    ExportStatus, OtherStatus, SegmentUpdatePeriod,
    TagUpdatePeriod, ReportUpdatePeriod, TagLevel,
    IdMergeStatus, IdMergeDataStatus, TaskStatus, DataSourceCategory, TagValueType
} = _consts.Enums;


let { s3: s3config, HDFS: HDFSconfig } = _config2.default;
let firstAllList = exports.firstAllList = () => {
    return _models.Segment.findAll({
        attributes: ['id', 'name'],
        order: [['createdAt', 'DESC']],
        where: {
            status: Status.Normal,
            dataStatus: SegmentStatus.Normal,
            type: SegmentType.First
        }
    });
};

/**
 * 为上传人群新建标签和标签值
 */
let createUploadSegmentTagAndTagValue = exports.createUploadSegmentTagAndTagValue = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (name, flag, inStorage, updatePeriod, expires) {
        // let mergeRule = await getDefaultMergeRule();
        if (typeof inStorage === 'undefined') inStorage = 1;
        let tagModel = {
            name,
            // mergeRule: mergeRule.id,
            tagGroupId: OtherStatus.tag,
            tagType: TagType.Multiple,
            updatePeriod: updatePeriod,
            expires: expires,
            recordViewable: Status.Deleted,
            isUsedForInsight: Status.Deleted,
            tagLevel: TagLevel.uploadHidden
        };

        let tagRecord = yield (0, _tag.createSingleTag)(tagModel);
        let tagId = tagRecord.id;
        let tempValueRules = `${_segmentTagValue.uploadSegmentTagValueRules[inStorage].valueRules}'${flag}'`;
        let tagValueModel = {
            tagId,
            name: `_${name}`,
            valueRules: tempValueRules,
            parseRules: _segmentTagValue.uploadSegmentTagValueRules[inStorage].parseRules,
            tagValueRules: {
                type: TagValueType.code,
                rules: {
                    expression: tempValueRules
                }
            }
        };
        let tagValueRecord = yield (0, _tagValue.create)(tagValueModel);
        return {
            mergeRule: 0,
            includes: {
                logicalConnective: "or",
                rules: [[{
                    type: 1,
                    tagId: tagId,
                    value: [tagValueRecord.id]
                    //标签规则
                }]]
            },
            excludes: {
                logicalConnective: "or",
                rules: [[]]
            }

        };
    });

    return function createUploadSegmentTagAndTagValue(_x, _x2, _x3, _x4, _x5) {
        return _ref.apply(this, arguments);
    };
})();
/**
 * 创建默认人群(关联活动或者站点)
 * @param body
 * @param dimension
 * @returns {Array}
 */
let createDefaultSegmentByDimension = exports.createDefaultSegmentByDimension = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (body, dimension) {
        let { name, expires, insight } = body;
        let SegmentTypeList = _segmentTagValue.defaultSegmentTypeList[dimension];
        let data = [];
        // let mergeRule = await getDefaultMergeRule();
        let tagModel = {
            name,
            expires,
            // mergeRule: mergeRule.id,
            tagGroupId: OtherStatus.tag,
            tagType: TagType.Multiple,
            updatePeriod: TagUpdatePeriod.day,
            recordViewable: Status.Deleted,
            isUsedForInsight: Status.Deleted,
            tagLevel: TagLevel.campaignAndSiteHidden
        };

        let tagRecord = yield (0, _tag.createSingleTag)(tagModel);
        let tagId = tagRecord.id;
        for (let _ref3 of SegmentTypeList) {
            let { type, typeName, valueRules, parseRules, dimension, segmentGroupId } = _ref3;

            let tempValueRules = `${valueRules} '${body[dimension]}'`;
            let tagValueModel = {
                tagId,
                name: `${name}_${typeName}`,
                valueRules: tempValueRules,
                tagValueRules: {
                    type: TagValueType.code,
                    rules: {
                        expression: tempValueRules
                    }
                } || {},
                parseRules: parseRules
            };
            let tagValueRecord = yield (0, _tagValue.create)(tagValueModel);
            let segmentModel = {
                expires,
                name: `${name}_${typeName}`,
                type: SegmentType.Default,
                segmentGroupId: segmentGroupId || OtherStatus.segment,
                updatePeriod: SegmentUpdatePeriod.day,
                // recordEditable: Status.Deleted,
                segmentRules: {
                    firstPartyRules: {
                        mergeRule: 0,
                        includes: {
                            // logicalConnective: "or",
                            rules: [[{
                                type: 1,
                                tagId: tagId,
                                value: [tagValueRecord.id]
                                //标签规则
                            }]]
                        },
                        excludes: {
                            logicalConnective: "or",
                            rules: [[]]
                        }
                    }
                }
            };
            let segmentRecord = yield create(segmentModel);
            if (segmentRecord.id && insight && Array.isArray(insight) && insight.length > 0) {
                let insightModels = [];
                body.insight.forEach(function (item) {
                    insightModels.push({
                        expires,
                        segmentId: segmentRecord.id,
                        category: item.category,
                        dataSourceId: item.dataSourceId || null,
                        updatePeriod: ReportUpdatePeriod.day
                    });
                });
                yield createInsight(insightModels);
            }
            data.push({
                type,
                id: segmentRecord.id,
                name: segmentRecord.name
            });
        }
        return data;
    });

    return function createDefaultSegmentByDimension(_x6, _x7) {
        return _ref2.apply(this, arguments);
    };
})();

/**
 * 第一方和第三方字段映射list
 * @returns {*}
 */
let getMappingUserIdList = exports.getMappingUserIdList = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* () {
        return _models.UserIdMappingThirdPartyId.findAll({
            where: {
                status: Status.Normal
            },
            raw: true
        });
    });

    return function getMappingUserIdList() {
        return _ref4.apply(this, arguments);
    };
})();

let normalList = exports.normalList = (() => {
    var _ref7 = (0, _asyncToGenerator3.default)(function* (segmentGroupId, where) {
        where = (0, _assign2.default)(where, {
            dataStatus: SegmentStatus.Normal,
            status: {
                $ne: Status.Deleted
            }
        });
        return getSegmentBaseList(segmentGroupId, where);
    });

    return function normalList(_x10, _x11) {
        return _ref7.apply(this, arguments);
    };
})();

let allList = exports.allList = (() => {
    var _ref8 = (0, _asyncToGenerator3.default)(function* (segmentGroupId, where) {
        where = (0, _assign2.default)(where, {
            status: {
                $ne: Status.Deleted
            }
        });
        return getSegmentBaseList(segmentGroupId, where);
    });

    return function allList(_x12, _x13) {
        return _ref8.apply(this, arguments);
    };
})();let pages = exports.pages = conditions => {
    return _models.Segment.findAndCount(conditions);
};

let count = exports.count = conditions => {
    return _models.Segment.count(conditions);
};

let getWhere = exports.getWhere = (where, keywords) => {
    if (keywords) {
        (0, _assign2.default)(where, {
            $or: {
                id: {
                    $like: `%${keywords}%`
                },
                name: {
                    $like: `%${keywords}%`
                }
            }
        });
    }
    return (0, _assign2.default)(where, {
        status: {
            $ne: Status.Deleted
        }
    });
};

/**
 * 获得segmentId的随机数
 * @returns {*|Promise.<this>}
 */
let getSeq = (() => {
    var _ref11 = (0, _asyncToGenerator3.default)(function* () {
        let currentTagValueId;
        let seq;
        do {
            let instance = yield _models.Seq.findOne({ where: { id: 'segmentId' } });
            seq = yield instance.increment('seq', {
                by: 1
            });
            currentTagValueId = yield _models.Segment.findOne({
                where: { id: 'SG' + seq.seq }
            });
        } while (currentTagValueId);
        return seq;
    });

    return function getSeq() {
        return _ref11.apply(this, arguments);
    };
})();
/**
 * 上传人群入口
 * @param fileRules
 * @returns {void|*}
 */
let uploadSegment = exports.uploadSegment = (() => {
    var _ref12 = (0, _asyncToGenerator3.default)(function* (fileRules) {
        // const FS_PORTOCOL_HDFS = 'HDFS';
        let realPath = _path2.default.join(_config2.default.fileDir, `./${fileRules.filePath}`);
        let uploadObj = {};
        if (!_fs2.default.existsSync(realPath)) {
            throw new _errors2.default.SegmentFileNotExist();
        }
        let fileMD5Obj = yield getFileMD5(realPath);
        uploadObj = yield uploadFile(fileRules.filePath);

        return (0, _assign2.default)({}, fileRules, fileMD5Obj, uploadObj);
    });

    return function uploadSegment(_x16) {
        return _ref12.apply(this, arguments);
    };
})();

function uploadFile(filePath) {
    const FS_PORTOCOL_HDFS = 'HDFS';
    if (_config2.default.fsProtocol === FS_PORTOCOL_HDFS) {
        return uploadFileToHDFS(filePath);
    } else {
        return uploadFileToS3(filePath);
    }
}

/**
 * new 一个child process执行命令
 * @param commandLine
 */
function forkChildProcess(commandLine) {
    return new _promise2.default((resolve, reject) => {
        try {
            _child_process2.default.exec(commandLine, (error, stdout, stderr) => {
                if (error || stderr) {
                    console.error(`exec error: ${error}`);
                    reject();
                }
                resolve();
            });
        } catch (ex) {
            reject();
        }
    });
}let uploadFileToS3 = exports.uploadFileToS3 = (() => {
    var _ref14 = (0, _asyncToGenerator3.default)(function* (filePath) {
        let key = `audience/custom_upload/${(0, _moment2.default)().format("YYYY/MM/DD/HH/mm")}/${filePath}`;
        let s3Path = `s3://${s3config.bucket}/${key}`;

        return new _promise2.default(function (resolve, reject) {
            let s3 = new _awsSdk.S3((0, _lodash.pick)(s3config, ['accessKeyId', 'secretAccessKey', 'region']));
            s3.putObject({
                Bucket: s3config.bucket, //s3桶
                Key: key, //路径
                Body: _fs2.default.createReadStream(_path2.default.join(_config2.default.fileDir, `./${filePath}`))
            }, function (error, response) {
                console.log('uploadresult', error, response);
                if (error) {
                    reject(error);
                }
                resolve({
                    flag: _uuid2.default.v1(),
                    s3Path
                });
            });
        });
    });

    return function uploadFileToS3(_x18) {
        return _ref14.apply(this, arguments);
    };
})();

/**
 * 获取文件的md5值
 * @param realPath
 */
function getFileMD5(realPath) {
    return new _promise2.default(resolve => {
        const hash = _crypto2.default.createHash('md5');
        const input = _fs2.default.createReadStream(realPath);
        input.on('readable', () => {
            let data = input.read();
            if (data) {
                hash.update(data);
            } else {
                let md5 = hash.digest('hex');
                console.log(`${md5} ${realPath}`);
                resolve({
                    fileMD5: md5
                });
            }
        });
    });
}

/**
 * 获取上传人群的规则list
 * @return {Promise.<Array>}
 */
let getRulesOfUploadSegment = exports.getRulesOfUploadSegment = (() => {
    var _ref15 = (0, _asyncToGenerator3.default)(function* (where) {
        let segmentList = yield _models.Segment.findAll({
            attributes: ['id', 'name', 'segmentRules', 'createdAt'],
            where: (0, _assign2.default)(where, {
                type: SegmentType.Upload,
                status: Status.Normal
            }),
            raw: true
        });
        let finalArray = [];
        for (let _ref16 of segmentList) {
            let { id, name, createdAt, segmentRules } = _ref16;

            try {
                let uploadSegmentRules = JSON.parse(segmentRules);
                if ((0, _is2.default)(uploadSegmentRules.fileRules.inStorage, 0)) continue;
                finalArray.push({
                    id,
                    name,
                    createdAt,
                    providerId: uploadSegmentRules.fileRules.providerId,
                    rules: uploadSegmentRules.firstPartyRules.includes.rules[0][0] || {}
                });
            } catch (err) {
                console.log(err);
            }
        }
        return finalArray;
    });

    return function getRulesOfUploadSegment(_x19) {
        return _ref15.apply(this, arguments);
    };
})();

/**
 * 新建人群
 * @param model
 * @returns {model}
 */
let create = exports.create = (() => {
    var _ref17 = (0, _asyncToGenerator3.default)(function* (model) {
        let seq = yield getSeq();
        (0, _assign2.default)(model, {
            id: 'SG' + seq.seq
        });
        return _models.Segment.create(model);
    });

    return function create(_x20) {
        return _ref17.apply(this, arguments);
    };
})();
/**
 * 新建洞察任务(批量)
 * @param models
 * @returns {Promise.<Array.<Instance>>}
 */
let createInsight = exports.createInsight = models => {
    return _models.InsightInfo.bulkCreate(models);
};

/**
 * 新建洞察任务
 * @param model
 * @returns {Promise.<Array.<Instance>>}
 */
function createInsightModel(model) {
    return _models.InsightInfo.create(model);
}

/**
 * 新建idmerge报告
 * @param model
 * @return {Promise.<model>}
 */
let createIdMergeReport = exports.createIdMergeReport = (() => {
    var _ref18 = (0, _asyncToGenerator3.default)(function* (model) {
        return _models.IdMergeReport.create(model);
    });

    return function createIdMergeReport(_x21) {
        return _ref18.apply(this, arguments);
    };
})();
/**
 * 新建全部活动效果报告
 * @param model
 * @return {Promise.<model>}
 */
let createCampaignReport = exports.createCampaignReport = (() => {
    var _ref19 = (0, _asyncToGenerator3.default)(function* (model) {
        return _models.CampaignReport.create(model);
    });

    return function createCampaignReport(_x22) {
        return _ref19.apply(this, arguments);
    };
})();
/**
 * 根据人群id获取人群信息
 * @param id
 * @returns {*|Object|Query}
 */
let query = exports.query = id => {
    return _models.Segment.findOne({
        attributes: ['id', 'name', 'type', 'segmentRules', 'updatePeriod', 'segmentGroupId', 'remark', 'refreshTime', 'coverage', 'expires', 'createdAt'],
        where: {
            id
        },
        raw: true
    });
};
/**
 * 根据人群ids查询有多少个洞察任务
 * @param ids
 * @returns {Object|*|Query}
 */
let queryInsight = exports.queryInsight = ids => {
    return _models.InsightInfo.findAll({
        attributes: ['category', 'dataSourceId', 'segmentId', 'dataStatus', 'errorCode', 'updatePeriod', 'expires', 'startTask'],
        where: {
            segmentId: {
                $in: ids
            },
            status: InsightStatus.Normal
        },
        raw: true
    });
};
/**
 * 查询idmergereport报告
 * @param ids
 * @return {*}
 */
let queryIdMergeReport = exports.queryIdMergeReport = ids => {
    return _models.IdMergeReport.findOne({
        attributes: ['segmentId', 'dataStatus', 'errorCode', 'updatePeriod', 'expires'],
        where: {
            segmentId: {
                $in: ids
            },
            status: InsightStatus.Normal
        },
        raw: true
    });
};

/**
 * 查询人群活动报告开启状况
 * @param ids
 * @return {Query|*}
 */
let queryCampaignReport = exports.queryCampaignReport = ids => {
    return _models.CampaignReport.findOne({
        attributes: ['segmentId', 'status'],
        where: {
            segmentId: {
                $in: ids
            },
            status: Status.Normal
        },
        raw: true
    });
};

/**
 * 根据id查询dataSourceList
 * @param ids
 * @returns {*}
 */

let getDataSourceListByIds = exports.getDataSourceListByIds = ids => {
    return _models.DataSource.findAll({
        attributes: ['id', 'name'],
        where: {
            id: {
                $in: (0, _lodash.uniq)(ids)
            }
        },
        raw: true
    });
};

/**
 * 给dataSourceId添加name
 * @param data
 * @returns {*}
 */
let getDataSourceDetails = exports.getDataSourceDetails = (() => {
    var _ref20 = (0, _asyncToGenerator3.default)(function* (data) {
        let dataSourceList = [];
        if (data && data.length > 0) {

            dataSourceList = yield getDataSourceListByIds(data.map(function (item) {
                if (item.dataSourceId) {
                    return item.dataSourceId;
                }
            }));

            data.forEach(function (z) {
                let dataSourceItem = (0, _lodash.find)(dataSourceList, { id: z.dataSourceId });
                if (dataSourceItem) {
                    z.dataSourceName = dataSourceItem.name;
                }
            });
        }

        return data;
    });

    return function getDataSourceDetails(_x23) {
        return _ref20.apply(this, arguments);
    };
})();

/**
 * 判断是否应该更新为生成中的状态
 * @param segmentId
 * @param newSegmentRules
 * @param updatePeriod
 * @return {Promise.<{shouldUpdateToGenerating: boolean, shouldAddReportTask: boolean}>}
 */
let shouldUpdateDateStatus = exports.shouldUpdateDateStatus = (() => {
    var _ref21 = (0, _asyncToGenerator3.default)(function* (segmentId, { segmentRules: newSegmentRules, updatePeriod }) {
        let shouldUpdateToGenerating = false;
        let shouldAddReportTask = false;
        let segmentObj = yield _models.Segment.findOne({
            where: {
                id: segmentId
            },
            raw: true
        });
        if (segmentObj && segmentObj.segmentRules) {
            let newSegmentRulesIM = _immutable2.default.fromJS(newSegmentRules);
            let oldSegmentRulesIM = _immutable2.default.fromJS(JSON.parse(segmentObj.segmentRules));
            if (!newSegmentRulesIM.equals(oldSegmentRulesIM)) {
                shouldUpdateToGenerating = true;
            }
        }
        if (segmentObj && segmentObj.updatePeriod && updatePeriod !== segmentObj.updatePeriod) {
            shouldAddReportTask = true;
        }
        return {
            shouldUpdateToGenerating,
            shouldAddReportTask: shouldAddReportTask || shouldUpdateToGenerating
        };
    });

    return function shouldUpdateDateStatus(_x24, _x25) {
        return _ref21.apply(this, arguments);
    };
})();
/**
 * 更新人群
 * @param id
 * @param model
 */
let update = exports.update = (id, model) => {
    return _models.Segment.update(model, {
        where: { id }
    });
};
/**
 * 根据人群id更新标签的更新周期
 * @param id
 * @param model
 * @returns {*}
 */
let updateTagUpdatePeriodBySegmentId = exports.updateTagUpdatePeriodBySegmentId = (() => {
    var _ref22 = (0, _asyncToGenerator3.default)(function* (id, model) {
        let segmentRecord = yield _models.Segment.findOne({
            where: { id },
            raw: true
        });
        if (!segmentRecord) return;
        try {
            let tagId = (0, _lodash.result)(JSON.parse(segmentRecord.segmentRules), 'firstPartyRules.includes.rules[0][0].tagId', null);
            if (!tagId) return;
            return _models.FirstPartyTag.update(model, {
                where: {
                    id: tagId
                }
            });
        } catch (err) {
            console.log(err);
        }
    });

    return function updateTagUpdatePeriodBySegmentId(_x26, _x27) {
        return _ref22.apply(this, arguments);
    };
})();

/**
 * 给人群规则添加name
 * @param rules
 * @param arr
 * @returns {*}
 */
let appendIdAndStatus = exports.appendIdAndStatus = (rules, arr) => {
    let idMapName = {};
    let idMapStatus = {};
    let idMapDataStatus = {};
    arr.forEach(item => {
        idMapName[item.id] = item.name;
        idMapStatus[item.id] = item.status;
        idMapDataStatus[item.id] = item.dataStatus;
    });
    return (0, _segment.getKeyPathOriginalObject)(rules, item => {
        return item.map(ru => dealWithObj(ru, idMapName, idMapStatus, idMapDataStatus));
    });
};

/**
 * 添加staus一系列参数
 * @param srcRu 一个选项对应的规则
 * @param idMapName
 * @param idMapStatus
 * @param idMapDataStatus
 * @returns {*}
 */
let dealWithObj = exports.dealWithObj = (srcRu, idMapName, idMapStatus, idMapDataStatus) => {
    let ru = (0, _extends3.default)({}, srcRu); //此处只是浅层复制 不过srcRu没有嵌套深度对象
    let tagId = ru.tagId;
    if (idMapName[tagId]) {
        ru.tagIsNormal = idMapStatus[tagId] === TagStatus.Open;
        ru.tagName = idMapName[tagId];
        ru.valueName = ru.value.map(z => idMapName[z]);
        ru.valueIsNormal = ru.value.every(valueItemId => {
            if (!(0, _is2.default)(idMapDataStatus[valueItemId], undefined)) {
                /**
                 * 第一方的标签值 status=1 dataStatus=2
                 */
                return idMapStatus[valueItemId] === Status.Normal && idMapDataStatus[valueItemId] === TagValueStatus.Normal;
            }
            /**
             * 第三方的
             */
            return idMapStatus[valueItemId] === Status.Normal;
        });
    }
    return ru;
};

function ListToMap(list) {
    let map = {};
    list.forEach(({ id, name }) => map[id] = name);
    return map;
}

let convertIdToName = exports.convertIdToName = (() => {
    var _ref24 = (0, _asyncToGenerator3.default)(function* (rules) {
        let idMapName = {};
        let arr = [];
        if (rules.firstPartyRules && rules.firstPartyRules.includes && rules.firstPartyRules.excludes && rules.firstPartyRules.includes.rules && rules.firstPartyRules.excludes.rules) {
            let firstRules = [];
            rules.firstPartyRules.includes.rules.forEach(function (item) {
                firstRules = firstRules.concat(item);
            });
            rules.firstPartyRules.excludes.rules.forEach(function (z) {
                firstRules = firstRules.concat(z);
            });
            let firstTagIds = (0, _lodash.uniq)(firstRules.map(function (x) {
                return x.tagId;
            }));
            let firstTagValueIds = _lodash.union.apply(null, firstRules.map(function (x) {
                return x.value;
            }));
            let firstTagList = yield (0, _tag.getFirstTaglistByIds)(firstTagIds);
            let firstTagValueList = yield (0, _tagValue.getFirstTagValuelistByIds)(firstTagValueIds);
            arr = firstTagList.concat(firstTagValueList);
        }
        if (rules.thirdPartyRules && rules.thirdPartyRules.includes && rules.thirdPartyRules.excludes && rules.thirdPartyRules.includes.rules && rules.thirdPartyRules.excludes.rules) {
            let thirdRules = [];
            if (rules.thirdPartyRules.dataSourceId) {
                rules.thirdPartyRules.dataSourceName = yield (0, _dataSource.getDataSourceNameById)(rules.thirdPartyRules.dataSourceId);
            }
            rules.thirdPartyRules.includes.rules.forEach(function (item) {
                thirdRules = thirdRules.concat(item);
            });
            rules.thirdPartyRules.excludes.rules.forEach(function (z) {
                thirdRules = thirdRules.concat(z);
            });
            let thirdTagIds = (0, _lodash.uniq)(thirdRules.map(function (x) {
                return x.tagId;
            }));
            let thirdTagValueIds = _lodash.union.apply(null, thirdRules.map(function (x) {
                return x.value;
            }));
            let thirdTagList = yield (0, _tag.getThirdTaglistByIds)(thirdTagIds);
            let thirdTagValueList = yield (0, _tagValue.getThirdTagValuelistByIds)(thirdTagValueIds);
            arr = arr.concat(thirdTagList, thirdTagValueList);
        }
        if (rules.magnificationRules && rules.magnificationRules.baseSegment) {
            let segObj = yield query(rules.magnificationRules.baseSegment);
            if (segObj) {
                rules.magnificationRules.baseSegmentName = segObj.name;
                rules.magnificationRules.coverage = segObj.coverage;
                rules.magnificationRules.createdAt = segObj.createdAt;
            }
        }
        arr.forEach(function (item) {
            idMapName[item.id] = item.name;
        });

        return appendIdAndStatus(rules, arr);
    });

    return function convertIdToName(_x28) {
        return _ref24.apply(this, arguments);
    };
})();let updateInsightList = exports.updateInsightList = (() => {
    var _ref28 = (0, _asyncToGenerator3.default)(function* (segmentId, insight, shouldUpdateToGenerating, updatePeriod, expires) {
        function itemIsInInsightList(insightList, item) {
            return (0, _lodash.find)(insightList, z => z.category === item.category && (!item.dataSourceId || z.dataSourceId === item.dataSourceId));
        }

        let previousInsight = yield (0, _insight.getAllInsightListBySegmentId)(segmentId);
        /**
         * 不在现有insightList的洞察人群删除掉
         */
        for (let preItem of previousInsight) {
            let existCurrentInsightItem = itemIsInInsightList(insight, preItem);
            if (!existCurrentInsightItem && preItem.status === InsightStatus.Normal) {
                let where = {
                    segmentId,
                    category: preItem.category,
                    updatedAt: _models.sequelize.fn('NOW')
                };
                if (preItem.category === DataSourceCategory.ThirdParty) {
                    where = (0, _extends3.default)({}, where, {
                        dataSourceId: preItem.dataSourceId
                    });
                }
                yield _models.InsightInfo.update({
                    status: InsightStatus.Deleted
                }, {
                    where
                });
                yield addReportInsightTask(preItem.id);
            }
        }

        for (let item of insight) {
            let previousInsightItem = itemIsInInsightList(previousInsight, item);

            if (previousInsightItem) {
                let updateModel = {
                    updatePeriod,
                    expires,
                    status: InsightStatus.Normal,
                    startTask: previousInsightItem.status ? previousInsightItem.startTask : TaskStatus.run,
                    updatedAt: _models.sequelize.fn('NOW')
                };

                if (shouldUpdateToGenerating) {
                    updateModel = (0, _extends3.default)({}, updateModel, {
                        dataStatus: InsightDataStatus.Generating
                    });
                }

                yield _models.InsightInfo.update(updateModel, {
                    where: {
                        id: previousInsightItem.id
                    }
                });

                yield addReportInsightTask(previousInsightItem.id);
            } else {

                let insightRecord = yield _models.InsightInfo.create({
                    updatePeriod,
                    expires,
                    segmentId,
                    category: item.category,
                    dataSourceId: item.dataSourceId || null
                });

                let insightInstance = yield insightRecord.reload();
                //新建洞察任务
                yield addReportInsightTask(insightInstance.dataValues.id);
            }
        }
    });

    return function updateInsightList(_x39, _x40, _x41, _x42, _x43) {
        return _ref28.apply(this, arguments);
    };
})();

/**
 * 判断是否有人群正在分发
 * @param segmentId
 * @return {*|Query}
 */
let shouldRemoveSegment = exports.shouldRemoveSegment = segmentId => {
    return _models.SegmentExport.findOne({
        where: {
            status: ExportStatus.Open,
            segmentId: segmentId
        }
    });
};

const nativeArrayMap = Array.prototype.map;
const nativeArrayReduce = Array.prototype.reduce;

/**
 * 获取人群规则的详细标签规则
 * @param segmentList
 * @param cb
 */
function getSegmentRulesIncludeAndExclude(segmentList, cb) {
    function reduceDeal(a, b) {
        return a.concat(b);
    }

    return segmentList.map(({ segmentRules, id, name }) => {
        try {
            let segmentRulesRaw = JSON.parse(segmentRules);
            return {
                id,
                name,
                usedRules: (0, _segment.getKeyPathArrayShallow)(segmentRulesRaw, itemRules => {
                    return nativeArrayMap.call(nativeArrayReduce.call(itemRules, reduceDeal, []), cb);
                }).reduce(reduceDeal, []).filter(z => z)
            };
        } catch (err) {
            return {
                id,
                name,
                usedRules: []
            };
        }
    });
}

/**
 * 获取全部未删除的人群
 * @return {*}
 */
function getAllNormalSegmentList() {
    return _models.Segment.findAll({
        raw: true,
        where: {
            status: Status.Normal
        },
        attributes: ['id', 'name', 'segmentRules']
    });
}

/**
 * 判断上传的人群是否被人群用去新建规则
 * @param segmentId
 * @param mode
 * @return {*}
 */
let isUploadSegmentUsedBySegment = exports.isUploadSegmentUsedBySegment = (() => {
    var _ref29 = (0, _asyncToGenerator3.default)(function* (segmentId, mode) {
        let segmentList = yield getAllNormalSegmentList();
        let usedSegmentList = [];
        if (segmentList && segmentList.length > 0) {
            //获取人群规则的list
            let includeList = getSegmentRulesIncludeAndExclude(segmentList, function (item) {
                return item[mode];
            });
            for (let _ref30 of includeList) {
                let { usedRules, id, name } = _ref30;

                //flatMap打平人群规则
                if ((0, _lodash.flatMap)(usedRules).indexOf(segmentId) > -1) {
                    usedSegmentList.push({
                        id,
                        name
                    });
                }
            }
        }
        return usedSegmentList;
    });

    return function isUploadSegmentUsedBySegment(_x44, _x45) {
        return _ref29.apply(this, arguments);
    };
})();

/**
 * 移除人群
 * @param id
 * @returns {*}
 */
let remove = exports.remove = (() => {
    var _ref31 = (0, _asyncToGenerator3.default)(function* (id) {
        return _models.Segment.update({
            status: Status.Deleted
        }, {
            where: { id }
        });
    });

    return function remove(_x46) {
        return _ref31.apply(this, arguments);
    };
})();
/**
 * 移除洞察
 * @param segmentId
 * @returns {*}
 */
let removeInsightBySegmentId = exports.removeInsightBySegmentId = segmentId => {
    return _models.InsightInfo.update({
        status: Status.Deleted,
        updatedAt: _models.sequelize.fn('NOW')
    }, {
        where: { segmentId }
    });
};
/**
 * 移除idMerge报告
 * @param segmentId
 */
let removeIdMergeBySegmentId = exports.removeIdMergeBySegmentId = segmentId => {
    return _models.IdMergeReport.update({
        status: Status.Deleted,
        updatedAt: _models.sequelize.fn('NOW')
    }, {
        where: { segmentId }
    });
};
/**
 * 移除活动报告
 * @param segmentId
 */
let removeCampaignReportBySegmentId = exports.removeCampaignReportBySegmentId = segmentId => {
    return _models.CampaignReport.update({
        status: Status.Deleted,
        updatedAt: _models.sequelize.fn('NOW')
    }, {
        where: { segmentId }
    });
};

/**
 * 根据id列表获取多个人群信息
 * @param ids
 * @param attributes
 * @return {*}
 */
let getSegmentListByIds = exports.getSegmentListByIds = (ids, attributes = ['id', 'name']) => {
    return _models.Segment.findAll({
        attributes,
        where: {
            id: { $in: (0, _lodash.uniq)(ids) }
        },
        raw: true
    });
};

let StringDecoder = require('string_decoder').StringDecoder;
let decoder = new StringDecoder('utf-8');
const CSV_SEPARATOR = ',';
const TAB_CHARACTER = '\t';

/**
 * 添加制表符的回调
 */
function onDataCallback(chunk) {
    let tempChunkArray = String.prototype.split.call(decoder.write(chunk), _os2.default.EOL);
    return tempChunkArray.map(row => {
        return row.split(CSV_SEPARATOR).map(value => {
            return (0, _is2.default)(Number(value), NaN) ? value : `${TAB_CHARACTER}${value}`;
        }).join(CSV_SEPARATOR);
    }).join(_os2.default.EOL);
}

/**
 * 从server端下载人群文件
 * @param body {String}
 * @return {*}
 */
let download = exports.download = body => {
    // let filePath = path.join(config.fileDir,`/src_segment_${uuid.v1()}_${body.segmentId}.zip`);
    // let resFilePath = path.join(config.fileDir,`/${uuid.v1()}_${body.segmentId}.csv`);
    // return fs.createReadStream('E:\\test.zip')
    return _api.ReportApi.downloadSegmentFile(body);
    // fs.createReadStream(filePath)
    //     .pipe(iconv.decodeStream('utf8'))
    //     .pipe(iconv.encodeStream('gb2312'))
    //     .pipe(fs.createWriteStream(resFilePath));
};

function addReportSegmentTask(segmentId) {
    const SEGMENT_KEY_TYPE = 1;
    return _models.ReportTask.create({
        keyId: segmentId,
        keyType: SEGMENT_KEY_TYPE
    });
}

function addReportInsightTask(insightId) {
    const INSIGHT_KEY_TYPE = 2;
    return _models.ReportTask.create({
        keyId: insightId,
        keyType: INSIGHT_KEY_TYPE
    });
}
function addTagValueUploadTask(id) {
    const TAG_VALUE_UPLOAD_KEY_TYPE = 3;
    return _models.ReportTask.create({
        keyId: id,
        keyType: TAG_VALUE_UPLOAD_KEY_TYPE
    });
}
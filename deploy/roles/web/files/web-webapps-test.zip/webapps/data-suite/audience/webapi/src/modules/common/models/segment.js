'use strict';

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

var _sequelize = require('sequelize');

var _sequelize2 = _interopRequireDefault(_sequelize);

var _consts = require('../../../config/consts');

var _helper = require('../util/helper');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Segment', {
        id: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: true,
            defaultValue: null
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null
        },
        type: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        },

        segmentGroupId: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'segment_group_id'
        },

        segmentRules: {
            type: DataTypes.JSON,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'segment_rules',
            set: function (val) {
                try {
                    this.setDataValue('segmentRules', JSON.parse((0, _stringify2.default)(val)));
                } catch (err) {
                    return null;
                }
            },
            get: function (val) {
                try {
                    return this.getDataValue(val);
                } catch (err) {
                    return null;
                }
            }

        },
        remark: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null
        },
        errorCode: {
            type: DataTypes.STRING,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'error_code'
        },
        coverage: {
            type: DataTypes.INTEGER(10),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null
        },
        rowCount: {
            type: DataTypes.INTEGER(10),
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'row_count'
        },
        status: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1
        },

        dataStatus: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _consts.Enums.SegmentStatus.Generating,
            field: 'data_status'
        },
        createdAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'created_at'
        },
        updatedAt: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _sequelize2.default.NOW,
            field: 'updated_at'
        },
        refreshTime: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            field: 'refresh_time'
        },
        recordEditable: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: 'record_editable'
        },
        updatePeriod: {
            type: DataTypes.INTEGER(4),
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _consts.Enums.SegmentUpdatePeriod.auto,
            field: 'update_period'
        },
        expires: {
            type: DataTypes.DATE,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: _helper.FOREVER_TIME,
            field: 'expires'
        }
    }, {
        tableName: 'segment'
    });
};
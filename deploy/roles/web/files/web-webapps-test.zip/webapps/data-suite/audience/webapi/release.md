v1.12.0发布
```
    1.执行sql/v1.12.0下的sql文件
    2.在项目目录下执行 npm run init_tag_rule:production 命令
    3 修改配置文件添加 dataServiceApiPath: "http://web-dev.chiefclouds.com:8082/v1/dataservice",
```

v1.13.0发布
```
    1.执行sql/v1.13.0下的sql文件
    2. 修改配置文件添加  reportDownloadApiPath: "http://web-dev.chiefclouds.com:9100",
```
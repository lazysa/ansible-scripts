'use strict';

var _koa = require('koa');

var _koa2 = _interopRequireDefault(_koa);

var _koaConvert = require('koa-convert');

var _koaConvert2 = _interopRequireDefault(_koaConvert);

var _koaError = require('koa-error');

var _koaError2 = _interopRequireDefault(_koaError);

var _koaCors = require('koa-cors');

var _koaCors2 = _interopRequireDefault(_koaCors);

var _config = require('./config/config');

var _config2 = _interopRequireDefault(_config);

var _router = require('./router');

var _router2 = _interopRequireDefault(_router);

var _koaBody = require('koa-body');

var _koaBody2 = _interopRequireDefault(_koaBody);

var _koaLogger = require('koa-logger');

var _koaLogger2 = _interopRequireDefault(_koaLogger);

var _util = require('util');

var _util2 = _interopRequireDefault(_util);

var _http = require('http');

var _http2 = _interopRequireDefault(_http);

var _upmAuth = require('upm-auth');

var _koaCompress = require('koa-compress');

var _koaCompress2 = _interopRequireDefault(_koaCompress);

var _koaStatic = require('koa-static');

var _koaStatic2 = _interopRequireDefault(_koaStatic);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _log = require('./modules/common/core/log');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const app = new _koa2.default();
app.use((0, _koaConvert2.default)((0, _koaStatic2.default)(_path2.default.join(__dirname, '../apidoc'))));
// app.keys = config.cookieSignKeys;
app.use((0, _koaConvert2.default)((0, _upmAuth.auth)({
    whitePaths: _config2.default.whitePaths,
    appId: _config2.default.authAppId,
    basePath: _config2.default.authAPiPath,
    logger: _log.log.log,
    disable: _config2.default.env === "development",
    disableVerifyToken: _config2.default.env === "development",
    disableCache: _config2.default.env === "development" ? true : true,
    token: 'aiZsUzX4yh_L1Mu0cLA2v9Qb24iFbRfCDcHJVLsOg21BF9A0ePfAOk-R39ZsG1v3'
})));

// app.use(serve(config.fileDir));

app.use((0, _koaCompress2.default)({
    filter: function () {
        return 4;
    },
    threshold: 1024,
    flush: require('zlib').Z_SYNC_FLUSH
}));

/**
 * /
 body解析
 */

app.use((0, _koaConvert2.default)((0, _koaBody2.default)({
    formidable: {
        uploadDir: _config2.default.uploadDir
    },
    multipart: true
})));
/**
 *跨域支持
 */

app.use((0, _koaConvert2.default)((0, _koaCors2.default)({
    origin: function (req) {
        let origin = req.header.origin;
        if (origin && _config2.default.allowOrigins.indexOf(origin) != -1) {
            return origin;
        }
        return _config2.default.allowOrigins[0];
    },
    credentials: true,
    headers: ["X-Token", "Content-Type"]
})));

//禁止缓存
if (_config2.default.env == 'development') {
    app.use(function (ctx, next) {
        ctx.set('Cache-Control', 'no-cache, no-store, must-revalidate'); // HTTP 1.1.
        ctx.set('Pragma', 'no-cache'); // HTTP 1.0.
        ctx.set('Expires', '0'); // Proxies.
        return next();
    });
}
//输出错误日志 开发环境使用
if (_config2.default.env == 'development') {
    app.use((0, _koaConvert2.default)((0, _koaLogger2.default)()));
    app.use((0, _koaConvert2.default)((0, _koaError2.default)()));
} else {
    app.on('error', function (err, ctx) {
        ctx.status = err.status || 500;
        ctx.body = err.message;
    });
}

/**
 * 添加所有请求logger
 */
app.use((ctx, next) => {
    _log.requestLog.info({
        req: ctx.request,
        query: ctx.request.query,
        body: _util2.default.inspect(ctx.request.body, true, null, true)
    });
    return next();
});

//auth

// app.use(auth);
//路由
(0, _router2.default)(app);

// app.listen(config.port,function () {
//     console.info('listen on',config.port);
// });

let server = _http2.default.createServer(app.callback()).listen(_config2.default.port, function () {
    console.info('listen on', _config2.default.port);
});

module.exports = server;
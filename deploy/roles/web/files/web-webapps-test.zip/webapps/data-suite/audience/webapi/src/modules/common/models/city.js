'use strict';

Object.defineProperty(exports, "__esModule", {
	value: true
});
var mongoose = require("mongoose");
var Schema = mongoose.Schema;

var citySchema = new Schema({
	'id': String,
	'name': String,
	'stateId': String,
	'pinyin': String,
	'pinyinFirstLetter': String,
	'settleTime': {
		'type': Date,
		'default': Date.now
	},
	'lastChanged': {
		'type': Date,
		'default': Date.now
	},
	'status': {
		'type': Number,
		'default': 1
	}
});

citySchema.index({
	'id': 1
});
citySchema.index({
	'name': 1
});
citySchema.index({
	'stateid': 1
});

exports.default = mongoose.model('City', citySchema);
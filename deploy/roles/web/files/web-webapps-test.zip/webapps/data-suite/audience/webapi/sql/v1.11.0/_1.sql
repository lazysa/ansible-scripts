/*
Navicat MySQL Data Transfer

Source Server         : 192.168.10.40_3306
Source Server Version : 50711
Source Host           : 192.168.10.40:3306
Source Database       : audience

Target Server Type    : MYSQL
Target Server Version : 50711
File Encoding         : 65001

Date: 2017-06-09 17:40:26
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for resource_team
-- ----------------------------
DROP TABLE IF EXISTS `resource_team`;
CREATE TABLE `resource_team` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `team_id` int(10) NOT NULL,
  `resource_type` varchar(255) NOT NULL,
  `resource_id` varchar(255) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `updated_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;
SET FOREIGN_KEY_CHECKS=1;

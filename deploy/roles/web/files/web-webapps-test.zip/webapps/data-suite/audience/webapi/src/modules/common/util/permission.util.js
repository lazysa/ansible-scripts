'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.createTeamResource = exports.getTeamResourceIds = undefined;

var _assign = require('babel-runtime/core-js/object/assign');

var _assign2 = _interopRequireDefault(_assign);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

/**
 * 查询resourceTeamId 表
 * @param resourceType
 * @param teamId
 * @return {Promise.<*>}
 */
let getTeamResourceIds = exports.getTeamResourceIds = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (resourceType, teamId) {
        if (!Array.isArray(teamId)) {
            teamId = [teamId];
        }
        let resourceList = yield _models.ResourceTeam.findAll({
            where: {
                resourceType,
                teamId: {
                    $in: teamId
                },
                status: Status.Normal
            },
            raw: true
        });

        return resourceList && resourceList.map(function (z) {
            return z.resourceId;
        });
    });

    return function getTeamResourceIds(_x3, _x4) {
        return _ref2.apply(this, arguments);
    };
})();

let createTeamResource = exports.createTeamResource = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (resourceType, teamIds, resourceId) {
        if (!Array.isArray(teamIds)) return createTeamResourceId(resourceType, teamIds, resourceId);
        for (let teamId of (0, _lodash.uniq)(teamIds)) {
            yield createTeamResourceId(resourceType, teamId, resourceId);
        }
    });

    return function createTeamResource(_x5, _x6, _x7) {
        return _ref3.apply(this, arguments);
    };
})();
/**
 * 创建resourceTeamId
 * @param resourceType
 * @param teamId
 * @param resourceId
 */


exports.checkPermission = checkPermission;
exports.createTeamResourceId = createTeamResourceId;
exports.removeTeamResourceId = removeTeamResourceId;
exports.constructorResource = constructorResource;

var _upmAuth = require('upm-auth');

var _models = require('../../common/models');

var _helper = require('../util/helper');

var _consts = require('../../../config/consts');

var _lodash = require('lodash');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const { Permission, Status } = _consts.Enums;

const ResourceTypeMapResourceId = {
    'segment': 'id'
};
/**
 * 判断是否有权限
 * @param actionId
 * @return {Function}
 */
function checkPermission(actionId) {
    return (() => {
        var _ref = (0, _asyncToGenerator3.default)(function* (ctx, next) {
            try {
                let actionInfo = yield _upmAuth.services.getActionInfo(actionId);
                let {
                    permission
                } = actionInfo;
                if (permission == null) {
                    throw new _upmAuth.errors.PermissionDeny();
                }
                ctx.state.actionInfo = actionInfo;
                yield next();
            } catch (ex) {
                console.log(ex);
                return ctx.body = (0, _helper.wrapBody)(ex);
            }
        });

        return function (_x, _x2) {
            return _ref.apply(this, arguments);
        };
    })();
}function createTeamResourceId(resourceType, teamId, resourceId) {
    if (!Array.isArray(resourceId)) {
        return _models.ResourceTeam.create({
            resourceType,
            teamId,
            resourceId
        });
    } else {
        console.log(resourceId);
        return _models.ResourceTeam.bulkCreate(resourceId.map(z => ({
            resourceType,
            teamId,
            resourceId: z
        })));
    }
}
/**
 * 删除resourceTeamId
 * @param resourceType
 * @param teamId
 * @param resourceId
 */
function removeTeamResourceId(resourceType, teamId, resourceId) {
    return _models.ResourceTeam.update({
        status: Status.Deleted
    }, {
        where: {
            resourceType,
            teamId,
            resourceId
        }
    });
}

/**
 * 构建查询条件
 * @param resourceType
 * @return {Function}
 */
function constructorResource(resourceType) {
    return (() => {
        var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
            try {
                let {
                    permission,
                    teamIds
                } = ctx.state.actionInfo;
                let where = {};
                console.log(permission, teamIds);
                if (permission != Permission.All) {

                    (0, _assign2.default)(where, {
                        [ResourceTypeMapResourceId[resourceType]]: {
                            $in: yield getTeamResourceIds(resourceType, teamIds)
                        }
                    });
                }
                ctx.state.where = where;
                yield next();
            } catch (ex) {
                console.log(ex);
                return ctx.body = (0, _helper.wrapBody)(ex);
            }
        });

        return function (_x8, _x9) {
            return _ref4.apply(this, arguments);
        };
    })();
}
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.firstList = exports.updateCampaignAndSite = exports.createSite = exports.createCampaign = exports.firstAndUploadList = exports.segmentGroupList = exports.authToken = exports.segmentAliasByIds = exports.firstAllList = exports.tagValueAliasByIds = exports.reportSegment = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let reportSegment = exports.reportSegment = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            data = yield service.reportSegment();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function reportSegment(_x) {
        return _ref.apply(this, arguments);
    };
})();
/**
 * 正则过滤
 * @param data
 * @param keywords
 * @return {Array}
 */


let tagValueAliasByIds = exports.tagValueAliasByIds = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let { tagValueId, keywords } = body;
            let srcData = yield (0, _tagValue.getFirstTagValuelistByIds)(tagValueId);
            data = srcData.map(function ({ id, name }) {
                return { id, name };
            });
            data = filterKeywords(data, keywords);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function tagValueAliasByIds(_x2) {
        return _ref2.apply(this, arguments);
    };
})();

let firstAllList = exports.firstAllList = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let { keywords } = ctx.request.query;
            data = yield (0, _tagValue.getFirstAllList)(keywords);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function firstAllList(_x3) {
        return _ref3.apply(this, arguments);
    };
})();

let segmentAliasByIds = exports.segmentAliasByIds = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let { segmentId, keywords } = body;
            let srcData = yield (0, _segment2.getSegmentListByIds)(segmentId);
            data = srcData.map(function ({ id, name }) {
                return { id, name };
            });
            data = filterKeywords(data, keywords);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function segmentAliasByIds(_x4) {
        return _ref4.apply(this, arguments);
    };
})();

let authToken = exports.authToken = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        try {
            let headers = ctx.request.headers;
            let { timestamp, randomstr, token } = headers;
            let hash = service.getHash(timestamp, randomstr, _config2.default.apiSecret);
            if (!timestamp || !randomstr || timestamp.toString().length < 10 || randomstr.length < 10) {
                throw new _errors2.default.ApiNoInvokeRight();
            }
            if (hash == token) {
                yield next();
            } else {
                throw new _errors2.default.ApiNoInvokeRight();
            }
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex, null);
        }
    });

    return function authToken(_x5, _x6) {
        return _ref5.apply(this, arguments);
    };
})();

var _segmentGroup = require('../../../segmentGroup/segmentGroup.controller');

Object.defineProperty(exports, 'segmentGroupList', {
    enumerable: true,
    get: function () {
        return _segmentGroup.list;
    }
});

var _segment = require('../../../segment/segment.controller');

Object.defineProperty(exports, 'firstAndUploadList', {
    enumerable: true,
    get: function () {
        return _segment.firstAndUploadList;
    }
});
Object.defineProperty(exports, 'createCampaign', {
    enumerable: true,
    get: function () {
        return _segment.createCampaign;
    }
});
Object.defineProperty(exports, 'createSite', {
    enumerable: true,
    get: function () {
        return _segment.createSite;
    }
});
Object.defineProperty(exports, 'updateCampaignAndSite', {
    enumerable: true,
    get: function () {
        return _segment.updateCampaignAndSite;
    }
});
Object.defineProperty(exports, 'firstList', {
    enumerable: true,
    get: function () {
        return _segment.firstList;
    }
});

var _helper = require('../../../common/util/helper');

var _errors = require('../../../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _config = require('../../../../config/config');

var _config2 = _interopRequireDefault(_config);

var _business = require('./business.service');

var service = _interopRequireWildcard(_business);

var _tagValue = require('../../../tagValue/tagValue.service');

var _segment2 = require('../../../segment/segment.service');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function filterKeywords(data, keywords) {
    if (!data) return [];
    return data.filter(({ id, name }) => {
        return !keywords || new RegExp(keywords).test(id) || new RegExp(keywords).test(name);
    });
}
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _exxon = require('./exxon.controller');

var ctrl = _interopRequireWildcard(_exxon);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
    prefix: '/exxon'
});

router.get('/productList', ctrl.productList);
router.get('/categoryList', ctrl.categoryDataList);
router.get('/loyalCategoryList', ctrl.loyalCategoryDataList);
router.get('/dataRecord', ctrl.buyerCountRecord);
router.get('/channel', ctrl.channelBuyerCount);
router.get('/tagBuyerCounts', ctrl.tagBuyerCounts);

exports.default = router;
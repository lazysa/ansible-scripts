'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.create = exports.updateInsight = exports.SegmentPages = undefined;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import {Enums} from '../../config/consts';

let SegmentPages = exports.SegmentPages = _joi2.default.object().keys({
    keywords: _joi2.default.string().allow('').min(0).max(30),
    pageIndex: _joi2.default.number().integer().min(1).required().default(1),
    pageSize: _joi2.default.number().integer().min(1).max(1000).required().default(10),
    sort: _joi2.default.string().allow('')
});

let updateInsight = exports.updateInsight = _joi2.default.object().keys({
    category: _joi2.default.number().integer().required(),
    dataSourceId: _joi2.default.number().integer().allow(null)
});

let cludesJoi = _joi2.default.object({
    logicalConnective: _joi2.default.string(),
    rules: _joi2.default.array().allow([]).items(_joi2.default.array().allow([]).items(_joi2.default.object({
        type: _joi2.default.number().integer(),
        segmentId: _joi2.default.string(),
        tagId: _joi2.default.string(),
        value: _joi2.default.any()
    })))
});

let keyMapsJoi = _joi2.default.array().allow([]).items(_joi2.default.object({
    userIdTypeName: _joi2.default.string(),
    encryptType: _joi2.default.number().integer(),
    columnName: _joi2.default.string().allow('', null),
    columnIndex: _joi2.default.number().integer(),
    thirdUserIdTypeName: _joi2.default.string().allow('', null),
    category: _joi2.default.number().integer(),
    dataSourceId: _joi2.default.number().integer().allow('', null)
}));

let create = exports.create = _joi2.default.object().keys({
    name: _joi2.default.string().required().max(50),
    type: _joi2.default.number().integer().required(),
    segmentGroupId: _joi2.default.number().integer().required(),
    segmentRules: _joi2.default.object({
        magnificationRules: _joi2.default.object().keys({
            baseSegment: _joi2.default.string().required(),
            lookalikePercent: _joi2.default.number(),
            magnificationTimes: _joi2.default.number().integer().required(),
            featureTags: _joi2.default.array().allow([])
        }),
        firstPartyRules: _joi2.default.object().keys({
            mergeRule: _joi2.default.number().integer(),
            includes: cludesJoi,
            excludes: cludesJoi
        }),
        thirdPartyRules: _joi2.default.object().keys({
            dataSourceId: _joi2.default.number().integer(),
            includes: cludesJoi,
            excludes: cludesJoi
        }),
        fileRules: _joi2.default.object().keys({
            filePath: _joi2.default.string(),
            providerId: _joi2.default.number().integer(),
            inStorage: _joi2.default.number().integer(),
            keyMaps: keyMapsJoi,
            encoding: _joi2.default.string()
        }),
        logicalConnective: _joi2.default.string()
    }),
    insight: _joi2.default.array().required().allow([]),
    remark: _joi2.default.string().allow('', null).min(0).max(250),

    updatePeriod: _joi2.default.number().integer(),
    expires: _joi2.default.string().allow('', null),
    isForever: _joi2.default.number().integer().valid([0, 1]),

    insightUpdatePeriod: _joi2.default.number().integer(),
    insightExpires: _joi2.default.string().allow('', null),
    insightIsForever: _joi2.default.number().integer().valid([0, 1]),

    idMergeUpdatePeriod: _joi2.default.number().integer(),
    idMergeExpires: _joi2.default.string().allow('', null),
    idMergeIsForever: _joi2.default.number().integer().valid([0, 1]),

    isOpenIdMerge: _joi2.default.number().integer().valid([0, 1]),
    isOpenCampaignReport: _joi2.default.number().integer().valid([0, 1])
});
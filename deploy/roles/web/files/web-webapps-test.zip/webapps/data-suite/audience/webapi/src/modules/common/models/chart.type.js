'use strict';

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Chart_type', {
        id: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: true,
            defaultValue: null
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null
        },
        usedForMultipleTag: {
            type: DataTypes.INTEGER(10).UNSIGNED,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: 1,
            field: 'used_for_multiple_tag'
        }

    }, {
        tableName: 'chart_type',
        timestamps: false
    });
};
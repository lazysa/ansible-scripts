'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});

var _tagGroup = require('./tagGroup.controller');

var ctrl = _interopRequireWildcard(_tagGroup);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
    prefix: '/tagGroup'
});

//常量

router.get('/first/list', ctrl.firstPartyList);

router.get('/third/:dataSourceId/list', ctrl.thirdPartyList);

router.post('/', ctrl.create);
router.delete('/:tagGroupId', ctrl.remove);
router.put('/:tagGroupId', ctrl.update);

exports.default = router;
'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.validateRules = exports.displaySequenceUpdate = exports.bulkCreateBody = exports.create = exports.TagValuePages = undefined;

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

// import {Enums} from '../../config/consts';

let TagValuePages = exports.TagValuePages = _joi2.default.object().keys({
    keywords: _joi2.default.string().allow('').min(0).max(30),
    pageIndex: _joi2.default.number().integer().min(1).required().default(1),
    pageSize: _joi2.default.number().integer().min(1).max(1000).required().default(10),
    sort: _joi2.default.string().allow('')
});

let create = exports.create = _joi2.default.object().keys({
    name: _joi2.default.string().required().max(25),
    type: _joi2.default.number().integer().default(1),
    tagId: _joi2.default.string().required(),
    valueRules: _joi2.default.string(),
    tagValueRules: _joi2.default.object(),
    remark: _joi2.default.string().allow('', null).min(0).max(250)
});

let bulkCreateBody = exports.bulkCreateBody = _joi2.default.object().keys({
    inStorage: _joi2.default.number().integer().default(0),
    encoding: _joi2.default.string(),
    fileName: _joi2.default.string().required(),
    selectField: _joi2.default.string().required(),
    tagId: _joi2.default.string().required(),
    fieldMapList: _joi2.default.array(),
    tagValueList: _joi2.default.array()
});

let displaySequenceUpdate = exports.displaySequenceUpdate = _joi2.default.object().keys({
    displaySequenceArray: _joi2.default.array().items(_joi2.default.object().keys({
        tagValueId: _joi2.default.string().required(),
        displaySequence: _joi2.default.number().integer().min(1).max(10000000)
    })).min(1)
});

let validateRules = exports.validateRules = _joi2.default.object().keys({
    rules: _joi2.default.string().required().max(250)
});
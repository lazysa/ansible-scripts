ALTER TABLE `audience`.`first_party_tag_value`
ADD COLUMN `display_sequence` INT(10) NOT NULL DEFAULT 0 AFTER `priority`;

ALTER TABLE `audience`.`third_party_tag_value`
ADD COLUMN `display_sequence` INT(10) NOT NULL DEFAULT 0 AFTER `updated_at`;


ALTER TABLE `audience`.`first_party_tag_value`
CHANGE COLUMN `data_status` `data_status` TINYINT(4) NOT NULL DEFAULT 1 COMMENT '1.生成中 2.正常 3.异常' ;
ALTER TABLE `audience`.`segment`
CHANGE COLUMN `update_period` `update_period` TINYINT(4) NOT NULL DEFAULT 5 COMMENT '更新周期' ;
ALTER TABLE `audience`.`first_party_tag`
CHANGE COLUMN `update_period` `update_period` TINYINT(4) NOT NULL DEFAULT 5 COMMENT '更新周期';



--INSERT INTO `audience`.`update_period` (`id`, `name`, `data_source_id`, `status`) VALUES ('5', '自动更新', '1', '1');


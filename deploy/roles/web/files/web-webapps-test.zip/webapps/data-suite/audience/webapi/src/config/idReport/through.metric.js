"use strict";

Object.defineProperty(exports, "__esModule", {
    value: true
});
let throughMetrics = [{
    "id": "idType",
    "name": "ID类型1",
    "vtype": "string"
}, {
    "id": "comparedId",
    "name": "ID类型2",
    "vtype": "string"
}, {
    "id": "ccidCount",
    "name": "ID类型1的归并用户数",
    "vtype": "number"
}, {
    "id": "comparedIdCount",
    "name": "ID类型2的归并用户数",
    "vtype": "number"
}, {
    "id": "idPercentage",
    "name": "原始ID比例",
    "vtype": "decimal"
}, {
    "id": "throughCount",
    "name": "打通用户数",
    "vtype": "number"
}, {
    "id": "throughPercentage",
    "name": "打通率",
    "vtype": "percent"
}];

exports.default = throughMetrics;
alter table `audience`.`first_party_tag_value` CHANGE COLUMN `name` `name` varchar(255) null default '';


ALTER TABLE `audience`.`third_party_tag` 
ADD COLUMN `remark` VARCHAR(255) NULL AFTER `chart_type`;

ALTER TABLE `audience`.`third_party_tag` 
CHANGE COLUMN `chart_type` `chart_type` VARCHAR(255) NULL default '';


ALTER TABLE `audience`.`first_party_tag` 
ADD COLUMN `chart_type` VARCHAR(255)  NULL AFTER `updated_at`;

ALTER TABLE `audience`.`first_party_tag` 
ADD COLUMN `belonged_table_name` VARCHAR(255) NULL AFTER `chart_type`;


ALTER TABLE `audience`.`first_party_tag` 
ADD COLUMN `tag_level` TINYINT(4) NOT NULL DEFAULT 1 AFTER `belonged_table_name` ;

ALTER TABLE `audience`.`first_party_tag` 
ADD COLUMN `record_editable` TINYINT(4) NOT NULL DEFAULT 1 AFTER `tag_level` ;



'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.remove = exports.removeValidate = exports.removeTagValueBaseAuth = exports.removeTagValueAuth = exports.thirdDisplaySequenceUpdate = exports.firstDisplaySequenceUpdate = exports.update = exports.validateRules = exports.upload = exports.bulkCreate = exports.query = exports.create = exports.thirdPartyPages = exports.thirdPartyList = exports.firstPartyPages = exports.firstPartyNameList = exports.firstPartyList = undefined;

var _extends2 = require('babel-runtime/helpers/extends');

var _extends3 = _interopRequireDefault(_extends2);

var _objectWithoutProperties2 = require('babel-runtime/helpers/objectWithoutProperties');

var _objectWithoutProperties3 = _interopRequireDefault(_objectWithoutProperties2);

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

/**
 * 标签文件上传
 * @param ctx
 * @return {Promise.<{status}|{data, status}|*>}
 */
let upload = exports.upload = (() => {
    var _ref10 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        try {
            let { encoding } = ctx.request.query;
            ctx.res.connection.setTimeout(0);
            let file = ctx.request.body.files.file;
            const MAX_FILE_SIZE = 50 * 1024 * 2014;
            // const ACCEPT_FILE_TYPE = ['text/csv'];
            let { type, size } = file;
            // if (!ACCEPT_FILE_TYPE.includes(type)) throw new errors.UploadAcceptCSV();
            if (size > MAX_FILE_SIZE) throw new _errors2.default.UploadFileTooLarge();
            let fileName = _path2.default.basename(file.path) + '.csv';
            let fileFullName = _path2.default.join(_config2.default.fileDir, fileName);
            _fs2.default.renameSync(file.path, fileFullName);
            if (encoding === 'GBK') {
                fileFullName = yield (0, _helper.convertFileEncoding)(fileFullName, 'gb2312', 'utf8');
            }
            let preview = yield tagValueService.preview(fileFullName, true);
            data = (0, _extends3.default)({
                fileName
            }, preview);
        } catch (e) {
            return ctx.body = (0, _helper.wrapBody)(e);
        }
        ctx.body = (0, _helper.wrapBody)(null, data);
    });

    return function upload(_x9) {
        return _ref10.apply(this, arguments);
    };
})();

/**
 * 删除标签前的验证中间件
 * @param ctx
 * @param next
 * @return {Promise.<void>}
 */
let removeTagValueAuth = exports.removeTagValueAuth = (() => {
    var _ref16 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        try {
            let id = ctx.params.id;
            let usedSegmentList = yield (0, _segment.isUploadSegmentUsedBySegment)(id, 'value');
            if (usedSegmentList && usedSegmentList.length > 0) {
                throw new _errors2.default.TagValueSegmentUsed();
            }
            yield next();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function removeTagValueAuth(_x14, _x15) {
        return _ref16.apply(this, arguments);
    };
})();

let removeTagValueBaseAuth = exports.removeTagValueBaseAuth = (() => {
    var _ref17 = (0, _asyncToGenerator3.default)(function* (ctx, next) {
        try {
            let id = ctx.params.id;
            let tagValueGenerating = yield tagValueService.isTagValueGenerating(id);
            if (tagValueGenerating) {
                throw new _errors2.default.TagValueAtGenerating();
            }
            let analyticsValidateRes = yield tagValueService.isTagValueUsedByCampaignOrSite(id);
            if (analyticsValidateRes) {
                if (analyticsValidateRes['site']) throw _errors2.default.TagValueSiteUsed();
                if (analyticsValidateRes['campaign']) throw _errors2.default.TagValueCampaignUsed();
            }

            yield next();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
    });

    return function removeTagValueBaseAuth(_x16, _x17) {
        return _ref17.apply(this, arguments);
    };
})();

/**
 * 只是返回占用人群的逻辑
 * @param ctx
 * @return {{status}|{data, status}|*}
 */


var _helper = require('../common/util/helper');

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _tagValue = require('./tagValue.service');

var tagValueService = _interopRequireWildcard(_tagValue);

var _segment = require('../segment/segment.service');

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _config = require('../../config/config');

var _config2 = _interopRequireDefault(_config);

var _consts = require('../../config/consts');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

const { TagValueType } = _consts.Enums;
let firstPartyList = exports.firstPartyList = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let tagId = ctx.params.tagId;
            data = yield tagValueService.firstPartyList(tagId);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function firstPartyList(_x) {
        return _ref.apply(this, arguments);
    };
})();

let firstPartyNameList = exports.firstPartyNameList = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let tagId = ctx.params.tagId;
            data = yield tagValueService.firstPartyList(tagId, { type: { $in: [TagValueType.code, TagValueType.constructor] } });
            data = data && data.map(function (z) {
                return z.name;
            });
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function firstPartyNameList(_x2) {
        return _ref2.apply(this, arguments);
    };
})();

let firstPartyPages = exports.firstPartyPages = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let tagId = ctx.params.tagId;
            let query = ctx.request.query;
            let offset = query.pageSize * (query.pageIndex - 1);
            let limit = +query.pageSize;
            let keywords = query.keywords;
            let where = {
                tagId: tagId
            };
            where = tagValueService.getWhere(where, keywords);

            let conditions = {
                attributes: ['id', 'name', 'type', 'coverage', 'dataStatus', 'createdAt', 'refreshTime', 'displaySequence'],
                offset,
                limit,
                where,
                order: [['displaySequence', 'ASC'], ['createdAt', 'DESC']]
            };
            let { rows: list, count: total } = yield tagValueService.firstPartyPages(conditions);

            data = {
                total: total,
                list: list,
                pageSize: query.pageSize,
                pageIndex: query.pageIndex
            };
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function firstPartyPages(_x3) {
        return _ref3.apply(this, arguments);
    };
})();

let thirdPartyList = exports.thirdPartyList = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let tagId = ctx.params.tagId;
            data = yield tagValueService.thirdPartyList(tagId);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function thirdPartyList(_x4) {
        return _ref4.apply(this, arguments);
    };
})();

let thirdPartyPages = exports.thirdPartyPages = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let tagId = ctx.params.tagId;
            let query = ctx.request.query;
            let offset = query.pageSize * (query.pageIndex - 1);
            let limit = +query.pageSize;
            let keywords = query.keywords;
            let where = {
                tagId: tagId
            };
            where = tagValueService.getWhere(where, keywords);

            let conditions = {
                attributes: ['id', 'name', 'tagValueGroupId', 'displaySequence'],
                offset,
                limit,
                where,
                order: [['displaySequence', 'ASC'], ['createdAt', 'DESC']],
                raw: true
            };
            let { rows: list, count: total } = yield tagValueService.thirdPartyPages(conditions);
            /**
             * 查询标签值的父级，拼成tagValueGroupDisplay展示
             */
            let groupMap = yield tagValueService.getTagValueParentById(list.map(function (item) {
                return item.tagValueGroupId;
            }));
            list.forEach(function (item) {
                item.tagValueGroupDisplay = groupMap[item.tagValueGroupId];
            });
            data = {
                total: total,
                list: list,
                pageSize: query.pageSize,
                pageIndex: query.pageIndex
            };
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function thirdPartyPages(_x5) {
        return _ref5.apply(this, arguments);
    };
})();

/**
 *
 * @param ctx
 * @return {{status}|{data, status}|*}
 */
let create = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let { tagValueRules, tagId } = body;
            let { type, rules } = tagValueRules;

            switch (type) {

                case TagValueType.code:
                    let { expression } = rules;
                    let validateResult = yield tagValueService.validateSqlSyntax(expression);
                    if (validateResult.validate) {
                        body['valueRules'] = expression;
                        body['parseRules'] = validateResult['parseRules'];
                    } else {
                        throw new _errors2.default.TagValueRuleInvlide(validateResult.message);
                    }
                    data = yield tagValueService.create(body);
                    break;

                case TagValueType.constructor:
                    body['type'] = type;
                    let _ref7 = yield tagValueService.createConstructorTagAndTagValue(tagValueRules, tagId),
                        { tagValueRules: finalTagValueRules } = _ref7,
                        relyOnObj = (0, _objectWithoutProperties3.default)(_ref7, ['tagValueRules']);
                    body['tagValueRules'] = finalTagValueRules;
                    data = yield tagValueService.create(body);
                    yield tagValueService.createTagRelyOn(relyOnObj, data && data.id);
                    break;
            }
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function create(_x6) {
        return _ref6.apply(this, arguments);
    };
})();

exports.create = create;
let query = exports.query = (() => {
    var _ref8 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let id = ctx.params.id;
            /**
             * TODO 标签参数值 valueRules的验证
             * @type {body}
             */
            data = yield tagValueService.query(id);
            let tempTagValueRules = JSON.parse(data.tagValueRules);
            data['tagValueRules'] = tempTagValueRules;
            data['relySegmentMap'] = yield tagValueService.queryRelyOnSegmentId(tempTagValueRules);
            data['relyMap'] = yield tagValueService.queryRelyOnInfo(id);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function query(_x7) {
        return _ref8.apply(this, arguments);
    };
})();

/**
 * 批量新建标签
 * @param ctx
 * @return {Promise.<{status}|{data, status}|*>}
 */
let bulkCreate = exports.bulkCreate = (() => {
    var _ref9 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let { tagId, fileName, fieldMapList, inStorage, selectField, tagValueList, encoding } = ctx.request.body;

            let uploadObj = yield (0, _segment.uploadFile)(fileName);
            let fileMD5Obj = yield (0, _segment.getFileMD5)(_path2.default.join(_config2.default.fileDir, fileName));
            data = yield tagValueService.createTagValueUploadLog({
                tagId,
                filePath: fileName,
                rules: (0, _extends3.default)({}, uploadObj, fileMD5Obj, {
                    encoding,
                    inStorage,
                    selectField,
                    fieldMapList
                })
            });
            yield (0, _segment.addTagValueUploadTask)(data && data.id);
            yield tagValueService.bulkCreateTagValue(tagValueList, tagId, uploadObj.flag, inStorage);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function bulkCreate(_x8) {
        return _ref9.apply(this, arguments);
    };
})();let validateRules = exports.validateRules = (() => {
    var _ref11 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            // data = await tagValueService.validateRules(body.rules);
            data = yield tagValueService.validateSqlSyntax(body.rules);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(null, {
                validate: false,
                message: ex.message
            });
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function validateRules(_x10) {
        return _ref11.apply(this, arguments);
    };
})();

let update = (() => {
    var _ref12 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let id = ctx.params.id;
            let { tagValueRules, tagId, type, name } = body;
            let { rules } = tagValueRules;
            switch (type) {
                case TagValueType.upload:
                    data = yield tagValueService.update(id, { name });
                    break;
                case TagValueType.code:
                    let { expression } = rules;
                    let validateResult = yield tagValueService.validateSqlSyntax(expression);
                    if (validateResult.validate) {
                        body['valueRules'] = expression;
                        body['parseRules'] = validateResult['parseRules'];
                    } else {
                        throw new _errors2.default.TagValueRuleInvlide(validateResult.message);
                    }
                    yield tagValueService.shouldUpdateTagValueStatus(id, body.valueRules);
                    data = yield tagValueService.update(id, body);
                    break;

                case TagValueType.constructor:
                    body['type'] = type;
                    let _ref13 = yield tagValueService.updateConstructorTagAndTagValue(id, tagValueRules, tagId),
                        { tagValueRules: finalTagValueRules, relyOnSourceTagValueId } = _ref13,
                        relyOnObj = (0, _objectWithoutProperties3.default)(_ref13, ['tagValueRules', 'relyOnSourceTagValueId']);
                    body['tagValueRules'] = finalTagValueRules;
                    data = yield tagValueService.update(id, body);
                    yield tagValueService.updateTagRelyOn(relyOnObj, id, relyOnSourceTagValueId);
                    break;
            }
        } catch (ex) {
            console.log(ex);
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function update(_x11) {
        return _ref12.apply(this, arguments);
    };
})();

/**
 * 第一方更新显示序列
 * @param ctx
 * @return {{status}|{data, status}|*}
 */
exports.update = update;
let firstDisplaySequenceUpdate = exports.firstDisplaySequenceUpdate = (() => {
    var _ref14 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let { displaySequenceArray } = body;
            let tagValueList = yield tagValueService.getFirstDisplaySequenceArray(displaySequenceArray);
            let sortSequenceList = yield tagValueService.displaySequenceUpdate(displaySequenceArray, tagValueList);
            data = yield tagValueService.updateFirstDisplaySequence(sortSequenceList);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function firstDisplaySequenceUpdate(_x12) {
        return _ref14.apply(this, arguments);
    };
})();

/**
 * 第三方更新显示序列
 * @param ctx
 * @return {{status}|{data, status}|*}
 */
let thirdDisplaySequenceUpdate = exports.thirdDisplaySequenceUpdate = (() => {
    var _ref15 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let body = ctx.request.body;
            let { displaySequenceArray } = body;
            let tagValueList = yield tagValueService.getThirdDisplaySequenceArray(displaySequenceArray);
            let sortSequenceList = yield tagValueService.displaySequenceUpdate(displaySequenceArray, tagValueList);
            data = yield tagValueService.updateThirdDisplaySequence(sortSequenceList);
        } catch (ex) {

            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function thirdDisplaySequenceUpdate(_x13) {
        return _ref15.apply(this, arguments);
    };
})();let removeValidate = exports.removeValidate = (() => {
    var _ref18 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let id = ctx.params.id;
            data = yield (0, _segment.isUploadSegmentUsedBySegment)(id, 'value');
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function removeValidate(_x18) {
        return _ref18.apply(this, arguments);
    };
})();

/**
 * 只是删除标签的逻辑
 * @param ctx
 * @return {Promise.<{status}|{data, status}|*>}
 */
let remove = exports.remove = (() => {
    var _ref19 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let id = ctx.params.id;
            data = yield tagValueService.remove(id);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function remove(_x19) {
        return _ref19.apply(this, arguments);
    };
})();
update first_party_tag_value
set value_rules=concat('array_contains(split(geoTag.',tag_id,','';''),''',id,''')')
where tag_id='FT71';

update first_party_tag_value
set value_rules=concat('array_contains(split(semTag.',tag_id,','';''),''',id,''')')
where tag_id='FT72';

update first_party_tag_value
set value_rules=concat('array_contains(split(campaignTag.',tag_id,','';''),''',id,''')')
where tag_id in ('FT73','FT74');

update first_party_tag_value
set value_rules=concat('array_contains(split(siteTag.',tag_id,','';''),''',id,''')')
where tag_id = 'FT75';

update first_party_tag_value
set value_rules=concat('array_contains(split(semanticsTag.',tag_id,','';''),''',id,''')')
where tag_id in ('FT2','FT3','FT4','FT5','FT6','FT7','FT8','FT9','FT10','FT11','FT12','FT13','FT14','FT15','FT17','FT18','FT19','FT20','FT21','FT22','FT24','FT25','FT26','FT28','FT29','FT30','FT31','FT32','FT33','FT34','FT35','FT36','FT37','FT38','FT39','FT41','FT42','FT43','FT44','FT45','FT46','FT47','FT49','FT50','FT51','FT52','FT53','FT54','FT55','FT56','FT57','FT58','FT59','FT60','FT61','FT62','FT63','FT64','FT65','FT66','FT80','FT81','FT82','FT83','FT84','FT85','FT86','FT87');

update first_party_tag_value
set value_rules=concat('array_contains(split(publisherTag.',tag_id,','';''),''',id,''')')
where tag_id in ('FT68','FT69','FT70');



-- INSERT INTO `audience`.`first_party_tag` (`id`, `name`, `tag_type`, `tag_group_id`, `merge_rule`, `update_period`, `remark`, `status`, `created_at`, `updated_at`) VALUES ('FT88', '省份', '1', '9', '15', '4', '', '1', '2016-10-13 11:18:49', '2016-10-13 11:18:49');
-- INSERT INTO `audience`.`first_party_tag` (`id`, `name`, `tag_type`, `tag_group_id`, `merge_rule`, `update_period`, `remark`, `status`, `created_at`, `updated_at`) VALUES ('FT89', '城市级别', '1', '9', '15', '4', '', '1', '2016-10-13 11:18:49', '2016-10-13 11:18:49');
-- INSERT INTO `audience`.`first_party_tag` (`id`, `name`, `tag_type`, `tag_group_id`, `merge_rule`, `update_period`, `remark`, `status`, `created_at`, `updated_at`) VALUES ('FT90', '大区', '1', '9', '15', '4', '', '1', '2016-10-13 11:18:49', '2016-10-13 11:18:49');

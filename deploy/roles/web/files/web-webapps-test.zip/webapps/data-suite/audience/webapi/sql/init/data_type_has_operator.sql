/*
Navicat MySQL Data Transfer

Source Server         : dev
Source Server Version : 50711
Source Host           : cc-mysql-test.c5s7vgxpiybm.rds.cn-north-1.amazonaws.com.cn:3306
Source Database       : audience

Target Server Type    : MYSQL
Target Server Version : 50711
File Encoding         : 65001

Date: 2017-09-15 17:14:00
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for data_type_has_operator
-- ----------------------------
DROP TABLE IF EXISTS `data_type_has_operator`;
CREATE TABLE `data_type_has_operator` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `data_type` tinyint(4) DEFAULT NULL COMMENT '数据类型',
  `ui_type` tinyint(4) DEFAULT NULL COMMENT '1 筛选器 2 过滤器',
  `operator_id` int(11) DEFAULT NULL COMMENT '操作符id',
  `status` tinyint(4) unsigned DEFAULT '1' COMMENT '状态 0:删除 1:正常 2:禁用',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8 COMMENT='数据类型和操作符关联表';

-- ----------------------------
-- Records of data_type_has_operator
-- ----------------------------
INSERT INTO `data_type_has_operator` VALUES ('1', '4', '1', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('2', '4', '2', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('3', '4', '1', '18', '0');
INSERT INTO `data_type_has_operator` VALUES ('4', '4', '2', '18', '0');
INSERT INTO `data_type_has_operator` VALUES ('5', '4', '1', '14', '0');
INSERT INTO `data_type_has_operator` VALUES ('6', '4', '2', '14', '0');
INSERT INTO `data_type_has_operator` VALUES ('7', '4', '1', '13', '1');
INSERT INTO `data_type_has_operator` VALUES ('8', '4', '2', '13', '1');
INSERT INTO `data_type_has_operator` VALUES ('9', '4', '1', '10', '1');
INSERT INTO `data_type_has_operator` VALUES ('10', '4', '2', '10', '1');
INSERT INTO `data_type_has_operator` VALUES ('11', '5', '1', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('12', '5', '2', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('13', '5', '1', '18', '1');
INSERT INTO `data_type_has_operator` VALUES ('14', '5', '2', '18', '1');
INSERT INTO `data_type_has_operator` VALUES ('15', '5', '1', '14', '1');
INSERT INTO `data_type_has_operator` VALUES ('16', '5', '2', '14', '1');
INSERT INTO `data_type_has_operator` VALUES ('17', '5', '1', '13', '1');
INSERT INTO `data_type_has_operator` VALUES ('18', '5', '2', '13', '1');
INSERT INTO `data_type_has_operator` VALUES ('19', '5', '1', '10', '1');
INSERT INTO `data_type_has_operator` VALUES ('20', '5', '2', '10', '1');
INSERT INTO `data_type_has_operator` VALUES ('21', '9', '1', '19', '1');
INSERT INTO `data_type_has_operator` VALUES ('22', '9', '2', '19', '1');
INSERT INTO `data_type_has_operator` VALUES ('23', '9', '1', '1', '1');
INSERT INTO `data_type_has_operator` VALUES ('24', '9', '2', '1', '1');
INSERT INTO `data_type_has_operator` VALUES ('25', '9', '1', '2', '1');
INSERT INTO `data_type_has_operator` VALUES ('26', '9', '2', '2', '1');
INSERT INTO `data_type_has_operator` VALUES ('27', '9', '1', '17', '1');
INSERT INTO `data_type_has_operator` VALUES ('28', '9', '2', '17', '1');
INSERT INTO `data_type_has_operator` VALUES ('29', '9', '1', '15', '1');
INSERT INTO `data_type_has_operator` VALUES ('30', '9', '2', '15', '1');
INSERT INTO `data_type_has_operator` VALUES ('31', '9', '1', '23', '1');
INSERT INTO `data_type_has_operator` VALUES ('32', '9', '2', '23', '1');
INSERT INTO `data_type_has_operator` VALUES ('33', '6', '1', '9', '2');
INSERT INTO `data_type_has_operator` VALUES ('34', '6', '2', '9', '2');
INSERT INTO `data_type_has_operator` VALUES ('35', '6', '1', '16', '2');
INSERT INTO `data_type_has_operator` VALUES ('36', '6', '2', '16', '2');
INSERT INTO `data_type_has_operator` VALUES ('37', '10', '1', '11', '1');
INSERT INTO `data_type_has_operator` VALUES ('38', '10', '2', '11', '1');
INSERT INTO `data_type_has_operator` VALUES ('39', '12', '1', '19', '1');
INSERT INTO `data_type_has_operator` VALUES ('40', '12', '2', '19', '0');
INSERT INTO `data_type_has_operator` VALUES ('41', '12', '1', '1', '1');
INSERT INTO `data_type_has_operator` VALUES ('42', '12', '2', '1', '1');
INSERT INTO `data_type_has_operator` VALUES ('43', '1', '1', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('44', '1', '2', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('45', '1', '1', '3', '2');
INSERT INTO `data_type_has_operator` VALUES ('46', '1', '2', '3', '1');
INSERT INTO `data_type_has_operator` VALUES ('47', '1', '1', '5', '2');
INSERT INTO `data_type_has_operator` VALUES ('48', '1', '2', '5', '1');
INSERT INTO `data_type_has_operator` VALUES ('49', '1', '1', '6', '1');
INSERT INTO `data_type_has_operator` VALUES ('50', '1', '2', '6', '1');
INSERT INTO `data_type_has_operator` VALUES ('51', '1', '1', '20', '2');
INSERT INTO `data_type_has_operator` VALUES ('52', '1', '2', '20', '1');
INSERT INTO `data_type_has_operator` VALUES ('53', '1', '1', '21', '1');
INSERT INTO `data_type_has_operator` VALUES ('54', '1', '2', '21', '1');
INSERT INTO `data_type_has_operator` VALUES ('55', '1', '1', '16', '1');
INSERT INTO `data_type_has_operator` VALUES ('56', '1', '2', '16', '1');
INSERT INTO `data_type_has_operator` VALUES ('57', '15', '1', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('58', '15', '2', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('59', '15', '1', '3', '2');
INSERT INTO `data_type_has_operator` VALUES ('60', '15', '2', '3', '1');
INSERT INTO `data_type_has_operator` VALUES ('61', '15', '1', '5', '2');
INSERT INTO `data_type_has_operator` VALUES ('62', '15', '2', '5', '1');
INSERT INTO `data_type_has_operator` VALUES ('63', '15', '1', '6', '1');
INSERT INTO `data_type_has_operator` VALUES ('64', '15', '2', '6', '1');
INSERT INTO `data_type_has_operator` VALUES ('65', '15', '1', '20', '2');
INSERT INTO `data_type_has_operator` VALUES ('66', '15', '2', '20', '1');
INSERT INTO `data_type_has_operator` VALUES ('67', '15', '1', '21', '1');
INSERT INTO `data_type_has_operator` VALUES ('68', '15', '2', '21', '1');
INSERT INTO `data_type_has_operator` VALUES ('69', '15', '1', '16', '1');
INSERT INTO `data_type_has_operator` VALUES ('70', '15', '2', '16', '1');
INSERT INTO `data_type_has_operator` VALUES ('71', '11', '1', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('72', '11', '2', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('73', '11', '1', '3', '2');
INSERT INTO `data_type_has_operator` VALUES ('74', '11', '2', '3', '1');
INSERT INTO `data_type_has_operator` VALUES ('75', '11', '1', '5', '2');
INSERT INTO `data_type_has_operator` VALUES ('76', '11', '2', '5', '1');
INSERT INTO `data_type_has_operator` VALUES ('77', '11', '1', '6', '1');
INSERT INTO `data_type_has_operator` VALUES ('78', '11', '2', '6', '1');
INSERT INTO `data_type_has_operator` VALUES ('79', '11', '1', '20', '2');
INSERT INTO `data_type_has_operator` VALUES ('80', '11', '2', '20', '1');
INSERT INTO `data_type_has_operator` VALUES ('81', '11', '1', '21', '1');
INSERT INTO `data_type_has_operator` VALUES ('82', '11', '2', '21', '1');
INSERT INTO `data_type_has_operator` VALUES ('83', '11', '1', '16', '1');
INSERT INTO `data_type_has_operator` VALUES ('84', '11', '2', '16', '1');
INSERT INTO `data_type_has_operator` VALUES ('85', '14', '1', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('86', '14', '2', '9', '1');
INSERT INTO `data_type_has_operator` VALUES ('87', '14', '1', '3', '2');
INSERT INTO `data_type_has_operator` VALUES ('88', '14', '2', '3', '1');
INSERT INTO `data_type_has_operator` VALUES ('89', '14', '1', '5', '2');
INSERT INTO `data_type_has_operator` VALUES ('90', '14', '2', '5', '1');
INSERT INTO `data_type_has_operator` VALUES ('91', '14', '1', '6', '1');
INSERT INTO `data_type_has_operator` VALUES ('92', '14', '2', '6', '1');
INSERT INTO `data_type_has_operator` VALUES ('93', '14', '1', '20', '2');
INSERT INTO `data_type_has_operator` VALUES ('94', '14', '2', '20', '1');
INSERT INTO `data_type_has_operator` VALUES ('95', '14', '1', '21', '1');
INSERT INTO `data_type_has_operator` VALUES ('96', '14', '2', '21', '1');
INSERT INTO `data_type_has_operator` VALUES ('97', '14', '1', '16', '1');
INSERT INTO `data_type_has_operator` VALUES ('98', '14', '2', '16', '1');
INSERT INTO `data_type_has_operator` VALUES ('99', '8', '1', '17', '1');
INSERT INTO `data_type_has_operator` VALUES ('100', '8', '2', '17', '1');
INSERT INTO `data_type_has_operator` VALUES ('101', '8', '1', '15', '1');
INSERT INTO `data_type_has_operator` VALUES ('102', '8', '2', '15', '1');
INSERT INTO `data_type_has_operator` VALUES ('103', '8', '1', '1', '1');
INSERT INTO `data_type_has_operator` VALUES ('104', '8', '2', '1', '1');
INSERT INTO `data_type_has_operator` VALUES ('105', '8', '1', '2', '1');
INSERT INTO `data_type_has_operator` VALUES ('106', '8', '2', '2', '1');
INSERT INTO `data_type_has_operator` VALUES ('107', '8', '1', '19', '1');
INSERT INTO `data_type_has_operator` VALUES ('108', '8', '2', '19', '1');
INSERT INTO `data_type_has_operator` VALUES ('109', '8', '1', '24', '1');
INSERT INTO `data_type_has_operator` VALUES ('110', '8', '2', '24', '1');
INSERT INTO `data_type_has_operator` VALUES ('111', '8', '1', '23', '1');
INSERT INTO `data_type_has_operator` VALUES ('112', '8', '2', '23', '1');
INSERT INTO `data_type_has_operator` VALUES ('113', '8', '1', '22', '1');
INSERT INTO `data_type_has_operator` VALUES ('114', '8', '2', '22', '1');
INSERT INTO `data_type_has_operator` VALUES ('115', '2', '1', '17', '1');
INSERT INTO `data_type_has_operator` VALUES ('116', '2', '2', '17', '1');
INSERT INTO `data_type_has_operator` VALUES ('117', '2', '1', '15', '1');
INSERT INTO `data_type_has_operator` VALUES ('118', '2', '2', '15', '1');
INSERT INTO `data_type_has_operator` VALUES ('119', '2', '1', '1', '1');
INSERT INTO `data_type_has_operator` VALUES ('120', '2', '2', '1', '1');
INSERT INTO `data_type_has_operator` VALUES ('121', '2', '1', '2', '1');
INSERT INTO `data_type_has_operator` VALUES ('122', '2', '2', '2', '1');
INSERT INTO `data_type_has_operator` VALUES ('123', '2', '1', '19', '1');
INSERT INTO `data_type_has_operator` VALUES ('124', '2', '2', '19', '1');
INSERT INTO `data_type_has_operator` VALUES ('125', '2', '1', '24', '1');
INSERT INTO `data_type_has_operator` VALUES ('126', '2', '2', '24', '1');
INSERT INTO `data_type_has_operator` VALUES ('127', '13', '1', '17', '1');
INSERT INTO `data_type_has_operator` VALUES ('128', '13', '2', '17', '1');
INSERT INTO `data_type_has_operator` VALUES ('129', '13', '1', '15', '1');
INSERT INTO `data_type_has_operator` VALUES ('130', '13', '2', '15', '1');
INSERT INTO `data_type_has_operator` VALUES ('131', '13', '1', '1', '1');
INSERT INTO `data_type_has_operator` VALUES ('132', '13', '2', '1', '1');
INSERT INTO `data_type_has_operator` VALUES ('133', '13', '1', '2', '1');
INSERT INTO `data_type_has_operator` VALUES ('134', '13', '2', '2', '1');
INSERT INTO `data_type_has_operator` VALUES ('135', '13', '1', '19', '1');
INSERT INTO `data_type_has_operator` VALUES ('136', '13', '2', '19', '1');
INSERT INTO `data_type_has_operator` VALUES ('137', '13', '1', '24', '1');
INSERT INTO `data_type_has_operator` VALUES ('138', '13', '2', '24', '1');
INSERT INTO `data_type_has_operator` VALUES ('139', '10', '1', '7', '1');
INSERT INTO `data_type_has_operator` VALUES ('140', '10', '1', '8', '1');
SET FOREIGN_KEY_CHECKS=1;

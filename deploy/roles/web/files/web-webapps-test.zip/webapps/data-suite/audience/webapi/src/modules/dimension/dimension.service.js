'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getActionMetricList = exports.getDimensionMetaList = exports.getActionDimensionAttrList = exports.getBusinessDataDimensionList = exports.getActionByBusiness = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

//业务中心API
let getActionByBusiness = exports.getActionByBusiness = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (businessId, actionId) {
        let list = yield _api.DataServiceApi.getBusinessActionList(businessId);
        return list.find(function (z) {
            return z.id === actionId;
        });
    });

    return function getActionByBusiness(_x, _x2) {
        return _ref.apply(this, arguments);
    };
})();
//业务中心API


let getBusinessDataDimensionList = exports.getBusinessDataDimensionList = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (businessId, apiName) {
        let list = yield _api.DataServiceApi.getBusinessDataDimensionList(businessId);
        return list.find(function (z) {
            if (apiName) return z.apiName == apiName;
            return z.isDefault;
        });
    });

    return function getBusinessDataDimensionList(_x3, _x4) {
        return _ref2.apply(this, arguments);
    };
})();
//业务中心API


let getActionDimensionAttrList = exports.getActionDimensionAttrList = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* ({ subjectId, actionId, businessId }, filterId) {
        let list = yield _api.DataServiceApi.getActionDimensionAttrList({ subjectId, actionId, businessId });
        return list.find(function (z) {
            return z.id === filterId;
        });
    });

    return function getActionDimensionAttrList(_x5, _x6) {
        return _ref3.apply(this, arguments);
    };
})();
//业务中心API


let getDimensionMetaList = exports.getDimensionMetaList = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (dimensionAttribute) {
        let list = yield _api.DataServiceApi.getDimensionMetaList(dimensionAttribute);
        return list && list.list;
    });

    return function getDimensionMetaList(_x7) {
        return _ref4.apply(this, arguments);
    };
})();

let getActionMetricList = exports.getActionMetricList = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* ({ subjectId, actionId, businessId }, metricsId) {
        let list = yield _api.DataServiceApi.getActionMetricList({ subjectId, actionId, businessId });
        return list.find(function (z) {
            return z.id === metricsId;
        });
    });

    return function getActionMetricList(_x8, _x9) {
        return _ref5.apply(this, arguments);
    };
})();

var _consts = require('../../config/consts');

var _helper = require('../common/util/helper');

var _api = require('../common/api');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
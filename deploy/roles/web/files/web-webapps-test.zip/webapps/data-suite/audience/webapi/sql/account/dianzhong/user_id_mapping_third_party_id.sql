/*
Navicat MySQL Data Transfer

Source Server         : dev
Source Server Version : 50711
Source Host           : cc-mysql-test.c5s7vgxpiybm.rds.cn-north-1.amazonaws.com.cn:3306
Source Database       : audience

Target Server Type    : MYSQL
Target Server Version : 50711
File Encoding         : 65001

Date: 2017-05-23 11:50:17
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for user_id_mapping_third_party_id
-- ----------------------------
DROP TABLE IF EXISTS `user_id_mapping_third_party_id`;
CREATE TABLE `user_id_mapping_third_party_id` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `third_user_id_type_name` varchar(255) NOT NULL,
  `first_user_id_type_name` varchar(255) NOT NULL,
  `data_source_id` int(10) unsigned NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of user_id_mapping_third_party_id
-- ----------------------------
INSERT INTO `user_id_mapping_third_party_id` VALUES ('1', 'imei_key', 'IMEI_MD5', '1', '1');
INSERT INTO `user_id_mapping_third_party_id` VALUES ('2', 'imei_key', 'IMEI', '1', '1');
INSERT INTO `user_id_mapping_third_party_id` VALUES ('3', 'imei_key', 'IMEI_SHA1', '1', '1');
INSERT INTO `user_id_mapping_third_party_id` VALUES ('4', 'phone_key', 'MOBILE_MD5', '1', '1');
INSERT INTO `user_id_mapping_third_party_id` VALUES ('5', 'phone_key', 'MOBILE', '1', '1');
INSERT INTO `user_id_mapping_third_party_id` VALUES ('6', 'phone_key', 'MOBILE_SHA1', '1', '1');
INSERT INTO `user_id_mapping_third_party_id` VALUES ('7', 'idfa_key', 'IDFA_MD5', '1', '1');
INSERT INTO `user_id_mapping_third_party_id` VALUES ('8', 'idfa_key', 'IDFA', '1', '1');
INSERT INTO `user_id_mapping_third_party_id` VALUES ('9', 'idfa_key', 'IDFA_SHA1', '1', '1');
SET FOREIGN_KEY_CHECKS=1;

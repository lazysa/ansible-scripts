ALTER TABLE `audience`.`insight_field`
ADD COLUMN `record_viewable` TINYINT(4) NOT NULL DEFAULT 1 AFTER `is_default`,
ADD COLUMN `status` TINYINT(4) NOT NULL DEFAULT 1 AFTER `record_viewable`;

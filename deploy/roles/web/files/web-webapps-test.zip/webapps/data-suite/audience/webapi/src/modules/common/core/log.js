'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.requestLog = exports.taskLog = exports.log = undefined;

var _path = require("path");

var _path2 = _interopRequireDefault(_path);

var _bunyan = require("bunyan");

var _bunyan2 = _interopRequireDefault(_bunyan);

var _config = require("../../../config/config");

var _config2 = _interopRequireDefault(_config);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let env = _config2.default.env;

let log = _bunyan2.default.createLogger({
    name: "webapi",
    streams: [{
        level: 'info',
        path: _path2.default.join(_config2.default.logDir, "/log.txt")
    }],
    serializers: {
        err: _bunyan2.default.stdSerializers.err,
        req: _bunyan2.default.stdSerializers.req,
        res: _bunyan2.default.stdSerializers.res
    }
});
log.level(_config2.default.logLevel);

//定日任务日志
let taskLog = _bunyan2.default.createLogger({
    name: "task",
    streams: [{
        level: 'info',
        path: _path2.default.join(_config2.default.logDir, "/tasklog.txt")
    }],
    serializers: {
        err: _bunyan2.default.stdSerializers.err,
        req: _bunyan2.default.stdSerializers.req,
        res: _bunyan2.default.stdSerializers.res
    }
});
taskLog.level('info');

let requestLog = _bunyan2.default.createLogger({
    name: 'request',
    streams: [{
        level: 'info',
        path: _path2.default.join(_config2.default.logDir, "/request-log.txt")
    }],
    serializers: {
        err: _bunyan2.default.stdSerializers.err,
        req: _bunyan2.default.stdSerializers.req,
        res: _bunyan2.default.stdSerializers.res
    }
});

if (env != "development") {
    process.on('SIGUSR2', function () {
        log.reopenFileStreams();
        taskLog.reopenFileStreams();
        requestLog.reopenFileStreams();
    });
} else {
    // process.once('SIGUSR2', function () {
    //     log.reopenFileStreams();
    //     process.kill(process.pid, 'SIGUSR2');
    // });
}

exports.log = log;
exports.taskLog = taskLog;
exports.requestLog = requestLog;
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});

var _business = require('./business.controller');

var ctrl = _interopRequireWildcard(_business);

var _koaRouter = require('koa-router');

var _koaRouter2 = _interopRequireDefault(_koaRouter);

var _permission = require('../../../common/util/permission.util');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

let router = (0, _koaRouter2.default)({
  prefix: '/api/v1/business'
});

/**
 * 获取开启活动效果报告的人群list
 */
router.get('/reportSegment', ctrl.authToken, ctrl.reportSegment);
/**
 * analytics给到的人群分组的list
 */
router.get('/segmentGroup/list', ctrl.authToken, ctrl.segmentGroupList);
/**
 * analytics给到的第一方和上传人群list接口
 */
// router.get('/segment/:segmentGroupId/firstAndUploadList',checkPermission('audience.segment.access'),constructorResource('segment'),ctrl.authToken, ctrl.firstAndUploadList);
router.get('/segment/:segmentGroupId/firstAndUploadList', ctrl.authToken, ctrl.firstAndUploadList);
// router.get('/segment/:segmentGroupId/firstList',checkPermission('audience.segment.access'),constructorResource('segment'),ctrl.authToken, ctrl.firstList);
router.get('/segment/:segmentGroupId/firstList', ctrl.authToken, ctrl.firstList);
/**
 * analytics根据标签值id查询name
 */
router.post('/tagValue/aliasByIds', ctrl.authToken, ctrl.tagValueAliasByIds);
router.get('/tagValue/firstAllList', ctrl.authToken, ctrl.firstAllList);
router.post('/segment/aliasByIds', ctrl.authToken, ctrl.segmentAliasByIds);
/**
 * analytics活动开启洞察报告 新建人群的接口
 */
router.post('/segment/campaign', (0, _permission.checkPermission)('audience.segment.create'), ctrl.createCampaign);
router.post('/segment/site', (0, _permission.checkPermission)('audience.segment.create'), ctrl.createSite);
router.put('/segment/campaign', ctrl.updateCampaignAndSite);
router.put('/segment/site', ctrl.updateCampaignAndSite);

exports.default = router;
'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
const DIMENSION_CHINESE = exports.DIMENSION_CHINESE = '维度';
const MAIN_DIMENSION_CHINESE = exports.MAIN_DIMENSION_CHINESE = '主维度';
const SEC_DIMENSION_CHINESE = exports.SEC_DIMENSION_CHINESE = '次级维度';
const NULL_CHINESE = exports.NULL_CHINESE = '无';
const ID_TYPE_CHINESE = exports.ID_TYPE_CHINESE = 'ID类型';
const SINGLE_ID_ANALYSIS_SHEET_NAME = exports.SINGLE_ID_ANALYSIS_SHEET_NAME = '单用户ID分析';
const THROUGH_ANALYSIS_SHEET_NAME = exports.THROUGH_ANALYSIS_SHEET_NAME = '重合分析';
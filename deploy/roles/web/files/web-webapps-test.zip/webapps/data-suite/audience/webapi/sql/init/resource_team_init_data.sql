insert into resource_team (team_id,resource_type,resource_id)
select 100 as team_id,'segment' as resource_type ,id from segment where status =1;
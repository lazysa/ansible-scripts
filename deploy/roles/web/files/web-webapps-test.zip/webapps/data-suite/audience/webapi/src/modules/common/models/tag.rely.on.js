'use strict';

var _stringify = require('babel-runtime/core-js/json/stringify');

var _stringify2 = _interopRequireDefault(_stringify);

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

module.exports = function (sequelize, DataTypes) {
    return sequelize.define('Tag_rely_on', {
        tagId: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'tag_id'
        },
        tagValueId: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: true,
            defaultValue: null,
            field: 'tag_value_id'
        },
        relyOnTagId: {
            type: DataTypes.STRING,
            allowNull: false,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            field: 'rely_on_tag_id'
        },
        relyOnTagValueId: {
            type: DataTypes.JSON,
            allowNull: true,
            autoIncrement: false,
            primaryKey: false,
            defaultValue: null,
            set: function (val) {
                try {
                    this.setDataValue('relyOnTagValueId', JSON.parse((0, _stringify2.default)(val)));
                } catch (err) {
                    return null;
                }
            },
            get: function (val) {
                try {
                    return this.getDataValue(val);
                } catch (err) {
                    return null;
                }
            },
            field: 'rely_on_tag_value_id'
        }
    }, {
        tableName: 'tag_rely_on',
        timestamps: false
    });
};
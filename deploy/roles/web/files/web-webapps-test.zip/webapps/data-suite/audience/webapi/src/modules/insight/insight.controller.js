'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.downloadIdReport = exports.association = exports.distribution = exports.downloadByTagId = exports.download = exports.analysisByTagId = exports.analysis = exports.campaignSegmentReportDownload = exports.campaignSegmentReportTime = exports.campaignSegmentReportPages = exports.campaignSegmentReport = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let campaignSegmentReport = exports.campaignSegmentReport = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        let body = ctx.request.body;
        try {
            data = yield _api.AnalyticsWebApi.getCampaignSegmentReport(body);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function campaignSegmentReport(_x) {
        return _ref.apply(this, arguments);
    };
})();

let campaignSegmentReportPages = exports.campaignSegmentReportPages = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        let body = ctx.request.body;
        try {
            data = yield _api.AnalyticsWebApi.getCampaignSegmentReportPages(body);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function campaignSegmentReportPages(_x2) {
        return _ref2.apply(this, arguments);
    };
})();

let campaignSegmentReportTime = exports.campaignSegmentReportTime = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        let body = ctx.request.body;
        try {
            data = yield _api.AnalyticsWebApi.getCampaignSegmentReportTime(body);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function campaignSegmentReportTime(_x3) {
        return _ref3.apply(this, arguments);
    };
})();

let campaignSegmentReportDownload = exports.campaignSegmentReportDownload = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        let body = ctx.request.body;
        try {
            let fileName = yield _api.AnalyticsWebApi.getCampaignSegmentReportDownload(body);
            data = yield (0, _fileToken.getToken)(fileName);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function campaignSegmentReportDownload(_x4) {
        return _ref4.apply(this, arguments);
    };
})();

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _fileToken = require('../fileToken/fileToken.service');

var _helper = require('../common/util/helper');

var _insightService = require('./insight.service.js');

var insightService = _interopRequireWildcard(_insightService);

var _errors = require('../common/core/errors');

var _errors2 = _interopRequireDefault(_errors);

var _api = require('../common/api');

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let analysis = exports.analysis = (() => {
    var _ref5 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let segmentId = ctx.params.segmentId;
            let { category, dataSourceId, sort } = ctx.query;
            dataSourceId = Number(dataSourceId);
            let insightInstance = new insightService.Insight({ segmentId, category, dataSourceId, sort });
            yield insightInstance.getInsightFormServer();
            yield insightInstance.filterAnalysis();
            insightInstance.sortServerAnalysis();
            yield insightInstance.getCoverage();
            yield insightInstance.getRefreshTime();
            data = insightInstance.returnAllDimensionAnalysis();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function analysis(_x5) {
        return _ref5.apply(this, arguments);
    };
})();

let analysisByTagId = exports.analysisByTagId = (() => {
    var _ref6 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {
            let { segmentId, tagId } = ctx.params;
            let { secTagId, category, dataSourceId, sort } = ctx.query;
            dataSourceId = Number(dataSourceId);
            let insightInstance = new insightService.Insight({ segmentId, category, dataSourceId, sort, tagId, secTagId });
            yield insightInstance.getInsightFormServer();
            yield insightInstance.filterAnalysis();
            insightInstance.sortServerAnalysis();
            data = insightInstance.returnSingleDimensionAnalysis();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function analysisByTagId(_x6) {
        return _ref6.apply(this, arguments);
    };
})();

let download = exports.download = (() => {
    var _ref7 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;

        try {
            let segmentId = ctx.params.segmentId;
            let { category, dataSourceId, sort } = ctx.query;

            dataSourceId = Number(dataSourceId);

            let insightInstance = new insightService.Insight({ segmentId, category, dataSourceId, sort, downloadMode: true });
            yield insightInstance.getInsightFormServer();
            yield insightInstance.filterAnalysis();
            insightInstance.sortServerAnalysis();
            yield insightInstance.getCoverage();
            yield insightInstance.getRefreshTime();
            data = yield insightInstance.returnFileToken();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }
        ctx.body = (0, _helper.wrapBody)(null, data);
    });

    return function download(_x7) {
        return _ref7.apply(this, arguments);
    };
})();

let downloadByTagId = exports.downloadByTagId = (() => {
    var _ref8 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;

        try {
            let { segmentId, tagId } = ctx.params;
            let { secTagId, category, dataSourceId, sort } = ctx.query;
            dataSourceId = Number(dataSourceId);

            let insightInstance = new insightService.Insight({ segmentId, category, dataSourceId, sort, tagId, secTagId, downloadMode: true });
            yield insightInstance.getInsightFormServer();
            yield insightInstance.filterAnalysis();
            insightInstance.sortServerAnalysis();
            yield insightInstance.getCoverage();
            data = yield insightInstance.returnFileToken();
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(null, data);
    });

    return function downloadByTagId(_x8) {
        return _ref8.apply(this, arguments);
    };
})();

//ID类型分布图
let distribution = exports.distribution = (() => {
    var _ref9 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;

        try {

            let segmentId = ctx.params.segmentId;
            let info = {
                segmentId
            };
            data = yield _api.ReportApi.getDistribution(info);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function distribution(_x9) {
        return _ref9.apply(this, arguments);
    };
})();
//ID打通率报告
let association = exports.association = (() => {
    var _ref10 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;

        try {
            let { segmentId, idType } = ctx.request.body;
            let info = {
                segmentId,
                idType
            };
            data = yield _api.ReportApi.getAssociation(info);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function association(_x10) {
        return _ref10.apply(this, arguments);
    };
})();

//下载IDmerge报告
let downloadIdReport = exports.downloadIdReport = (() => {
    var _ref11 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;

        try {
            let segmentId = ctx.params.segmentId;
            let info = {
                segmentId
            };
            let distributionData = yield _api.ReportApi.getDistribution(info);
            let allThroughData = yield _api.ReportApi.getAllThrough(info);

            let reportRefreshAt = distributionData && distributionData.reportDt;
            let fileName = yield insightService.generateIdReportXlsx(distributionData.list, allThroughData);

            if (!_fs2.default.existsSync(fileName)) {
                throw new _errors2.default.ReportNotExistFile();
            }
            let token = yield (0, _fileToken.getToken)(fileName);
            data = {
                reportRefreshAt,
                token
            };
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function downloadIdReport(_x11) {
        return _ref11.apply(this, arguments);
    };
})();
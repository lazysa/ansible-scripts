'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
const defaultSegmentTypeList = exports.defaultSegmentTypeList = {

    Campaign: [{
        dimension: 'campaignId',
        typeName: '看过',
        type: 'viewCampaign',
        segmentGroupId: '4',
        valueRules: 'campaign_site_segment.pv_campaign_id = ',
        parseRules: { campaign_site_segment: ['pv_campaign_id'] }
    }, {
        dimension: 'campaignId',
        typeName: '点过',
        type: 'clickCampaign',
        segmentGroupId: '5',
        valueRules: 'campaign_site_segment.click_campaign_id = ',
        parseRules: { campaign_site_segment: ['click_campaign_id'] }
    }, {
        dimension: 'campaignId',
        typeName: '到站',
        type: 'viewSite',
        segmentGroupId: '6',
        valueRules: 'campaign_site_segment.arrive_site_campaign_id = ',
        parseRules: { campaign_site_segment: ['arrive_site_campaign_id'] }
    }],

    Site: [{
        dimension: 'siteId',
        typeName: '访问',
        type: 'viewSite',
        segmentGroupId: '7',
        valueRules: 'campaign_site_segment.visit_site_id = ',
        parseRules: { campaign_site_segment: ['visit_site_id'] }
    }]
};

const uploadSegmentTagValueRules = exports.uploadSegmentTagValueRules = {
    1: {
        valueRules: `system_uploaded_segment.segment_flag = `,
        parseRules: { system_uploaded_segment: ['segment_flag'] }
    },
    0: {
        valueRules: `system_uploaded_no_store_segment.segment_flag = `,
        parseRules: { system_uploaded_no_store_segment: ['segment_flag'] }
    }
};
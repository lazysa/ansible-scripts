'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.behaviourTypeList = exports.getBasic = exports.getDetails = exports.exploreList = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

var _helper = require('../common/util/helper');

var _exploreService = require('./explore.service.js');

var exploreService = _interopRequireWildcard(_exploreService);

function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj.default = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let exploreList = exports.exploreList = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {

            let {
                segmentId,
                type
            } = ctx.params;
            let {
                pageSize,
                pageIndex,
                keywords,
                sort
            } = ctx.request.query;
            pageSize = pageSize * 1;
            pageIndex = pageIndex * 1;
            segmentId = segmentId == 'all' ? '' : segmentId; //默认全部
            let info = {
                "segmentId": segmentId,
                "userIdType": type.split(",").map(function (n) {
                    return n * 1;
                }),
                "pageSize": pageSize,
                "pageIndex": pageIndex,
                "keywords": keywords,
                "sort": sort
            };
            let exploreList = yield exploreService.getExploreList(info);
            data = {
                total: exploreList.total,
                list: exploreList.list,
                pageSize: pageSize,
                pageIndex: pageIndex
            };
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function exploreList(_x) {
        return _ref.apply(this, arguments);
    };
})();

let getDetails = exports.getDetails = (() => {
    var _ref2 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {

            let exploreId = ctx.params.exploreId;
            let body = ctx.request.body;
            let info = {
                "ccid": exploreId,
                "behaviourType": body.type || '',
                "startDate": body.startDate,
                "endDate": body.endDate,
                "pageSize": body.pageSize * 1,
                "pageIndex": body.pageIndex * 1
            };

            let details = yield exploreService.getDetails(info);
            data = {
                total: details.total,
                list: details.list,
                pageSize: body.pageSize,
                pageIndex: body.pageIndex
            };
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function getDetails(_x2) {
        return _ref2.apply(this, arguments);
    };
})();

let getBasic = exports.getBasic = (() => {
    var _ref3 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {

            let exploreId = ctx.params.exploreId;
            let info = {
                ccid: exploreId
            };
            data = yield exploreService.getBasic(info);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function getBasic(_x3) {
        return _ref3.apply(this, arguments);
    };
})();

let behaviourTypeList = exports.behaviourTypeList = (() => {
    var _ref4 = (0, _asyncToGenerator3.default)(function* (ctx) {
        let data = null;
        let error = null;
        try {

            let exploreId = ctx.params.exploreId;
            let { startDate, endDate } = ctx.request.query;
            let info = {
                ccid: exploreId,
                startDate,
                endDate
            };
            data = yield exploreService.getBehaviourTypeList(info);
        } catch (ex) {
            return ctx.body = (0, _helper.wrapBody)(ex);
        }

        ctx.body = (0, _helper.wrapBody)(error, data);
    });

    return function behaviourTypeList(_x4) {
        return _ref4.apply(this, arguments);
    };
})();
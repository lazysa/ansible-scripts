//privilege
let privilege = {
    "标签管理": {
        "标签管理-第一方标签": {}
    },
    "人群管理": {},
    '人群洞察': {},
    '全景资料': {}
}
//action
let action = {
    '标签管理': [{
        'actionName': 'app.tag',
        'type': '1'
    }],
    '标签管理-第一方标签': [{
        'actionName': 'app.tag.first',
        'type': '1'
    }],
    '人群管理': [{
        'actionName': 'app.segment',
        'type': '1'
    },{
        'actionName': 'audience.segment.page',
        'type': '2'
    },{
        'actionName': 'audience.segment.create',
        'type': '2'
    },{
        'actionName': 'audience.segment.delete',
        'type': '2'
    },{
        'actionName': 'audience.segment.access',
        'type': '2'
    }],
    '人群洞察': [{
        'actionName': 'app.insight.tag',
        'type': '1'
    }],
    '全景资料': [{
        'actionName': 'app.explore.identification',
        'type': '1'
    }]
}
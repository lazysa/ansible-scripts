'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.getDataSourceListByIds = exports.getDefaultMergeRule = exports.getDataSourceNameById = exports.IdMetricList = exports.InsightFieldList = exports.mergeList = exports.updatePeriodlist = exports.getDataSourceInfoById = exports.behaviourTypeList = exports.chartTypeList = exports.list = undefined;

var _asyncToGenerator2 = require('babel-runtime/helpers/asyncToGenerator');

var _asyncToGenerator3 = _interopRequireDefault(_asyncToGenerator2);

let getDataSourceNameById = exports.getDataSourceNameById = (() => {
    var _ref = (0, _asyncToGenerator3.default)(function* (id) {
        let dataSourceObj = yield _models.DataSource.findOne({
            attributes: ['id', 'name'],
            where: {
                id
            },
            raw: true
        });
        return dataSourceObj && dataSourceObj.name;
    });

    return function getDataSourceNameById(_x) {
        return _ref.apply(this, arguments);
    };
})();

var _consts = require('../../config/consts');

var _id = require('../../config/idReport/id.metric');

var _id2 = _interopRequireDefault(_id);

var _models = require('../common/models');

var _lodash = require('lodash');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let { Status, HasTagStatus, rollerType } = _consts.Enums;

let list = exports.list = () => {
    return _models.DataSource.findAll({
        attributes: ['id', 'name', 'maxSegmentFieldMappingCount'],
        where: {
            rollerType: rollerType.provider,
            hasTag: HasTagStatus.Normal,
            status: Status.Normal
        }
    });
};
let chartTypeList = exports.chartTypeList = () => {
    return _models.ChartType.findAll();
};

let behaviourTypeList = exports.behaviourTypeList = () => {
    return _models.BehaviourType.findAll({
        attributes: ['type', 'name', 'icon']
    });
};

let getDataSourceInfoById = exports.getDataSourceInfoById = id => {
    return _models.DataSource.findOne({
        attributes: ['id', 'name'],
        where: {
            id
        },
        raw: true
    });
};

let updatePeriodlist = exports.updatePeriodlist = id => {
    return _models.UpdatePeriod.findAll({
        attributes: ['id', 'name'],
        where: {
            dataSourceId: id,
            status: Status.Normal
        }
    });
};
let mergeList = exports.mergeList = () => {
    return _models.MergeRule.findAll({
        attributes: ['id', 'name', 'isDefault'],
        where: {
            status: Status.Normal
        }
    });
};
let InsightFieldList = exports.InsightFieldList = () => {
    return _models.InsightField.findAll({
        raw: true,
        order: [['colNum', 'asc']],
        where: {
            recordViewable: Status.Normal,
            status: Status.Normal
        }
    });
};

let IdMetricList = exports.IdMetricList = () => {
    return _id2.default;
};

let getDefaultMergeRule = exports.getDefaultMergeRule = () => {
    return _models.MergeRule.findOne({
        attributes: ['id', 'name', 'isDefault'],
        where: {
            status: Status.Normal,
            isDefault: Status.Normal
        },
        raw: true
    });
};

let getDataSourceListByIds = exports.getDataSourceListByIds = ids => {
    return _models.DataSource.findAll({
        attributes: ['id', 'name'],
        where: {
            id: { $in: (0, _lodash.uniq)(ids) }
        },
        raw: true
    });
};
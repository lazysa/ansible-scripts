ALTER TABLE `audience`.`segment`
ADD COLUMN `row_count` INT(10) NULL AFTER `coverage`;

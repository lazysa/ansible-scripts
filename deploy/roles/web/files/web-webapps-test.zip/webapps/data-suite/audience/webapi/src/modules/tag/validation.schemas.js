'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.update = exports.create = exports.TagPages = undefined;

var _values = require('babel-runtime/core-js/object/values');

var _values2 = _interopRequireDefault(_values);

var _joi = require('joi');

var _joi2 = _interopRequireDefault(_joi);

var _consts = require('../../config/consts');

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

let TagPages = exports.TagPages = _joi2.default.object().keys({
    keywords: _joi2.default.string().allow('').min(0).max(30),
    pageIndex: _joi2.default.number().integer().min(1).required().default(1),
    pageSize: _joi2.default.number().integer().min(1).max(1000).required().default(10),
    sort: _joi2.default.string().allow('')
});

let create = exports.create = _joi2.default.object().keys({
    name: _joi2.default.string().required().max(25),
    tagType: _joi2.default.number().integer().required().valid((0, _values2.default)(_consts.Enums.TagType)),
    tagGroupId: _joi2.default.string().required(),
    mergeRule: _joi2.default.array(),
    updatePeriod: _joi2.default.number().integer().required(),
    remark: _joi2.default.string().allow('', null).min(0).max(250),
    status: _joi2.default.number().integer().required(),
    isUsedForInsight: _joi2.default.number().integer(),
    isUsedForSegment: _joi2.default.number().integer(),
    chartType: _joi2.default.string().allow('', null),
    expires: _joi2.default.string().allow('', null),
    isForever: _joi2.default.number().integer().valid([0, 1])
});

let update = exports.update = _joi2.default.object().keys({
    name: _joi2.default.string().required().max(25),
    tagType: _joi2.default.number().integer().required().valid((0, _values2.default)(_consts.Enums.TagType)),
    tagGroupId: _joi2.default.string().required(),
    updatePeriod: _joi2.default.number().integer().required(),
    remark: _joi2.default.string().allow('', null).min(0).max(250),
    priority: _joi2.default.array(),
    status: _joi2.default.number().integer().required(),
    isUsedForInsight: _joi2.default.number().integer(),
    isUsedForSegment: _joi2.default.number().integer(),
    chartType: _joi2.default.string().allow('', null),
    expires: _joi2.default.string().allow('', null),
    isForever: _joi2.default.number().integer().valid([0, 1])
});